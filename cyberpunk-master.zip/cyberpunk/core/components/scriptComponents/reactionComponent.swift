
public class PlayerMuntedToMyVehicle extends Event {

  public let player: wref<PlayerPuppet>;

  public final static func Create(player: wref<PlayerPuppet>) -> ref<PlayerMuntedToMyVehicle> {
    let evt: ref<PlayerMuntedToMyVehicle> = new PlayerMuntedToMyVehicle();
    evt.player = player;
    return evt;
  }
}

public class StimFilters extends IScriptable {

  public final static func Debug_IsAllowed(stimType: gamedataStimType) -> Bool {
    if IsFinal() {
      return true;
    };
    return true;
  }

  public final static func IsGunshot(stimType: gamedataStimType) -> Bool {
    return Equals(stimType, gamedataStimType.Gunshot) || Equals(stimType, gamedataStimType.SilencedGunshot);
  }

  public final static func IsProjectile(stimType: gamedataStimType) -> Bool {
    return Equals(stimType, gamedataStimType.Bullet) || Equals(stimType, gamedataStimType.ProjectileDistraction);
  }

  public final static func IsIllegalAction(stimType: gamedataStimType) -> Bool {
    return Equals(stimType, gamedataStimType.IllegalAction) || Equals(stimType, gamedataStimType.IllegalActionNoCombat);
  }

  public final static func IsIllegal(stimType: gamedataStimType) -> Bool {
    return StimFilters.IsIllegalAction(stimType) || Equals(stimType, gamedataStimType.IllegalInteraction);
  }

  public final static func IsIgnoredWhileGrappled(stimType: gamedataStimType) -> Bool {
    return NotEquals(stimType, gamedataStimType.Combat);
  }

  public final static func IsIgnoredFromSameSource(stimType: gamedataStimType) -> Bool {
    return Equals(stimType, gamedataStimType.Distract) || Equals(stimType, gamedataStimType.CarAlarm) || Equals(stimType, gamedataStimType.Recon);
  }

  public final static func IsIgnoredInVehicle(stimType: gamedataStimType) -> Bool {
    return Equals(stimType, gamedataStimType.CrowdIllegalAction) || Equals(stimType, gamedataStimType.CrimeWitness) || Equals(stimType, gamedataStimType.SpreadFear);
  }

  public final static func ShouldBeInPublicZone(stimType: gamedataStimType) -> Bool {
    return Equals(stimType, gamedataStimType.WeaponDisplayed);
  }

  public final static func ShouldBeFriendly(stimType: gamedataStimType) -> Bool {
    return Equals(stimType, gamedataStimType.DeadBody);
  }

  public final static func ShouldBeDetected(stimType: gamedataStimType) -> Bool {
    return Equals(stimType, gamedataStimType.IllegalInteraction) || Equals(stimType, gamedataStimType.CarryBody);
  }

  public final static func IsForTheDead(stimType: gamedataStimType) -> Bool {
    return Equals(stimType, gamedataStimType.UndeadCall);
  }

  public final static func CanTriggerAllyHelp(stimType: gamedataStimType) -> Bool {
    return StimFilters.IsGunshot(stimType) || StimFilters.IsProjectile(stimType) || Equals(stimType, gamedataStimType.Explosion) || Equals(stimType, gamedataStimType.MeleeHit) || Equals(stimType, gamedataStimType.VehicleHit) || Equals(stimType, gamedataStimType.Alarm) || Equals(stimType, gamedataStimType.Call) || Equals(stimType, gamedataStimType.Dying);
  }

  public final static func CanTriggerNeutralHelp(stimType: gamedataStimType) -> Bool {
    return StimFilters.IsGunshot(stimType) || Equals(stimType, gamedataStimType.Bullet) || Equals(stimType, gamedataStimType.Explosion);
  }

  public final static func CanTriggerEnemyHostility(stimType: gamedataStimType) -> Bool {
    return StimFilters.CanTriggerNeutralHelp(stimType);
  }

  public final static func CanProcessPastAllyHelp(stimType: gamedataStimType) -> Bool {
    return Equals(stimType, gamedataStimType.Call) || Equals(stimType, gamedataStimType.Dying);
  }

  public final static func CanTriggerCombatDirectly(stimType: gamedataStimType) -> Bool {
    return StimFilters.IsGunshot(stimType) || StimFilters.IsIllegal(stimType) && NotEquals(stimType, gamedataStimType.IllegalActionNoCombat) || Equals(stimType, gamedataStimType.Combat) || Equals(stimType, gamedataStimType.Bullet) || Equals(stimType, gamedataStimType.CarryBody);
  }

  public final static func CanTriggerAlertedDirectly(stimType: gamedataStimType) -> Bool {
    return Equals(stimType, gamedataStimType.CombatHit);
  }

  public final static func CanTriggerPreventionCombatDirectly(stimType: gamedataStimType) -> Bool {
    return Equals(stimType, gamedataStimType.VehicleHit) || Equals(stimType, gamedataStimType.HijackVehicle) || Equals(stimType, gamedataStimType.CrimeWitness) || Equals(stimType, gamedataStimType.CombatHit);
  }

  public final static func CanTriggerPreventionCombatDirectlyEvenInvisible(stimType: gamedataStimType) -> Bool {
    return Equals(stimType, gamedataStimType.VehicleHit);
  }

  public final static func CanBeIgnoredInCombat(stimType: gamedataStimType) -> Bool {
    return StimFilters.IsGunshot(stimType) || StimFilters.IsProjectile(stimType) || StimFilters.IsIllegal(stimType) || Equals(stimType, gamedataStimType.Explosion);
  }
}

public class ReactionManagerComponent extends ScriptableComponent {

  private let m_activeReaction: ref<AIReactionData>;

  private let m_desiredReaction: ref<AIReactionData>;

  private let m_stimuliCache: array<ref<StimEventTaskData>>;

  private let m_reactionCache: array<ref<AIReactionData>>;

  private let m_reactionPreset: ref<ReactionPreset_Record>;

  private let m_puppetReactionBlackboard: ref<IBlackboard>;

  private let m_receivedStimType: gamedataStimType;

  private let m_receivedStimPropagation: gamedataStimPropagation;

  private let m_inCrowd: Bool;

  private let m_inTrafficLane: Bool;

  @default(ReactionManagerComponent, -1)
  private let m_desiredFearPhase: Int32;

  private let m_previousFearPhase: Int32;

  @default(ReactionManagerComponent, 0.3f)
  private let m_NPCRadius: Float;

  @default(ReactionManagerComponent, 1.0f)
  private let m_bumpTriggerDistanceBufferMounted: Float;

  @default(ReactionManagerComponent, -0.11f)
  private let m_bumpTriggerDistanceBufferCrouched: Float;

  private let m_delayReactionEventID: DelayID;

  private let m_delay: Vector2;

  private let m_delayDetectionEventID: DelayID;

  private let m_delayStimEventID: DelayID;

  private let m_resetReactionDataID: DelayID;

  private let m_callingPoliceID: DelayID;

  private let m_lookatEvent: ref<LookAtAddEvent>;

  private let m_ignoreList: array<EntityID>;

  private let m_investigationList: array<StimEventData>;

  private let m_pendingReaction: ref<AIReactionData>;

  @default(ReactionManagerComponent, 1.f)
  private let m_ovefloodCooldown: Float;

  @default(ReactionManagerComponent, gamedataNPCStanceState.Stand)
  private let m_stanceState: gamedataNPCStanceState;

  @default(ReactionManagerComponent, gamedataNPCHighLevelState.Relaxed)
  private let m_highLevelState: gamedataNPCHighLevelState;

  private let m_aiRole: EAIRole;

  private let m_pendingBehaviorCb: ref<CallbackHandle>;

  private let m_inPendingBehavior: Bool;

  private let m_cacheSecuritySysOutput: ref<SecuritySystemOutput>;

  private let m_environmentalHazards: array<ref<StimuliEvent>>;

  private let m_environmentalHazardsDelayIDs: array<DelayID>;

  private let m_stolenVehicle: wref<VehicleObject>;

  @default(ReactionManagerComponent, false)
  private let m_isAlertedByDeadBody: Bool;

  private let m_isInCrosswalk: Bool;

  private let m_beignHijacked: Bool;

  private let m_owner_id: EntityID;

  private let m_presetName: CName;

  private let m_updateByActive: Bool;

  private let m_personalities: array<gamedataStatType>;

  private let m_workspotReactionPlayed: Bool;

  private let m_inReactionSequence: Bool;

  private let m_playerProximity: Bool;

  private let m_fearToIdleDistance: Vector2;

  private let m_exitWorkspotAim: Vector2;

  private let m_bumpedRecently: Int32;

  private let m_bumpTimestamp: Float;

  private let m_crowdAimingReactionDistance: Float;

  private let m_fearInPlaceAroundDistance: Float;

  private let m_lookatRepeat: Bool;

  private let m_disturbingComfortZoneInProgress: Bool;

  private let m_entereProximityRecently: Int32;

  private let m_comfortZoneTimestamp: Float;

  private let m_disturbComfortZoneEventId: DelayID;

  private let m_checkComfortZoneEventId: DelayID;

  private let m_spreadingFearEventId: DelayID;

  private let m_proximityLookatEventId: DelayID;

  private let m_resetFacialEventId: DelayID;

  private let m_exitWorkspotSequenceEventId: DelayID;

  private let m_exitFearInVehicleEventId: DelayID;

  @default(ReactionManagerComponent, true)
  private let m_fastWalk: Bool;

  @default(ReactionManagerComponent, true)
  private let m_createThreshold: Bool;

  private let m_initialized: Bool;

  private let m_initCrowd: Bool;

  private let m_facialCooldown: Float;

  private let m_disturbComfortZoneAggressiveEventId: DelayID;

  private let m_backOffInProgress: Bool;

  private let m_backOffTimestamp: Float;

  @default(ReactionManagerComponent, gameFearStage.Relaxed)
  private let m_crowdFearStage: gameFearStage;

  private let m_fearLocomotionWrapper: Bool;

  private let m_successfulFearDeescalation: Float;

  private let m_willingToCallPolice: Bool;

  private let m_deadBodyInvestigators: array<EntityID>;

  private let m_deadBodyStartingPosition: Vector4;

  private let m_currentStimThresholdValue: Int32;

  private let m_timeStampThreshold: Float;

  private let m_currentStealthStimThresholdValue: Int32;

  private let m_stealthTimeStampThreshold: Float;

  @default(ReactionManagerComponent, false)
  private let m_driverAllowedToGetAggressive: Bool;

  @default(ReactionManagerComponent, false)
  private let m_driverIsAggressive: Bool;

  @default(ReactionManagerComponent, EReactLogSource.Undefined)
  private let m_logSource: EReactLogSource;

  @default(ReactionManagerComponent, 5.f)
  private let m_gracePeriodDuration: Float;

  private let m_recentAlertObject: wref<GameObject>;

  private let m_recentAlertTimeStamp: Float;

  private final const func Log(category: CName, message: String) -> Void {
    let aiComponent: ref<AIHumanComponent>;
    if IsFinal() {
      return;
    };
    aiComponent = this.GetOwnerPuppet().GetAIControllerComponent();
    if IsDefined(aiComponent) {
      aiComponent.DebugLog(category, message);
    };
  }

  private final const func LogStim(category: CName, stimType: gamedataStimType, stimPropagation: gamedataStimPropagation, message: String) -> Void {
    let logMessage: String;
    if IsFinal() {
      return;
    };
    logMessage = "(" + EnumValueToString("gamedataStimPropagation", Cast<Int64>(EnumInt(stimPropagation))) + ") ";
    logMessage += EnumValueToString("gamedataStimType", Cast<Int64>(EnumInt(stimType)));
    logMessage += ": ";
    logMessage += message;
    this.Log(category, logMessage);
  }

  private final const func LogReactionData(category: CName, reactionData: ref<AIReactionData>, message: String) -> Void {
    if IsFinal() {
      return;
    };
    if IsDefined(reactionData) {
      this.LogStim(category, reactionData.stimType, reactionData.stimPropagation, message);
      return;
    };
    this.Log(category, "NO REACTION DATA: " + message);
  }

  private final const func LogReaction(category: CName, message: String) -> Void {
    if IsFinal() {
      return;
    };
    switch this.m_logSource {
      case EReactLogSource.Detected:
        this.Log(category, "OnDetected: " + message);
        break;
      case EReactLogSource.StimEvent:
        this.LogStim(category, this.m_receivedStimType, this.m_receivedStimPropagation, message);
        break;
      case EReactLogSource.BehaviorCombatTrigger:
      case EReactLogSource.BehaviorCombatCheck:
        this.LogReactionData(category, this.GetActiveOrDesiredReactionData(), message);
        break;
      default:
        this.Log(category, message);
    };
  }

  private final const func LogCategory(suffix: String) -> CName {
    let cat: String;
    if IsFinal() {
      return n"None";
    };
    cat = "reactions";
    switch this.m_logSource {
      case EReactLogSource.Detected:
        cat += ".detect";
        break;
      case EReactLogSource.StimEvent:
        cat += ".stim";
        break;
      case EReactLogSource.BehaviorCombatTrigger:
      case EReactLogSource.BehaviorCombatCheck:
        cat += ".behavior";
        break;
      default:
    };
    if StrLen(suffix) > 0 {
      cat += "." + suffix;
    };
    return StringToName(cat);
  }

  public final func LogStart(source: EReactLogSource, message: String) -> Void {
    this.m_logSource = source;
    this.LogReaction(this.LogCategory("start"), message);
  }

  public final const func LogInfo(message: String) -> Void {
    this.LogReaction(this.LogCategory("info"), message);
  }

  public final const func LogSuccess(message: String) -> Void {
    this.LogReaction(this.LogCategory("success"), message);
  }

  public final const func LogFailure(message: String) -> Void {
    this.LogReaction(this.LogCategory("failure"), message);
  }

  protected final func HandleStimEventByTask(stimEvent: ref<StimuliEvent>, opt delayed: Bool) -> Void {
    let data: ref<StimEventTaskData> = new StimEventTaskData();
    data.cachedEvt = stimEvent;
    data.delayed = delayed;
    GameInstance.GetDelaySystem(this.GetOwner().GetGame()).QueueTask(this, data, n"HandleStimEventTask", gameScriptTaskExecutionStage.PostPhysics);
  }

  protected final func HandleStimEventTask(data: ref<ScriptTaskData>) -> Void {
    let stimData: ref<StimEventTaskData> = data as StimEventTaskData;
    if IsDefined(stimData) {
      this.HandleStimEvent(stimData);
    };
  }

  protected final func HandleStimEvent(stimData: ref<StimEventTaskData>) -> Void {
    let localPlayer: ref<GameObject>;
    let ownerPuppet: ref<ScriptedPuppet>;
    let resetLookatReaction: ref<ResetLookatReactionEvent>;
    let stimEvent: ref<StimuliEvent>;
    let stimParams: StimParams;
    let stimType: gamedataStimType;
    if !IsDefined(stimData) || !IsDefined(stimData.cachedEvt) {
      return;
    };
    stimEvent = stimData.cachedEvt;
    stimType = stimEvent.GetStimType();
    this.m_receivedStimType = stimType;
    this.m_receivedStimPropagation = stimEvent.stimPropagation;
    if !this.IsEnabled() && !StimFilters.IsForTheDead(stimType) {
      this.m_receivedStimType = gamedataStimType.Invalid;
      this.m_receivedStimPropagation = gamedataStimPropagation.Invalid;
      return;
    };
    if !this.m_initialized {
      this.Initialiaze();
      this.m_initialized = true;
    };
    ownerPuppet = this.GetOwnerPuppet();
    if Equals(stimType, gamedataStimType.AudioEnemyPing) {
      if ScriptedPuppet.IsActive(ownerPuppet) && ownerPuppet.IsAggressive() {
        localPlayer = GameInstance.GetPlayerSystem(ownerPuppet.GetGame()).GetLocalPlayerMainGameObject();
        if !this.SourceAttitude(localPlayer, EAIAttitude.AIA_Friendly) {
          GameInstance.GetAudioSystem(ownerPuppet.GetGame()).RegisterEnemyPingStim(ownerPuppet.GetHighLevelStateFromBlackboard(), ownerPuppet.IsPrevention());
        };
      };
      return;
    };
    if stimData.delayed {
      this.LogStart(EReactLogSource.StimEvent, "processing delayed stim event");
    } else {
      this.LogStart(EReactLogSource.StimEvent, "processing stim event");
    };
    if this.ShouldEventBeProcessed(stimEvent) {
      if !ownerPuppet.IsPrevention() && IsDefined(ownerPuppet.GetCrowdMemberComponent()) && (this.m_inCrowd || ownerPuppet.IsCharacterCivilian()) {
        this.LogInfo("processing crowd stim");
        if this.ShouldStimBeProcessedByCrowd(stimEvent) {
          this.LogSuccess("handling crowd reaction");
          this.HandleCrowdReaction(stimEvent);
        };
        if stimEvent.IsTagInStimuli(n"Safe") {
          this.LogInfo("resetting lookat with delay");
          resetLookatReaction = new ResetLookatReactionEvent();
          GameInstance.GetDelaySystem(this.GetOwner().GetGame()).DelayEvent(this.GetOwner(), resetLookatReaction, 1.00);
        };
        this.m_receivedStimType = gamedataStimType.Invalid;
        this.m_receivedStimPropagation = gamedataStimPropagation.Invalid;
        return;
      };
      this.LogInfo("processing stim");
      if this.ShouldStimBeProcessed(stimEvent, stimData.delayed) {
        stimParams = this.ProcessStimParams(stimEvent);
        this.ProcessReactionOutput(stimData, stimParams);
      };
    };
    if (Equals(stimType, gamedataStimType.StopedAiming) || Equals(stimType, gamedataStimType.ReevaluateDetectionOverwrite)) && this.m_reactionPreset.IsAggressive() {
      ownerPuppet.GetSensesComponent().ReevaluateDetectionOverwrite(stimEvent.sourceObject);
      this.LogSuccess("reevaluated detection overwrite");
    };
    if Equals(stimType, gamedataStimType.EnvironmentalHazard) {
      this.ProcessEnvironmentalHazard(stimEvent);
    };
    if StimFilters.IsForTheDead(stimEvent.GetStimType()) {
      this.ProcessStimForTheDead(stimEvent);
    };
    this.m_receivedStimType = gamedataStimType.Invalid;
    this.m_receivedStimPropagation = gamedataStimPropagation.Invalid;
  }

  protected final func ReactToSecuritySystemOutputByTask(evt: ref<SecuritySystemOutput>) -> Void {
    let data: ref<SecuritySystemOutputTaskData> = new SecuritySystemOutputTaskData();
    data.cachedEvt = evt;
    GameInstance.GetDelaySystem(this.GetOwner().GetGame()).QueueTask(this, data, n"ReactToSecuritySystemOutputTask", gameScriptTaskExecutionStage.Any);
  }

  protected final func ReactToSecuritySystemOutputTask(data: ref<ScriptTaskData>) -> Void {
    let taskData: ref<SecuritySystemOutputTaskData> = data as SecuritySystemOutputTaskData;
    if IsDefined(taskData) {
      this.ReactToSecurityOutput(taskData.cachedEvt);
    };
  }

  public final func OnGameAttach() -> Void {
    this.m_owner_id = this.GetOwner().GetEntityID();
    this.m_puppetReactionBlackboard = IBlackboard.Create(GetAllBlackboardDefs().PuppetReaction);
  }

  protected cb func OnPlayerMuntedToMyVehicle(evt: ref<PlayerMuntedToMyVehicle>) -> Bool {
    let ownerPuppet: ref<ScriptedPuppet> = this.GetOwnerPuppet();
    if ownerPuppet.IsAggressive() && ScriptedPuppet.IsActive(ownerPuppet) && AIActionHelper.TryChangingAttitudeToHostile(ownerPuppet, evt.player) {
      if !this.GetOwnerPuppet().GetPuppetStateBlackboard().GetBool(GetAllBlackboardDefs().PuppetState.WorkspotAnimationInProgress) {
        this.GetOwner().QueueEvent(AIEvents.ExitVehicleEvent());
        TargetTrackingExtension.InjectThreat(ownerPuppet, evt.player);
      };
    };
  }

  protected cb func OnSenseVisibilityEvent(evt: ref<SenseVisibilityEvent>) -> Bool {
    let broadcaster: ref<StimBroadcasterComponent>;
    let ownerPuppet: ref<ScriptedPuppet> = this.GetOwnerPuppet();
    let owner: ref<GameObject> = this.GetOwner();
    if !IsDefined(evt.target) || !evt.target.IsPlayer() {
      return false;
    };
    if ownerPuppet.IsPrevention() || NPCManager.HasTag(ownerPuppet.GetRecordID(), n"TriggerPrevention") {
      if evt.isVisible {
        PreventionSystem.RegisterAsViewerToPreventionSystem(owner.GetGame(), ownerPuppet);
      } else {
        PreventionSystem.UnRegisterAsViewerToPreventionSystem(owner.GetGame(), ownerPuppet);
      };
    };
    if !evt.isVisible {
      (owner as NPCPuppet).GetComfortZoneComponent().Toggle(false);
      return false;
    };
    if !this.CanTriggerReprimandOrder() {
      return false;
    };
    if !IsDefined(this.m_activeReaction) {
      broadcaster = evt.target.GetStimBroadcasterComponent();
      broadcaster.SendDrirectStimuliToTarget(owner, gamedataStimType.AskToFollowOrder, owner);
    };
    if NotEquals(this.m_highLevelState, gamedataNPCHighLevelState.Combat) {
      (owner as NPCPuppet).GetComfortZoneComponent().Toggle(true);
    };
  }

  protected cb func OnLookedAtEvent(evt: ref<LookedAtEvent>) -> Bool {
    let broadcaster: ref<StimBroadcasterComponent> = this.GetPlayerSystem().GetLocalPlayerControlledGameObject().GetStimBroadcasterComponent();
    if IsDefined(broadcaster) && evt.isLookedAt && !IsDefined(this.m_activeReaction) && this.CanTriggerReprimandOrder() {
      broadcaster.SendDrirectStimuliToTarget(this.GetOwner(), gamedataStimType.AskToFollowOrder, this.GetOwner());
    };
  }

  protected cb func OnDetectedEvent(evt: ref<OnDetectedEvent>) -> Bool {
    let broadcaster: ref<StimBroadcasterComponent>;
    let deviceLink: ref<PuppetDeviceLinkPS>;
    let ignoreListEvent: ref<IgnoreListEvent>;
    let investigateData: stimInvestigateData;
    let scriptedPuppetTarget: ref<ScriptedPuppet>;
    let securitySystem: ref<SecuritySystemControllerPS>;
    let securitySystemInput: ref<SecuritySystemInput>;
    let targetOfSource: wref<GameObject>;
    let ownerPuppet: ref<ScriptedPuppet> = this.GetOwnerPuppet();
    let owner: ref<GameObject> = this.GetOwner();
    let onlyAlertNoThreat: Bool = false;
    this.LogStart(EReactLogSource.Detected, "handling event");
    if ScriptedPuppet.IsBlinded(ownerPuppet) {
      this.LogFailure("owner is blinded");
      return false;
    };
    if !IsDefined(evt.target) {
      this.LogFailure("no target");
      return false;
    };
    if !evt.isVisible {
      this.LogFailure("target is not visible");
      return false;
    };
    if evt.target.IsPlayer() {
      deviceLink = owner.GetDeviceLink() as PuppetDeviceLinkPS;
      if IsDefined(deviceLink) {
        deviceLink.NotifyAboutSpottingPlayer(true);
      };
      if this.IsPlayerAiming() && this.IsReactionAvailableInPreset(gamedataStimType.AimingAt) || this.DidTargetMakeMeAlerted(evt.target) {
        AIActionHelper.TryStartCombatWithTarget(ownerPuppet, evt.target);
        this.LogSuccess("starting combat with target (target aiming at owner)");
        return false;
      };
      broadcaster = evt.target.GetStimBroadcasterComponent();
      securitySystem = ownerPuppet.GetSecuritySystem();
      if Equals(this.m_reactionPreset.Type(), gamedataReactionPresetType.Civilian_Guard) || Equals(this.m_reactionPreset.Type(), gamedataReactionPresetType.Civilian_Grabbable) {
        broadcaster.SendDrirectStimuliToTarget(owner, gamedataStimType.SecurityBreach, owner);
        this.LogSuccess("broadcasted SecurityBreach to owner");
      } else {
        if IsDefined(securitySystem) {
          securitySystemInput = deviceLink.ActionSecurityBreachNotification(evt.target.GetWorldPosition(), evt.target, ESecurityNotificationType.DEFAULT);
          if Equals(securitySystem.DetermineSecuritySystemState(securitySystemInput, true), ESecuritySystemState.COMBAT) {
            AIActionHelper.TryStartCombatWithTarget(ownerPuppet, evt.target);
            this.LogSuccess("starting combat with target (security system in combat)");
          } else {
            ownerPuppet.TriggerSecuritySystemNotification(evt.target.GetWorldPosition(), evt.target, ESecurityNotificationType.DEFAULT);
            this.LogSuccess("triggered security system notification");
          };
        };
      };
      if this.IsTargetArmed(evt.target) && IsDefined(broadcaster) {
        broadcaster.SendDrirectStimuliToTarget(owner, gamedataStimType.WeaponDisplayed, owner);
        this.LogSuccess("broadcasted WeaponDisplayed to owner");
      };
      if StatusEffectSystem.ObjectHasStatusEffect(evt.target, t"PreventionStatusEffect.PerformingIllegalAction") && this.IsReactionAvailableInPreset(gamedataStimType.IllegalAction) {
        broadcaster.SendDrirectStimuliToTarget(owner, gamedataStimType.IllegalAction, owner);
        this.LogSuccess("broadcasted IllegalAction to owner");
      };
      return false;
    };
    if Equals(this.m_highLevelState, gamedataNPCHighLevelState.Combat) && ownerPuppet.IsPrevention() && Equals((evt.target as ScriptedPuppet).GetHighLevelStateFromBlackboard(), gamedataNPCHighLevelState.Combat) && this.SourceAttitude(evt.target, EAIAttitude.AIA_Neutral) {
      AIActionHelper.TryStartCombatWithTarget(ownerPuppet, evt.target);
      this.LogSuccess("starting combat with target (already in combat)");
      return false;
    };
    if NotEquals(this.m_highLevelState, gamedataNPCHighLevelState.Combat) && evt.target.IsPuppet() && !evt.target.IsDead() && !ownerPuppet.IsCharacterCivilian() && !ownerPuppet.IsCharacterChildren() && this.SourceAttitude(evt.target, EAIAttitude.AIA_Friendly) {
      targetOfSource = this.GetCombatTarget(evt.target);
      if this.IsTargetSquadAlly(evt.target) || this.IsTargetInSameSecuritySystem(evt.target) || this.ShouldHelpTargetFromSameAttitudeGroup(evt.target, targetOfSource) || this.ShouldHelpCausePlayerGotTooClose(targetOfSource, onlyAlertNoThreat) {
        scriptedPuppetTarget = evt.target as ScriptedPuppet;
        if Equals(scriptedPuppetTarget.GetStimReactionComponent().GetReactionPreset().Type(), gamedataReactionPresetType.Civilian_Guard) || Equals(scriptedPuppetTarget.GetStimReactionComponent().GetReactionPreset().Type(), gamedataReactionPresetType.Civilian_Grabbable) {
          if Equals(scriptedPuppetTarget.GetHighLevelStateFromBlackboard(), gamedataNPCHighLevelState.Fear) && Equals(this.m_highLevelState, gamedataNPCHighLevelState.Relaxed) {
            NPCPuppet.ChangeHighLevelState(owner, gamedataNPCHighLevelState.Alerted);
            this.LogSuccess("entering alerted state (ally in fear)");
          };
        } else {
          this.LogInfo("HelpAlly attempt - friend detected");
          this.HelpAlly(scriptedPuppetTarget, targetOfSource, onlyAlertNoThreat);
        };
      };
    };
    if NotEquals(evt.description, n"Dead_Body") && NotEquals(evt.description, n"Unconscious") && NotEquals(evt.description, n"HeartAttack") {
      return false;
    };
    this.LogInfo("handling dead/defeated body");
    if this.HasCombatTarget() {
      if ArrayContains(this.m_ignoreList, evt.target.GetEntityID()) {
        this.LogSuccess("body already ignored");
      } else {
        ArrayPush(this.m_ignoreList, ignoreListEvent.bodyID);
        ignoreListEvent = new IgnoreListEvent();
        ignoreListEvent.bodyID = evt.target.GetEntityID();
        this.SendIgnoreEventToSquad(ignoreListEvent);
        this.LogSuccess("new body ignored");
      };
      return false;
    };
    broadcaster = evt.target.GetStimBroadcasterComponent();
    if IsDefined(broadcaster) {
      if Equals(evt.description, n"Dead_Body") {
        investigateData.attackInstigator = EntityGameInterface.GetEntity(GameInstance.GetPlayerSystem(owner.GetGame()).GetLocalPlayerControlledGameObject().GetEntity());
      };
      broadcaster.SendDrirectStimuliToTarget(owner, gamedataStimType.DeadBody, owner, investigateData);
      this.LogSuccess("broadcasted DeadBody to owner");
    };
  }

  protected cb func OnSecurityAreaCrossingPerimeter(evt: ref<SecurityAreaCrossingPerimeter>) -> Bool {
    let target: wref<GameObject>;
    if !this.IsEnabled() {
      return IsDefined(null);
    };
    if IsDefined(this.GetOwner()) {
      target = evt.GetWhoBreached();
    };
    if IsDefined(target) && target.IsPlayer() && this.IsTargetDetected(target) {
      if NotEquals(this.m_reactionPreset.Type(), gamedataReactionPresetType.Civilian_Guard) || NotEquals(this.m_reactionPreset.Type(), gamedataReactionPresetType.Civilian_Grabbable) {
        this.GetOwnerPuppet().TriggerSecuritySystemNotification(target.GetWorldPosition(), target, ESecurityNotificationType.DEFAULT);
      };
    };
  }

  protected cb func OnSecuritySystemOutput(evt: ref<SecuritySystemOutput>) -> Bool {
    let debugFact: CName;
    if this.GetOwnerPuppet().GetAreIncomingSecuritySystemEventsSuppressed() {
      return IsDefined(null);
    };
    if !IsFinal() {
      debugFact = StringToName(EntityID.ToDebugStringDecimal(this.m_owner_id));
      AddFact(this.GetOwnerPuppet().GetGame(), debugFact);
    };
    this.ReactToSecuritySystemOutputByTask(evt);
  }

  protected cb func OnReprimandEscalationEvent(evt: ref<ReprimandEscalationEvent>) -> Bool {
    if evt.startReprimand {
      this.StartEscalateReprimand();
    } else {
      if evt.startDeescalate {
        this.DeescalateReprimand();
      } else {
        this.ReprimandEscalation();
      };
    };
  }

  private final func StartEscalateReprimand() -> Void {
    let statPoolSys: ref<StatPoolsSystem> = GameInstance.GetStatPoolsSystem(this.GetOwner().GetGame());
    statPoolSys.RequestAddingStatPool(Cast<StatsObjectID>(this.GetOwner().GetEntityID()), t"BaseStatPools.ReprimandEscalation", true);
  }

  private final func ReprimandEscalation() -> Void {
    let statPoolMod: StatPoolModifier;
    let owner: ref<GameObject> = this.GetOwner();
    let ownerId: EntityID = owner.GetEntityID();
    let statPoolSys: ref<StatPoolsSystem> = GameInstance.GetStatPoolsSystem(owner.GetGame());
    statPoolSys.GetModifier(Cast<StatsObjectID>(ownerId), gamedataStatPoolType.ReprimandEscalation, gameStatPoolModificationTypes.Regeneration, statPoolMod);
    statPoolMod.enabled = true;
    statPoolSys.RequestSettingModifier(Cast<StatsObjectID>(ownerId), gamedataStatPoolType.ReprimandEscalation, gameStatPoolModificationTypes.Regeneration, statPoolMod);
  }

  private final func DeescalateReprimand() -> Void {
    let decayMod: StatPoolModifier;
    let regenMod: StatPoolModifier;
    let owner: ref<GameObject> = this.GetOwner();
    let ownerId: EntityID = owner.GetEntityID();
    let statPoolSys: ref<StatPoolsSystem> = GameInstance.GetStatPoolsSystem(owner.GetGame());
    statPoolSys.GetModifier(Cast<StatsObjectID>(ownerId), gamedataStatPoolType.ReprimandEscalation, gameStatPoolModificationTypes.Regeneration, regenMod);
    regenMod.enabled = false;
    statPoolSys.RequestSettingModifier(Cast<StatsObjectID>(ownerId), gamedataStatPoolType.ReprimandEscalation, gameStatPoolModificationTypes.Regeneration, regenMod);
    statPoolSys.GetModifier(Cast<StatsObjectID>(ownerId), gamedataStatPoolType.ReprimandEscalation, gameStatPoolModificationTypes.Decay, decayMod);
    decayMod.enabled = true;
    statPoolSys.RequestSettingModifier(Cast<StatsObjectID>(ownerId), gamedataStatPoolType.ReprimandEscalation, gameStatPoolModificationTypes.Decay, decayMod);
  }

  protected cb func OnReprimandUpdate(evt: ref<ReprimandUpdate>) -> Bool {
    let broadcaster: ref<StimBroadcasterComponent>;
    let owner: ref<GameObject>;
    let ownerPuppet: ref<ScriptedPuppet>;
    let reprimandUpdateEvent: ref<StimuliEvent>;
    let trespasser: ref<GameObject>;
    let trespasserID: EntityID;
    if !this.IsEnabled() {
      return false;
    };
    owner = this.GetOwner();
    ownerPuppet = this.GetOwnerPuppet();
    if ownerPuppet.GetAreIncomingSecuritySystemEventsSuppressed() {
      return false;
    };
    if Equals(evt.reprimandInstructions, EReprimandInstructions.CONCLUDE_SUCCESSFUL) {
      reprimandUpdateEvent = new StimuliEvent();
      reprimandUpdateEvent.name = n"targetComplies";
      owner.QueueEvent(reprimandUpdateEvent);
    };
    if Equals(evt.reprimandInstructions, EReprimandInstructions.CONCLUDE_FAILED) {
      reprimandUpdateEvent = new StimuliEvent();
      reprimandUpdateEvent.name = n"concludeFailed";
      owner.QueueEvent(reprimandUpdateEvent);
    };
    if Equals(evt.reprimandInstructions, EReprimandInstructions.RELEASE_TO_ANOTHER_ENTITY) {
      reprimandUpdateEvent = new StimuliEvent();
      reprimandUpdateEvent.name = n"exitReprimand";
    };
    trespasserID = evt.target;
    trespasser = GameInstance.FindEntityByID(owner.GetGame(), trespasserID) as GameObject;
    if !IsDefined(trespasser) {
      return false;
    };
    broadcaster = trespasser.GetStimBroadcasterComponent();
    if VehicleComponent.IsMountedToVehicle(owner.GetGame(), trespasser) {
      AIActionHelper.TryStartCombatWithTarget(ownerPuppet, trespasser);
    };
    if Equals(evt.reprimandInstructions, EReprimandInstructions.INITIATE_FIRST) {
      if this.RecentReaction(gamedataOutput.AskToHolster) {
        broadcaster.SendDrirectStimuliToTarget(owner, gamedataStimType.ReprimandFinalWarning, owner);
      } else {
        broadcaster.SendDrirectStimuliToTarget(owner, gamedataStimType.Reprimand, owner);
      };
    };
    if Equals(evt.reprimandInstructions, EReprimandInstructions.INITIATE_SUCCESSIVE) {
      broadcaster.SendDrirectStimuliToTarget(owner, gamedataStimType.ReprimandFinalWarning, owner);
    };
    if Equals(evt.reprimandInstructions, EReprimandInstructions.TAKEOVER) {
      broadcaster.SendDrirectStimuliToTarget(owner, gamedataStimType.Reprimand, owner);
    };
  }

  private final func RecentReaction(behaviorName: gamedataOutput) -> Bool {
    let reactionData: ref<AIReactionData>;
    let simTime: Float = EngineTime.ToFloat(GameInstance.GetSimTime(this.GetOwner().GetGame()));
    let i: Int32 = 0;
    while i < ArraySize(this.m_reactionCache) {
      reactionData = this.m_reactionCache[i];
      if Equals(reactionData.reactionBehaviorName, behaviorName) && reactionData.recentReactionTimeStamp >= simTime {
        return true;
      };
      i += 1;
    };
    return false;
  }

  protected cb func OnSuspiciousObjectEvent(evt: ref<SuspiciousObjectEvent>) -> Bool {
    if evt.target.IsPlayer() {
      AIActionHelper.TryChangingAttitudeToHostile(this.GetOwner() as ScriptedPuppet, evt.target);
    };
  }

  private final func GetCombatTarget(source: wref<GameObject>, opt attacker: wref<Entity>) -> wref<GameObject> {
    let aiComponent: ref<AIHumanComponent>;
    let commandCombatTargetVariant: Variant;
    let threat: TrackedLocation;
    if IsDefined(attacker) {
      return attacker as GameObject;
    };
    aiComponent = (source as ScriptedPuppet).GetAIControllerComponent();
    if IsDefined(aiComponent) {
      commandCombatTargetVariant = aiComponent.GetBehaviorArgument(n"CommmandCombatTarget");
      if IsDefined(commandCombatTargetVariant) {
        return FromVariant<wref<GameObject>>(commandCombatTargetVariant);
      };
    };
    if source.GetTargetTrackerComponent().GetTopHostileThreat(false, threat) {
      return threat.entity as GameObject;
    };
    return null;
  }

  private final func IsSourceGrenade(stimEvent: ref<StimuliEvent>) -> Bool {
    return IsDefined(stimEvent.sourceObject as BaseGrenade);
  }

  private final func GetGrenadeInstigator(stimEvent: ref<StimuliEvent>) -> wref<GameObject> {
    return (stimEvent.sourceObject as BaseGrenade).GetUser();
  }

  private final func JoinSearchWithAlert(ownerPuppet: ref<ScriptedPuppet>, target: wref<GameObject>, timeToLive: Float) -> Void {
    this.TriggerAlerted(target);
    if !TargetTrackingExtension.HasHostileThreat(ownerPuppet) {
      this.LogInfo("HelpAlly - injected positional threat");
      TargetTrackingExtension.InjectThreat(ownerPuppet, target.GetWorldPosition(), timeToLive);
    };
  }

  private final func HelpAllyWithAlert(ownerPuppet: ref<ScriptedPuppet>, target: wref<GameObject>, timeToLive: Float) -> Void {
    this.JoinSearchWithAlert(ownerPuppet, target, timeToLive);
  }

  private final func HelpAlly(ally: wref<GameObject>, targetOfAlly: wref<GameObject>, onlyAlertNoThreat: Bool, opt dontTrySquad: Bool) -> Void {
    let threat: TrackedLocation;
    let ownerPuppet: ref<ScriptedPuppet> = this.GetOwnerPuppet();
    if !IsDefined(ally) {
      this.LogFailure("HelpAlly failure - no ally");
      return;
    };
    if Equals(this.m_reactionPreset.Type(), gamedataReactionPresetType.NoReaction) {
      this.LogFailure("HelpAlly failure - NoReaction reaction preset");
      return;
    };
    if IsDefined(targetOfAlly) && ally.GetTargetTrackerComponent().ThreatFromEntity(targetOfAlly, threat) {
      if IsDefined(threat.entity) && AIActionHelper.TryChangingAttitudeToHostile(ownerPuppet, threat.entity as GameObject) {
        if onlyAlertNoThreat {
          this.HelpAllyWithAlert(ownerPuppet, targetOfAlly, 0.50);
          this.LogSuccess("HelpAlly success - alerted about target");
        } else {
          TargetTrackingExtension.InjectThreat(ownerPuppet, threat);
          this.LogSuccess("HelpAlly success - added target threat");
        };
      };
      return;
    };
    if !ScriptedPuppet.IsActive(ally) {
      this.HelpAllyWithAlert(ownerPuppet, ally, 5.00);
      this.LogSuccess("HelpAlly success - alerted about dead ally");
      return;
    };
    if !dontTrySquad && IsDefined(targetOfAlly) && this.IsTargetInFront(ally) && this.IsSquadMateInDanger() && AIActionHelper.TryChangingAttitudeToHostile(ownerPuppet, targetOfAlly) {
      this.HelpAllyWithAlert(ownerPuppet, targetOfAlly, 5.00);
      this.LogSuccess("HelpAlly success - alerted about target (ally reacting to intruder)");
      return;
    };
    this.LogFailure("HelpAlly failure");
  }

  private final func HelpPlayer(enemy: wref<GameObject>) -> Void {
    if !IsDefined(enemy) {
      this.LogFailure("HelpPlayer failure - no enemy");
      return;
    };
    if Equals(this.m_reactionPreset.Type(), gamedataReactionPresetType.NoReaction) {
      this.LogFailure("HelpPlayer failure - NoReaction reaction preset");
      return;
    };
    if AIActionHelper.TryStartCombatWithTarget(this.GetOwnerPuppet(), enemy) {
      this.LogSuccess("HelpPlayer success - added target threat");
      return;
    };
    this.LogFailure("HelpPlayer failure");
  }

  private final func ReactToSecurityOutput(evt: ref<SecuritySystemOutput>) -> Void {
    let deviceNotifier: ref<GameObject>;
    let trespasser: wref<GameObject>;
    if !this.IsEnabled() {
      return;
    };
    if Equals(evt.GetOriginalInputEvent().GetNotificationType(), ESecurityNotificationType.DEVICE_DESTROYED) && NotEquals(evt.GetCachedSecurityState(), ESecuritySystemState.COMBAT) {
      deviceNotifier = evt.GetOriginalInputEvent().GetNotifierHandle().GetOwnerEntityWeak() as GameObject;
      StimBroadcasterComponent.SendStimDirectly(deviceNotifier, gamedataStimType.ProjectileDistraction, this.GetOwner());
      return;
    };
    if !evt.GetSecurityStateChanged() && this.ReflectSecSysStateToHLS(evt.GetCachedSecurityState()) {
      return;
    };
    trespasser = evt.GetOriginalInputEvent().GetWhoBreached();
    switch evt.GetCachedSecurityState() {
      case ESecuritySystemState.COMBAT:
        if Equals(evt.GetBreachOrigin(), EBreachOrigin.LOCAL) && IsDefined(trespasser) {
          if StatusEffectSystem.ObjectHasStatusEffectWithTag(this.GetOwner(), n"LoreAnim") {
            this.m_cacheSecuritySysOutput = evt;
          } else {
            this.TriggerCombat(trespasser);
          };
        } else {
          if !IsDefined(trespasser) || IsDefined(trespasser) && trespasser.IsPlayer() {
            this.TriggerAlerted(trespasser);
          };
        };
        break;
      case ESecuritySystemState.ALERTED:
        if !IsDefined(trespasser) || IsDefined(trespasser) && trespasser.IsPlayer() {
          if Equals(evt.GetOriginalInputEvent().GetNotificationType(), ESecurityNotificationType.ALARM) {
            if Equals(evt.GetOriginalInputEvent().GetStimTypeTriggeredAlarm(), gamedataStimType.DeadBody) {
              this.m_isAlertedByDeadBody = true;
            } else {
              this.m_stolenVehicle = evt.GetOriginalInputEvent().GetNotifierHandle().GetOwnerEntityWeak() as VehicleObject;
            };
          };
          this.TriggerAlerted(trespasser);
        };
        break;
      default:
    };
  }

  private final func ReflectSecSysStateToHLS(securityState: ESecuritySystemState) -> Bool {
    switch securityState {
      case ESecuritySystemState.COMBAT:
        if Equals(this.m_highLevelState, gamedataNPCHighLevelState.Combat) {
          return true;
        };
        return false;
      case ESecuritySystemState.ALERTED:
        if Equals(this.m_highLevelState, gamedataNPCHighLevelState.Alerted) {
          return true;
        };
        return false;
      case ESecuritySystemState.SAFE:
        if Equals(this.m_highLevelState, gamedataNPCHighLevelState.Relaxed) {
          return true;
        };
        return false;
      default:
        return false;
    };
  }

  private final func TriggerAlerted(opt instigator: wref<GameObject>) -> Void {
    let ownerPuppet: ref<ScriptedPuppet> = this.GetOwnerPuppet();
    if !ownerPuppet.GetSecuritySystem().IsReprimandOngoing() && Equals(ownerPuppet.GetHighLevelStateFromBlackboard(), gamedataNPCHighLevelState.Relaxed) && !ownerPuppet.IsCharacterCivilian() && !ownerPuppet.IsCharacterChildren() {
      NPCPuppet.ChangeHighLevelState(this.GetOwner(), gamedataNPCHighLevelState.Alerted);
      if IsDefined(instigator) {
        this.m_recentAlertObject = instigator;
        this.m_recentAlertTimeStamp = EngineTime.ToFloat(GameInstance.GetSimTime(this.GetOwner().GetGame())) + TweakDBInterface.GetFloat(t"AIGeneralSettings.recentAlertValidTimeStamp", 20.00);
      };
    };
  }

  private final func TriggerCombat(trespasser: wref<GameObject>) -> Void {
    let broadcaster: ref<StimBroadcasterComponent>;
    let ownerPuppet: ref<ScriptedPuppet> = this.GetOwnerPuppet();
    if ownerPuppet.IsCharacterCivilian() {
      broadcaster = trespasser.GetStimBroadcasterComponent();
      if IsDefined(broadcaster) {
        broadcaster.SendDrirectStimuliToTarget(this.GetOwner(), gamedataStimType.SecurityBreach, this.GetOwner());
      };
    };
    AIActionHelper.TryStartCombatWithTarget(ownerPuppet, trespasser);
  }

  protected cb func OnReactionBehaviorStatus(evt: ref<ReactionBehaviorStatus>) -> Bool {
    switch evt.status {
      case AIbehaviorUpdateOutcome.IN_PROGRESS:
        if IsDefined(this.m_desiredReaction) {
          this.OnReactionStarted(evt.reactionData);
        } else {
          this.m_activeReaction = evt.reactionData;
        };
        break;
      default:
        this.OnReactionEnded();
    };
  }

  protected cb func OnEndLookatEvent(evt: ref<EndLookatEvent>) -> Bool {
    if !this.m_inReactionSequence {
      this.DeactiveLookAt(evt.repeat);
    };
  }

  protected cb func OnDisableUndeadAnimFeatureEvent(evt: ref<DisableUndeadAnimFeatureEvent>) -> Bool {
    let undeadAnimFeature: ref<AnimFeature_Undead> = new AnimFeature_Undead();
    undeadAnimFeature.active = false;
    AnimationControllerComponent.ApplyFeatureToReplicate(this.GetOwner(), n"Undead", undeadAnimFeature);
  }

  protected cb func OnTerminateReactionLookatEvent(evt: ref<TerminateReactionLookatEvent>) -> Bool {
    this.DeactiveLookAt();
  }

  protected cb func OnRepeatLookatEvent(evt: ref<RepeatLookatEvent>) -> Bool {
    this.m_lookatRepeat = false;
    if this.m_playerProximity && !this.m_inReactionSequence {
      this.TriggerFacialLookAtReaction(false, true);
    };
  }

  protected cb func OnEventReceived(stimEvent: ref<StimuliEvent>) -> Bool {
    if !this.IsStimuliEventValid(stimEvent) {
      return IsDefined(null);
    };
    this.HandleStimEventByTask(stimEvent);
  }

  protected cb func OnAIEvent(aiEvent: ref<AIEvent>) -> Bool {
    if Equals(aiEvent.name, n"ReprimandSuccessful") {
      this.GetOwnerPuppet().TriggerSecuritySystemNotification(this.m_activeReaction.stimTarget.GetWorldPosition(), this.m_activeReaction.stimTarget, ESecurityNotificationType.REPRIMAND_SUCCESSFUL);
    };
    if Equals(aiEvent.name, n"TriggerCombatReaction") {
      this.TriggerPendingReaction();
      this.m_inPendingBehavior = false;
    };
    if Equals(aiEvent.name, n"TriggerPendingReaction") {
      this.TriggerPendingReaction();
      this.m_inPendingBehavior = false;
    };
  }

  private final func Initialiaze() -> Void {
    this.m_delay = TweakDBInterface.GetVector2(t"AIGeneralSettings.reactionDelay", new Vector2(0.30, 0.70));
    let puppetBlackboard: ref<IBlackboard> = this.GetOwnerPuppet().GetPuppetStateBlackboard();
    if IsDefined(puppetBlackboard) {
      if puppetBlackboard.GetBool(GetAllBlackboardDefs().PuppetState.InPendingBehavior) {
        this.m_inPendingBehavior = true;
      };
      this.m_pendingBehaviorCb = puppetBlackboard.RegisterListenerBool(GetAllBlackboardDefs().PuppetState.InPendingBehavior, this, n"OnPendingBehaviorChanged");
    };
  }

  private final func CacheEvent(stimData: ref<StimEventTaskData>) -> Void {
    let stimEvent: ref<StimuliEvent> = stimData.cachedEvt;
    if ArraySize(this.m_stimuliCache) > 0 {
      if !this.IsEventDuplicated(stimEvent) {
        if ArraySize(this.m_stimuliCache) > 4 {
          ArrayErase(this.m_stimuliCache, 0);
        };
        stimData.id = Cast<Uint32>(ArraySize(this.m_stimuliCache));
        ArrayPush(this.m_stimuliCache, stimData);
      };
    } else {
      stimData.id = Cast<Uint32>(ArraySize(this.m_stimuliCache));
      ArrayPush(this.m_stimuliCache, stimData);
    };
  }

  private final func CacheReaction(reactionData: ref<AIReactionData>) -> Void {
    if ArraySize(this.m_reactionCache) > 0 {
      if ArraySize(this.m_reactionCache) > 4 {
        ArrayErase(this.m_reactionCache, 0);
      };
      reactionData.recentReactionTimeStamp = EngineTime.ToFloat(GameInstance.GetSimTime(this.GetOwner().GetGame())) + TweakDBInterface.GetFloat(t"AIGeneralSettings.recentReactionValidTimeStamp", 120.00);
      ArrayPush(this.m_reactionCache, reactionData);
    } else {
      reactionData.recentReactionTimeStamp = EngineTime.ToFloat(GameInstance.GetSimTime(this.GetOwner().GetGame())) + TweakDBInterface.GetFloat(t"AIGeneralSettings.recentReactionValidTimeStamp", 120.00);
      ArrayPush(this.m_reactionCache, reactionData);
    };
  }

  private final func IsEventDuplicated(stimEvent: ref<StimuliEvent>) -> Bool {
    let i: Int32 = 0;
    while i < ArraySize(this.m_stimuliCache) {
      if this.IsDuplicate(stimEvent, this.m_stimuliCache[i].cachedEvt) {
        return true;
      };
      i += 1;
    };
    return false;
  }

  private final func IsDuplicate(stimEvent: ref<StimuliEvent>, cacheStim: ref<StimuliEvent>) -> Bool {
    if stimEvent.sourceObject == cacheStim.sourceObject && Equals(stimEvent.GetStimType(), cacheStim.GetStimType()) {
      return true;
    };
    return false;
  }

  protected cb func OnStimThresholdEvent(thresholdEvent: ref<StimThresholdEvent>) -> Bool {
    let delayEvent: ref<StimThresholdEvent>;
    if thresholdEvent.reset {
      this.m_currentStimThresholdValue = 0;
      this.m_timeStampThreshold = 0.00;
    } else {
      if this.m_currentStimThresholdValue == 0 && this.m_timeStampThreshold == 0.00 {
        this.m_timeStampThreshold = EngineTime.ToFloat(GameInstance.GetSimTime(this.GetOwner().GetGame())) + thresholdEvent.timeThreshold;
        delayEvent = new StimThresholdEvent();
        delayEvent.reset = true;
        GameInstance.GetDelaySystem(this.GetOwnerPuppet().GetGame()).DelayEvent(this.GetOwner(), delayEvent, thresholdEvent.timeThreshold);
      };
      this.m_currentStimThresholdValue += 1;
    };
  }

  protected cb func OnStealthStimThresholdEvent(thresholdEvent: ref<StealthStimThresholdEvent>) -> Bool {
    let delayEvent: ref<StealthStimThresholdEvent>;
    if thresholdEvent.reset {
      this.m_currentStealthStimThresholdValue = 0;
      this.m_stealthTimeStampThreshold = 0.00;
    } else {
      if this.m_currentStealthStimThresholdValue == 0 && this.m_stealthTimeStampThreshold == 0.00 {
        this.m_stealthTimeStampThreshold = EngineTime.ToFloat(GameInstance.GetSimTime(this.GetOwner().GetGame())) + thresholdEvent.timeThreshold;
        delayEvent = new StealthStimThresholdEvent();
        delayEvent.reset = true;
        GameInstance.GetDelaySystem(this.GetOwnerPuppet().GetGame()).DelayEvent(this.GetOwner(), delayEvent, thresholdEvent.timeThreshold);
      };
      this.m_currentStealthStimThresholdValue += 1;
    };
  }

  public final func GetIgnoreList() -> array<EntityID> {
    return this.m_ignoreList;
  }

  private final func IsStimuliEventValid(stimEvent: ref<StimuliEvent>) -> Bool {
    let owner: ref<GameObject>;
    if stimEvent.sourceObject == null || Vector4.IsZero(stimEvent.sourcePosition) {
      return false;
    };
    owner = this.GetOwner();
    if stimEvent.sourceObject == owner {
      return false;
    };
    if Equals(stimEvent.GetStimType(), gamedataStimType.Invalid) {
      return false;
    };
    if owner.IsPlayer() {
      return false;
    };
    return true;
  }

  private final func ShouldEventBeProcessed(stimEvent: ref<StimuliEvent>) -> Bool {
    if StimFilters.IsForTheDead(stimEvent.GetStimType()) {
      return false;
    };
    if !ScriptedPuppet.IsActive(this.GetOwner()) {
      this.LogFailure("owner inactive");
      return false;
    };
    if !stimEvent.stimRecord.IsReactionStim() {
      this.LogFailure("NOT reaction stim");
      return false;
    };
    if Equals(this.m_reactionPreset.Type(), gamedataReactionPresetType.NoReaction) {
      this.LogFailure("NoReaction reaction preset");
      return false;
    };
    if this.m_puppetReactionBlackboard.GetBool(GetAllBlackboardDefs().PuppetReaction.blockReactionFlag) {
      this.LogFailure("PuppetReaction.blockReactionFlag");
      return false;
    };
    return true;
  }

  private final func ShouldVisualStimBeProcessed(stimEvent: ref<StimuliEvent>, reactionData: ref<AIReactionData>) -> Bool {
    let owner: ref<GameObject>;
    if stimEvent.sourceObject.IsPuppet() {
      if this.IsTargetVisible(stimEvent.sourceObject) || this.IsTargetVisibleBeyondSenses(stimEvent, reactionData) {
        return true;
      };
      this.LogFailure("stim source not visible");
      return false;
    };
    if !this.IsTargetInFront(stimEvent.sourceObject) {
      this.LogFailure("non-puppet stim source behind");
      return false;
    };
    if !this.IsTargetClose(stimEvent.sourceObject, this.m_crowdAimingReactionDistance) {
      this.LogFailure("non-puppet stim source too far");
      return false;
    };
    owner = this.GetOwner();
    if GameInstance.GetWorkspotSystem(owner.GetGame()).IsActorInWorkspot(owner) {
      if StatusEffectSystem.ObjectHasStatusEffectWithTag(owner, n"Braindance") || StatusEffectSystem.ObjectHasStatusEffectWithTag(owner, n"Sleep") {
        this.LogFailure("owner sleeping or in braindance");
        return false;
      };
    };
    return true;
  }

  private final func ShouldAudioStimBeProcessed(stimEvent: ref<StimuliEvent>) -> Bool {
    if this.IsTargetVisible(stimEvent.sourceObject) {
      return true;
    };
    if !this.GetOwnerPuppet().GetSensesComponent().IsHearingEnabled() {
      this.LogFailure("owner hearing disabled");
      return false;
    };
    if StatusEffectSystem.ObjectHasStatusEffectWithTag(this.GetOwner(), n"HearingImpaired") && !this.CheckHearingDistance(stimEvent) {
      this.LogFailure("owner hearing impaired");
      return false;
    };
    return true;
  }

  private final func ShouldFriendlyStimBeProcessed(stimEvent: ref<StimuliEvent>, investigateData: stimInvestigateData) -> Bool {
    let allyPuppet: ref<ScriptedPuppet>;
    let allyReactionComponent: ref<ReactionManagerComponent>;
    let broadcaster: ref<StimBroadcasterComponent>;
    let isSourceGrenade: Bool;
    let ownerPuppet: ref<ScriptedPuppet>;
    let ownerSecuritySystem: ref<SecuritySystemControllerPS>;
    let source: wref<GameObject>;
    let sourceNotAlly: Bool;
    let targetOfSource: wref<GameObject>;
    let threatenedByNPCGrenade: Bool;
    let threatenedByPlayer: Bool;
    let stimType: gamedataStimType = stimEvent.GetStimType();
    let onlyAlertNoThreat: Bool = false;
    if stimEvent.IsTagInStimuli(n"IgnoreFriendly") && !stimEvent.sourceObject.IsDevice() {
      this.LogFailure("IgnoreFriendly");
      return false;
    };
    if Equals(this.m_highLevelState, gamedataNPCHighLevelState.Combat) && !stimEvent.IsTagInStimuli(n"AllowFriendlyInCombat") {
      this.LogFailure("NOT AllowFriendlyInCombat");
      return false;
    };
    if !StimFilters.CanTriggerAllyHelp(stimType) {
      return true;
    };
    isSourceGrenade = this.IsSourceGrenade(stimEvent);
    source = isSourceGrenade ? this.GetGrenadeInstigator(stimEvent) : stimEvent.sourceObject;
    targetOfSource = isSourceGrenade ? this.GetCombatTarget(source) : this.GetCombatTarget(source, investigateData.attackInstigator);
    threatenedByNPCGrenade = isSourceGrenade && this.ShouldReactToNPCGrenade(stimEvent.sourceObject as BaseGrenade);
    sourceNotAlly = !this.IsTargetSquadAlly(source) && !this.IsTargetRecentSquadAlly(source) && !this.IsTargetInSameSecuritySystem(source) && !this.ShouldHelpTargetFromSameAttitudeGroup(source, targetOfSource);
    threatenedByPlayer = this.ShouldHelpCausePlayerGotTooClose(targetOfSource, onlyAlertNoThreat);
    if sourceNotAlly && !threatenedByNPCGrenade && !threatenedByPlayer {
      this.LogFailure("stim source is not ally");
      return false;
    };
    this.LogInfo("HelpAlly attempt - friendly stim");
    this.HelpAlly(source, targetOfSource, onlyAlertNoThreat);
    allyPuppet = source as ScriptedPuppet;
    ownerPuppet = this.GetOwnerPuppet();
    if IsDefined(allyPuppet) && IsDefined(ownerPuppet) {
      allyReactionComponent = allyPuppet.GetStimReactionComponent();
      ownerSecuritySystem = ownerPuppet.GetSecuritySystem();
      if IsDefined(allyReactionComponent) && IsDefined(ownerSecuritySystem) {
        if ownerSecuritySystem.IsReprimandOngoing() && IsDefined(ownerSecuritySystem.GetReprimandPerformer()) || Equals(allyReactionComponent.GetReactionPreset().Type(), gamedataReactionPresetType.Civilian_Guard) || Equals(allyReactionComponent.GetReactionPreset().Type(), gamedataReactionPresetType.Civilian_Grabbable) || Equals(allyReactionComponent.GetActiveReactionData().reactionBehaviorName, gamedataOutput.BackOff) {
          broadcaster = this.GetPlayerSystem().GetLocalPlayerControlledGameObject().GetStimBroadcasterComponent();
          if IsDefined(broadcaster) {
            broadcaster.SendDrirectStimuliToTarget(this.GetOwner(), gamedataStimType.SoundDistraction, this.GetOwner());
            this.LogSuccess("broadcasted SoundDistraction to owner");
          };
          return false;
        };
      };
    };
    return StimFilters.CanProcessPastAllyHelp(stimType);
  }

  private final func ShouldNeutralStimBeProcessed(stimEvent: ref<StimuliEvent>, investigateData: stimInvestigateData) -> Bool {
    let isSourceGrenade: Bool;
    let onlyAlertNoThreat: Bool;
    let source: wref<GameObject>;
    let targetOfSource: wref<GameObject>;
    let threatenedByNPCGrenade: Bool;
    let stimType: gamedataStimType = stimEvent.GetStimType();
    if Equals(this.m_highLevelState, gamedataNPCHighLevelState.Combat) || !StimFilters.CanTriggerNeutralHelp(stimType) {
      return true;
    };
    isSourceGrenade = this.IsSourceGrenade(stimEvent);
    source = isSourceGrenade ? this.GetGrenadeInstigator(stimEvent) : stimEvent.sourceObject;
    targetOfSource = isSourceGrenade ? this.GetCombatTarget(source) : this.GetCombatTarget(source, investigateData.attackInstigator);
    threatenedByNPCGrenade = isSourceGrenade && this.ShouldReactToNPCGrenade(stimEvent.sourceObject as BaseGrenade);
    if this.ShouldHelpCausePlayerGotTooClose(targetOfSource, onlyAlertNoThreat) || threatenedByNPCGrenade {
      this.LogInfo("HelpAlly attempt - neutral stim");
      this.HelpAlly(source, targetOfSource, onlyAlertNoThreat, true);
      return true;
    };
    return true;
  }

  private final func ShouldHostileStimBeProcessed(stimEvent: ref<StimuliEvent>, investigateData: stimInvestigateData) -> Bool {
    let isSourceGrenade: Bool;
    let onlyAlertNoThreat: Bool;
    let source: wref<GameObject>;
    let targetOfSource: wref<GameObject>;
    let threatenedByNPCGrenade: Bool;
    let stimType: gamedataStimType = stimEvent.GetStimType();
    if Equals(this.m_highLevelState, gamedataNPCHighLevelState.Combat) || !StimFilters.CanTriggerEnemyHostility(stimType) {
      return true;
    };
    isSourceGrenade = this.IsSourceGrenade(stimEvent);
    source = isSourceGrenade ? this.GetGrenadeInstigator(stimEvent) : stimEvent.sourceObject;
    targetOfSource = isSourceGrenade ? this.GetCombatTarget(source) : this.GetCombatTarget(source, investigateData.attackInstigator);
    threatenedByNPCGrenade = isSourceGrenade && this.ShouldReactToNPCGrenade(stimEvent.sourceObject as BaseGrenade);
    if this.ShouldHelpCausePlayerGotTooClose(targetOfSource, onlyAlertNoThreat) || threatenedByNPCGrenade {
      this.LogInfo("HelpPlayer attempt - hostile stim");
      this.HelpPlayer(source);
      return true;
    };
    return true;
  }

  private final func ShouldStimBeProcessed(stimEvent: ref<StimuliEvent>, delayed: Bool) -> Bool {
    let aiComponent: ref<AIHumanComponent>;
    let attackInstigator: wref<Entity>;
    let canIgnoreOnlyDueToDelay: Bool;
    let canIgnorePlayerCombatStim: Bool;
    let context: ScriptExecutionContext;
    let delayStimEvent: ref<DelayStimEvent>;
    let delaySystem: ref<DelaySystem>;
    let device: ref<Device>;
    let friendlyStim: Bool;
    let investigateData: stimInvestigateData;
    let investigators: array<EntityID>;
    let isCooldownActiveOnStim: Bool;
    let reevaluateDetectionOverwriteEvent: ref<ReevaluateDetectionOverwriteEvent>;
    let source: wref<GameObject>;
    let stimType: gamedataStimType;
    let owner: ref<GameObject> = this.GetOwner();
    let ownerPuppet: ref<ScriptedPuppet> = this.GetOwnerPuppet();
    let reactionData: ref<AIReactionData> = this.m_desiredReaction;
    if !IsDefined(reactionData) {
      reactionData = this.m_activeReaction;
    };
    stimType = stimEvent.GetStimType();
    if !StimFilters.Debug_IsAllowed(stimType) {
      this.LogFailure("disabled by debug");
      return false;
    };
    if Equals(stimType, gamedataStimType.MeleeAttack) && WeaponObject.IsFists(GameObject.GetActiveWeapon(stimEvent.sourceObject).GetItemID()) {
      this.LogFailure("ignored for fists weapon");
      return false;
    };
    if Equals(stimType, gamedataStimType.WeaponDisplayed) && !this.CanAskToHolsterWeapon() {
      this.LogFailure("NOT CanAskToHolsterWeapon");
      return false;
    };
    if stimEvent.IsCategory(n"Security") && stimEvent.sourceObject.IsPuppet() && !owner.IsTargetTresspassingMyZone(stimEvent.sourceObject) {
      this.LogFailure("stim source is NOT trespassing security zone");
      return false;
    };
    if StimFilters.ShouldBeInPublicZone(stimType) && !this.IsPlayerInZone(gamePSMZones.Public) {
      this.LogFailure("player is NOT in public zone");
      return false;
    };
    if !stimEvent.IsTagInStimuli(n"Direct") && !stimEvent.IsPurelyDirect() {
      if stimEvent.IsVisual() && !this.ShouldVisualStimBeProcessed(stimEvent, reactionData) || stimEvent.IsAudio() && !this.ShouldAudioStimBeProcessed(stimEvent) {
        return false;
      };
    };
    if StimFilters.IsIgnoredWhileGrappled(stimType) && ScriptedPuppet.IsBeingGrappled(ownerPuppet) {
      this.LogFailure("ignored while owner is grappled");
      return false;
    };
    if Equals(stimType, gamedataStimType.AimingAt) && this.m_reactionPreset.IsAggressive() && this.IsReactionAvailableInPreset(gamedataStimType.AimingAt) {
      delaySystem = GameInstance.GetDelaySystem(owner.GetGame());
      delaySystem.CancelDelay(this.m_delayDetectionEventID);
      reevaluateDetectionOverwriteEvent = new ReevaluateDetectionOverwriteEvent();
      reevaluateDetectionOverwriteEvent.target = stimEvent.sourceObject;
      this.m_delayDetectionEventID = delaySystem.DelayEvent(owner, reevaluateDetectionOverwriteEvent, 0.10);
      delaySystem.CancelDelay(this.m_delayStimEventID);
      delayStimEvent = new DelayStimEvent();
      delayStimEvent.stimEvent = stimEvent;
      this.m_delayStimEventID = delaySystem.DelayEvent(owner, delayStimEvent, 0.35);
      this.LogSuccess("detection reevaluation and aim reaction delayed");
      return false;
    };
    if stimEvent.IsTagInStimuli(n"Stealth") && !ReactionManagerComponent.ReactOnPlayerStealthStim(owner, stimEvent.sourceObject) {
      this.LogFailure("NOT ReactOnPlayerStealthStim");
      return false;
    };
    if stimEvent.IsTagInStimuli(n"Security") && !ownerPuppet.IsConnectedToSecuritySystem() {
      this.LogFailure("NOT IsConnectedToSecuritySystem");
      return false;
    };
    investigateData = stimEvent.stimInvestigateData;
    attackInstigator = investigateData.attackInstigator;
    if stimEvent.IsTagInStimuli(n"PlayerOnly") && !stimEvent.sourceObject.IsDevice() {
      if !IsDefined(attackInstigator) && !stimEvent.sourceObject.IsPlayer() || IsDefined(attackInstigator) && !(attackInstigator as GameObject).IsPlayer() {
        this.LogFailure("PlayerOnly constraints failed");
        return false;
      };
    };
    if this.IsSourceGrenade(stimEvent) {
      source = this.GetGrenadeInstigator(stimEvent);
    } else {
      if StatusEffectSystem.ObjectHasStatusEffect(stimEvent.sourceObject, t"BaseStatusEffect.ImpactedThrownNPC") {
        source = attackInstigator as PlayerPuppet;
      };
    };
    if !IsDefined(source) {
      source = stimEvent.sourceObject;
    };
    friendlyStim = this.SourceAttitude(source, EAIAttitude.AIA_Friendly);
    if !friendlyStim && StimFilters.ShouldBeFriendly(stimType) {
      this.LogFailure("non-friendly stim source");
      return false;
    };
    if friendlyStim && !this.ShouldFriendlyStimBeProcessed(stimEvent, investigateData) {
      return false;
    };
    if this.SourceAttitude(source, EAIAttitude.AIA_Neutral) && !this.ShouldNeutralStimBeProcessed(stimEvent, investigateData) {
      return false;
    };
    if this.SourceAttitude(source, EAIAttitude.AIA_Hostile) && !this.ShouldHostileStimBeProcessed(stimEvent, investigateData) {
      return false;
    };
    if this.InvestigatingAlready(stimEvent) {
      this.LogFailure("InvestigatingAlready");
      return false;
    };
    if this.IsSameStimulus(stimEvent) && this.IsSameSourceObject(stimEvent) && StimFilters.IsIgnoredFromSameSource(stimType) {
      this.LogFailure("IsIgnoredFromSameSource");
      return false;
    };
    if IsDefined(reactionData) && this.IsLowerPriority(stimEvent, reactionData.stimPriority) {
      this.LogFailure("lower priority compared to current reaction");
      return false;
    };
    if ArrayContains(this.m_ignoreList, stimEvent.sourceObject.GetEntityID()) {
      this.LogFailure("stim source ignored");
      return false;
    };
    if GameObject.IsCooldownActive(owner, EnumValueToName(n"gamedataStimType", Cast<Int64>(EnumInt(stimType)))) {
      this.LogFailure("stim cooldown active");
      return false;
    };
    if Equals(stimType, gamedataStimType.AreaEffect) && !this.m_inPendingBehavior && !ownerPuppet.IsCharacterCivilian() {
      this.LogFailure("special AreaEffect check failed");
      return false;
    };
    isCooldownActiveOnStim = IsDefined(this.m_desiredReaction) && Equals(this.m_desiredReaction.stimType, stimType) && GameObject.IsCooldownActive(owner, StringToName("ovefloodCooldown" + EnumValueToString("gamedataStimType", Cast<Int64>(EnumInt(stimType)))));
    if isCooldownActiveOnStim {
      this.LogFailure("stim overflood cooldown active");
      return false;
    };
    if Equals(stimType, gamedataStimType.GrenadeLanded) && !this.ShouldTriggerGrenadeDodgeBehavior(stimEvent) {
      this.LogFailure("NOT ShouldTriggerGrenadeDodgeBehavior");
      return false;
    };
    if Equals(stimType, gamedataStimType.DeviceExplosion) && !this.CanTriggerPanicInCombat(stimEvent) {
      this.LogFailure("NOT CanTriggerPanicInCombat");
      return false;
    };
    if ownerPuppet.IsPrevention() && !this.ShouldPreventionReact(stimEvent) {
      this.LogFailure("NOT ShouldPreventionReact");
      return false;
    };
    if StimFilters.ShouldBeDetected(stimType) && !this.IsTargetDetected(stimEvent.sourceObject) {
      this.LogFailure("stim source is not detected");
      return false;
    };
    if Equals(stimType, gamedataStimType.Distract) {
      device = stimEvent.sourceObject as Device;
      investigators = device.GetDevicePS().GetWillingInvestigators();
      if !ArrayContains(investigators, owner.GetEntityID()) {
        if this.IsTargetInFront(stimEvent.sourceObject) && !ownerPuppet.IsInvestigating() && ArraySize(investigators) != 0 {
          this.LogSuccess("lookat activated");
          this.ActivateReactionLookAt(stimEvent.sourceObject, true, false, 1.00, true);
        };
        this.LogFailure("no further investigation required");
        return false;
      };
    };
    if Equals(stimType, gamedataStimType.Explosion) {
      aiComponent = ownerPuppet.GetAIControllerComponent();
      if IsDefined(aiComponent) && FromVariant<wref<GameObject>>(aiComponent.GetBehaviorArgument(n"StimTarget")) == reactionData.stimTarget && AIHumanComponent.GetScriptContext(ownerPuppet, context) {
        ScriptExecutionContext.SetArgumentObject(context, n"StimTarget", null);
        ScriptExecutionContext.GetTweakActionSystem(context).ForceDirty(context, t"AIActionTarget.StimTarget");
      };
    };
    if this.ShouldIgnoreCombatStim(stimType, investigateData.attackInstigator as ScriptedPuppet, stimEvent.sourceObject as ScriptedPuppet, stimEvent.sourcePosition, !delayed, canIgnoreOnlyDueToDelay, canIgnorePlayerCombatStim, true) {
      if canIgnoreOnlyDueToDelay {
        delaySystem = GameInstance.GetDelaySystem(owner.GetGame());
        delayStimEvent = new DelayStimEvent();
        delayStimEvent.stimEvent = stimEvent;
        delayStimEvent.fullEventPipeline = true;
        delaySystem.DelayEvent(owner, delayStimEvent, 0.25);
        this.LogFailure("combat stim delayed");
        return false;
      };
      this.LogFailure("combat stim explicitely ignored");
      return false;
    };
    if this.HasCombatTarget() {
      if this.CanStimInterruptCombat(stimEvent, canIgnorePlayerCombatStim) {
        ScriptedPuppet.SendActionSignal(ownerPuppet, n"GracefulCombatInterruption", 2.00);
        this.m_inPendingBehavior = true;
        this.LogInfo("GracefulCombatInterruption");
      } else {
        if this.ShouldUpdateThreatPosition(stimEvent) {
          ownerPuppet.GetTargetTrackerComponent().AddThreat(stimEvent.sourceObject, true, stimEvent.sourceObject.GetWorldPosition(), 1.00, -1.00, false);
          this.LogInfo("updating threat position");
        };
        this.LogFailure("NOT CanStimInterruptCombat");
        return false;
      };
    };
    return true;
  }

  private final func ProcessStimParams(stimEvent: ref<StimuliEvent>) -> StimParams {
    let stimParams: StimParams;
    let owner: ref<GameObject> = this.GetOwner();
    let rules: array<wref<Rule_Record>> = this.GetRules();
    let reactionOutput: ReactionOutput = this.GetReactionOutput(stimEvent.GetStimType(), rules);
    if GameInstance.GetWorkspotSystem(owner.GetGame()).IsActorInWorkspot(owner) {
      reactionOutput.startedInWorkspot = true;
      if this.GetOwnerPuppet().IsCharacterCivilian() {
        reactionOutput.workspotReaction = GameInstance.GetWorkspotSystem(owner.GetGame()).IsReactionAvailable(owner, reactionOutput.workspotReactionType);
      };
    };
    stimParams.stimData = this.FillStimData(stimEvent);
    stimParams.reactionOutput = reactionOutput;
    return stimParams;
  }

  private func FillStimData(stimEvent: ref<StimuliEvent>) -> StimEventData {
    let data: StimEventData;
    data.source = stimEvent.sourceObject;
    data.stimType = stimEvent.GetStimType();
    return data;
  }

  private final const func IsReactionAvailableInPreset(stimTrigger: gamedataStimType) -> Bool {
    let reactionPresetOutput: ReactionOutput = this.GetReactionOutput(stimTrigger, this.GetRules());
    if NotEquals(reactionPresetOutput.reactionBehavior, gamedataOutput.Ignore) && NotEquals(reactionPresetOutput.reactionBehavior, gamedataOutput.Invalid) {
      return true;
    };
    return false;
  }

  private final func CreateFearThreashold() -> Void {
    let statSystem: ref<StatsSystem> = GameInstance.GetStatsSystem(this.GetOwner().GetGame());
    let statMod: ref<gameStatModifierData> = RPGManager.CreateStatModifier(gamedataStatType.PersonalityFear, gameStatModifierType.Additive, this.m_reactionPreset.FearThreshold());
    statSystem.AddModifier(Cast<StatsObjectID>(this.GetOwner().GetEntityID()), statMod);
  }

  private final func AddReactionValueToStatPool(reactionData: ref<AIReactionData>) -> Void {
    let ownerId: EntityID;
    let securitySystem: ref<SecuritySystemControllerPS>;
    let ownerPuppet: ref<ScriptedPuppet> = this.GetOwnerPuppet();
    let statPoolSystem: ref<StatPoolsSystem> = GameInstance.GetStatPoolsSystem(ownerPuppet.GetGame());
    if IsDefined(reactionData) && Equals(reactionData.reactionBehaviorName, gamedataOutput.TurnAt) && reactionData.stimTarget.IsPuppet() && this.IsTargetVisible(reactionData.stimTarget) {
      return;
    };
    securitySystem = ownerPuppet.GetSecuritySystem();
    if IsDefined(securitySystem) && !securitySystem.IsReprimandOngoing() {
      if reactionData.stimRecord.Fear() > 0.00 {
        ownerId = ownerPuppet.GetEntityID();
        statPoolSystem.RequestSettingModifierWithRecord(Cast<StatsObjectID>(ownerId), gamedataStatPoolType.Fear, gameStatPoolModificationTypes.Decay, t"BaseStatPools.ReactionValueDecay");
        statPoolSystem.RequestChangingStatPoolValue(Cast<StatsObjectID>(ownerId), gamedataStatPoolType.Fear, reactionData.stimRecord.Fear(), null, true, false);
      };
    };
  }

  private final const func GetRules() -> array<wref<Rule_Record>> {
    let rules: array<wref<Rule_Record>>;
    this.m_reactionPreset.Rules(rules);
    return rules;
  }

  private final const func GetReactionOutput(stimType: gamedataStimType, const rules: script_ref<array<wref<Rule_Record>>>) -> ReactionOutput {
    let reactionOutput: ReactionOutput;
    let i: Int32 = 0;
    while i < ArraySize(Deref(rules)) {
      if this.StimRule(Deref(rules)[i], stimType) {
        reactionOutput.reactionPriority = Deref(rules)[i].Output().Priority();
        reactionOutput.AIbehaviorPriority = Deref(rules)[i].Output().AIPriority();
        reactionOutput.reactionCooldown = Deref(rules)[i].Cooldown();
        reactionOutput.reactionBehavior = Deref(rules)[i].Output().Type();
        reactionOutput.workspotReactionType = Deref(rules)[i].WorkspotOutput();
        break;
      };
      reactionOutput.reactionBehavior = gamedataOutput.Ignore;
      i += 1;
    };
    return reactionOutput;
  }

  private final const func StimRule(rule: wref<Rule_Record>, stimType: gamedataStimType) -> Bool {
    if IsDefined(rule) && Equals(rule.Stimulus().Type(), stimType) {
      return true;
    };
    return false;
  }

  private final func ProcessReactionOutput(stimData: ref<StimEventTaskData>, stimParams: StimParams) -> Void {
    let driverInstigator: ref<GameObject>;
    let grenade: ref<BaseGrenade>;
    let isDuplicateReaction: Bool;
    let vehicle: ref<VehicleObject>;
    let owner: ref<GameObject> = this.GetOwner();
    let ownerPuppet: ref<ScriptedPuppet> = this.GetOwnerPuppet();
    let stimEvent: ref<StimuliEvent> = stimData.cachedEvt;
    let instigatorPuppet: ref<ScriptedPuppet> = stimEvent.sourceObject as ScriptedPuppet;
    let reactionData: ref<AIReactionData> = this.m_desiredReaction;
    if !IsDefined(reactionData) {
      reactionData = this.m_activeReaction;
    };
    grenade = stimEvent.sourceObject as BaseGrenade;
    if IsDefined(grenade) && this.HasCombatTarget() && Equals(stimEvent.GetStimType(), gamedataStimType.ProjectileDistraction) {
      stimEvent.SetStimType(gamedataStimType.GrenadeLanded);
      stimParams = this.ProcessStimParams(stimEvent);
    };
    if stimParams.reactionOutput.workspotReaction && GameInstance.GetWorkspotSystem(owner.GetGame()).SendReactionSignal(owner, stimParams.reactionOutput.workspotReactionType) {
      this.LogSuccess("sent workspot reaction " + NameToString(stimParams.reactionOutput.workspotReactionType));
      return;
    };
    vehicle = stimEvent.sourceObject as VehicleObject;
    if IsDefined(vehicle) {
      driverInstigator = VehicleComponent.GetDriver(owner.GetGame(), vehicle, vehicle.GetEntityID());
      instigatorPuppet = driverInstigator as ScriptedPuppet;
    };
    if ownerPuppet.IsPrevention() && StimFilters.IsGunshot(stimEvent.GetStimType()) && Equals(stimParams.reactionOutput.reactionBehavior, gamedataOutput.Intruder) && !instigatorPuppet.IsPlayer() {
      stimParams.reactionOutput.reactionBehavior = gamedataOutput.Investigate;
      stimParams.reactionOutput.reactionPriority = 8;
      stimParams.reactionOutput.AIbehaviorPriority = 4.70;
      this.LogInfo("prevention Intruder reaction decreased to Investigate for non-player gunshot");
    };
    if Equals(stimParams.reactionOutput.reactionBehavior, gamedataOutput.Panic) && ownerPuppet.IsBoss() {
      if Equals(stimEvent.GetStimType(), gamedataStimType.Explosion) {
        stimParams.reactionOutput.reactionBehavior = gamedataOutput.Intruder;
        stimParams.reactionOutput.reactionPriority = 10;
        stimParams.reactionOutput.AIbehaviorPriority = 4.90;
        this.LogInfo("boss Panic reaction decreased to Intruder");
      } else {
        if Equals(stimEvent.GetStimType(), gamedataStimType.GrenadeLanded) {
          this.TriggerAlerted();
          this.LogSuccess("triggered alerted for boss");
          return;
        };
        if Equals(stimEvent.GetStimType(), gamedataStimType.Hacked) || Equals(stimEvent.GetStimType(), gamedataStimType.DeviceExplosion) {
          this.TriggerAlerted();
        };
        stimParams.reactionOutput.reactionBehavior = gamedataOutput.Investigate;
        stimParams.reactionOutput.reactionPriority = 8;
        stimParams.reactionOutput.AIbehaviorPriority = 4.70;
        this.LogInfo("boss Panic reaction decreased to Investigate");
      };
    };
    this.LogInfo("processing reaction " + EnumValueToString("gamedataOutput", Cast<Int64>(EnumInt(stimParams.reactionOutput.reactionBehavior))));
    if Equals(stimParams.reactionOutput.reactionBehavior, gamedataOutput.Ignore) {
      this.LogFailure("reaction behavior is Ignore");
      return;
    };
    if Equals(stimParams.reactionOutput.reactionBehavior, gamedataOutput.LookAt) {
      if this.IsTargetInFront(stimEvent.sourceObject) || Equals(stimEvent.GetStimType(), gamedataStimType.Attention) {
        GameObject.PlayVoiceOver(owner, n"stlh_curious_grunt", n"Scripts:ProcessReactionOutput");
        this.ActivateReactionLookAt(stimEvent.sourceObject, true);
        this.LogSuccess("activated lookat");
        return;
      };
      stimParams.reactionOutput.reactionBehavior = gamedataOutput.TurnAt;
      this.TriggerBehaviorReaction(stimParams.reactionOutput, stimData, stimParams.stimData);
    };
    if Equals(stimEvent.GetStimType(), gamedataStimType.OpeningDoor) {
      if this.IsTargetInFront(stimEvent.sourceObject) {
        GameObject.PlayVoiceOver(owner, n"stlh_curious_grunt", n"Scripts:ProcessReactionOutput");
        this.ActivateReactionLookAt(stimEvent.sourceObject, true);
        this.LogSuccess("activated lookat for door");
        return;
      };
    };
    if (Equals(stimParams.reactionOutput.reactionBehavior, gamedataOutput.Intruder) || Equals(stimParams.reactionOutput.reactionBehavior, gamedataOutput.ProjectileInvestigate)) && !StatusEffectSystem.ObjectHasStatusEffectWithTag(owner, n"LoreAnim") {
      if IsDefined(driverInstigator) && this.TryTriggerCombatOrAlertedFromHostileStim(stimEvent, stimData, reactionData, driverInstigator) {
        return;
      };
      if GameInstance.GetWorkspotSystem(owner.GetGame()).IsActorInWorkspot(owner) && this.TryTriggerCombatOrAlertedFromHostileStim(stimEvent, stimData, reactionData, stimEvent.sourceObject) {
        return;
      };
      if this.IsSquadMateInDanger() && AIActionHelper.TryChangingAttitudeToHostile(ownerPuppet, stimEvent.sourceObject) {
        this.HelpAllyWithAlert(ownerPuppet, stimEvent.sourceObject, 5.00);
        this.LogSuccess("alerted about target (ally reacting to intruder)");
        return;
      };
    };
    if IsDefined(reactionData) && stimParams.reactionOutput.reactionPriority < reactionData.reactionPriority {
      this.LogFailure("lower reaction priority to current");
      return;
    };
    if IsDefined(this.m_pendingReaction) && stimParams.reactionOutput.reactionPriority < this.m_pendingReaction.reactionPriority {
      this.LogFailure("lower reaction priority to pending");
      return;
    };
    if IsDefined(this.m_activeReaction) && Equals(this.m_activeReaction.reactionBehaviorName, stimParams.reactionOutput.reactionBehavior) && NotEquals(this.m_activeReaction.reactionBehaviorName, gamedataOutput.DeviceInvestigate) {
      this.UpdateActiveReaction(stimParams.reactionOutput, stimEvent, stimParams.stimData, this.m_updateByActive);
      return;
    };
    isDuplicateReaction = IsDefined(reactionData) && IsDefined(this.m_desiredReaction) && Equals(reactionData.reactionBehaviorName, stimParams.reactionOutput.reactionBehavior) && GameObject.IsCooldownActive(owner, StringToName("ovefloodCooldown" + EnumValueToString("gamedataOutput", Cast<Int64>(EnumInt(this.m_desiredReaction.reactionBehaviorName)))));
    if isDuplicateReaction {
      this.LogFailure("reaction overflow cooldown");
      return;
    };
    this.TriggerBehaviorReaction(stimParams.reactionOutput, stimData, stimParams.stimData);
  }

  private final func UpdateActiveReaction(reaction: ReactionOutput, stimEvent: ref<StimuliEvent>, stimData: StimEventData, updateByActive: Bool) -> Void {
    let resetDesiredReactionData: ref<ResetReactionEvent>;
    let stimName: CName;
    let owner: ref<GameObject> = this.GetOwner();
    GameInstance.GetDelaySystem(owner.GetGame()).CancelDelay(this.m_resetReactionDataID);
    if updateByActive {
      this.m_desiredReaction = this.m_activeReaction;
    } else {
      this.m_desiredReaction = new AIReactionData();
      this.m_desiredReaction.reactionBehaviorName = reaction.reactionBehavior;
      this.m_desiredReaction.stimPriority = stimEvent.stimRecord.Priority().Type();
      this.m_desiredReaction.stimTarget = stimEvent.sourceObject;
      this.m_desiredReaction.stimSource = this.GetStimSource(stimEvent);
      this.m_desiredReaction.stimType = stimEvent.GetStimType();
      this.m_desiredReaction.stimRecord = stimEvent.stimRecord;
      this.m_desiredReaction.stimEventData = stimData;
      this.m_desiredReaction.stimPropagation = stimEvent.stimPropagation;
      this.m_desiredReaction.reactionPriority = reaction.reactionPriority;
      this.m_desiredReaction.stimInvestigateData = stimEvent.stimInvestigateData;
      this.m_desiredReaction.reactionBehaviorAIPriority = reaction.AIbehaviorPriority;
      this.m_desiredReaction.reactionCooldown = reaction.reactionCooldown;
      this.m_desiredReaction.initAnimInWorkspot = reaction.startedInWorkspot;
    };
    if Equals(this.m_desiredReaction.reactionBehaviorName, gamedataOutput.DeviceInvestigate) && !this.IsInList(this.m_investigationList, stimData) {
      ArrayPush(this.m_investigationList, stimData);
      this.LogInfo("added stim to investigation list");
    };
    this.UpdateStimSource();
    stimName = EnumValueToName(n"gamedataStimType", Cast<Int64>(EnumInt(this.m_desiredReaction.stimType)));
    if this.m_desiredReaction.reactionCooldown != 0.00 {
      GameObject.StartCooldown(owner, stimName, this.m_desiredReaction.reactionCooldown);
    };
    if !GameObject.IsCooldownActive(owner, n"ActiveReactionValueCooldown-" + stimName) && !this.GetOwnerPuppet().GetSecuritySystem().IsReprimandOngoing() {
      this.AddReactionValueToStatPool(this.m_desiredReaction);
      GameObject.StartCooldown(owner, n"ActiveReactionValueCooldown-" + stimName, 1.00);
    };
    resetDesiredReactionData = new ResetReactionEvent();
    resetDesiredReactionData.data = this.m_desiredReaction;
    this.m_resetReactionDataID = GameInstance.GetDelaySystem(owner.GetGame()).DelayEvent(owner, resetDesiredReactionData, 1.00);
    this.LogSuccess("updated active reaction " + EnumValueToString("gamedataOutput", Cast<Int64>(EnumInt(this.m_desiredReaction.reactionBehaviorName))));
  }

  private final func UpdateStimSource() -> Void {
    let updateStimSourceAIEvent: ref<StimuliEvent> = new StimuliEvent();
    updateStimSourceAIEvent.name = n"updateSource";
    this.GetOwner().QueueEvent(updateStimSourceAIEvent);
  }

  private func TriggerBehaviorReaction(reaction: ReactionOutput, stimTaskData: ref<StimEventTaskData>, stimData: StimEventData) -> Void {
    let exitEvent: ref<AIEvent>;
    let game: GameInstance;
    let reactionBehaviorOk: Bool;
    let stimEvent: ref<StimuliEvent>;
    let triggerAIEvent: ref<StimuliEvent>;
    let owner: ref<GameObject> = this.GetOwner();
    this.DeactiveLookAt();
    game = owner.GetGame();
    stimEvent = stimTaskData.cachedEvt;
    GameInstance.GetDelaySystem(game).CancelDelay(this.m_resetReactionDataID);
    this.m_desiredReaction = new AIReactionData();
    this.m_desiredReaction.reactionBehaviorName = reaction.reactionBehavior;
    this.m_desiredReaction.stimPriority = stimEvent.stimRecord.Priority().Type();
    this.m_desiredReaction.stimTarget = stimEvent.sourceObject;
    this.m_desiredReaction.stimType = stimEvent.GetStimType();
    this.m_desiredReaction.stimSource = this.GetStimSource(stimEvent);
    this.m_desiredReaction.stimRecord = stimEvent.stimRecord;
    this.m_desiredReaction.reactionPriority = reaction.reactionPriority;
    this.m_desiredReaction.stimInvestigateData = stimEvent.stimInvestigateData;
    this.m_desiredReaction.stimEventData = stimData;
    this.m_desiredReaction.reactionBehaviorAIPriority = reaction.AIbehaviorPriority;
    this.m_desiredReaction.reactionCooldown = reaction.reactionCooldown;
    this.m_desiredReaction.initAnimInWorkspot = reaction.startedInWorkspot;
    GameObject.StartCooldown(owner, StringToName("ovefloodCooldown" + EnumValueToString("gamedataStimType", Cast<Int64>(EnumInt(this.m_desiredReaction.stimType)))), this.m_ovefloodCooldown);
    GameObject.StartCooldown(owner, StringToName("ovefloodCooldown" + EnumValueToString("gamedataOutput", Cast<Int64>(EnumInt(this.m_desiredReaction.reactionBehaviorName)))), 0.50);
    triggerAIEvent = new StimuliEvent();
    triggerAIEvent.SetStimType(gamedataStimType.Invalid);
    if this.IsInPendingBehavior() {
      this.m_pendingReaction = this.m_desiredReaction;
      this.m_pendingReaction.validTillTimeStamp = EngineTime.ToFloat(GameInstance.GetSimTime(game)) + TweakDBInterface.GetFloat(t"AIGeneralSettings.pendingReactionValidTimeStamp", 10.00);
      this.m_desiredReaction = null;
      this.LogInfo("set reaction to pending");
      if VehicleComponent.IsMountedToVehicle(game, owner) {
        if owner.IsPrevention() && !PreventionSystem.IsChasingPlayer(this.GetOwner().GetGame()) && stimEvent.sourceObject.IsPlayer() {
          reactionBehaviorOk = Equals(reaction.reactionBehavior, gamedataOutput.Reprimand) || Equals(reaction.reactionBehavior, gamedataOutput.Investigate);
        } else {
          reactionBehaviorOk = Equals(reaction.reactionBehavior, gamedataOutput.Reprimand);
        };
        if reactionBehaviorOk {
          exitEvent = new AIEvent();
          exitEvent.name = n"ExitVehicle";
          owner.QueueEvent(exitEvent);
          this.LogInfo("queued ExitVehicle event");
        };
      };
    } else {
      triggerAIEvent.name = n"triggerReaction";
      reactionBehaviorOk = Equals(reaction.reactionBehavior, gamedataOutput.Flee) || Equals(reaction.reactionBehavior, gamedataOutput.Surrender) || Equals(reaction.reactionBehavior, gamedataOutput.WalkAway) || Equals(reaction.reactionBehavior, gamedataOutput.CallGuard);
      if IsDefined(this.m_activeReaction) && Equals(this.m_activeReaction.reactionBehaviorName, gamedataOutput.BodyInvestigate) && AISquadHelper.IsSignalActive(this.GetOwnerPuppet(), n"BodyInvestigationTicketReceived") {
        this.OnBodyInvestigated(new BodyInvestigatedEvent());
        this.LogInfo("triggered body investigated");
      };
      if this.FirstSquadMemberReaction() && !this.DelayReaction(stimEvent.GetStimType()) {
        owner.QueueEvent(triggerAIEvent);
        this.LogInfo("triggered reaction with NO delay");
      } else {
        this.m_delayReactionEventID = GameInstance.GetDelaySystem(game).DelayEvent(owner, triggerAIEvent, RandRangeF(0.20, 0.70));
        this.LogInfo("triggered reaction with delay");
      };
      if reactionBehaviorOk {
        NPCPuppet.ChangeHighLevelState(owner, gamedataNPCHighLevelState.Fear);
        AnimationControllerComponent.SetAnimWrapperWeightOnOwnerAndItems(owner, this.GetFearAnimWrapper(this.GetFearReactionPhase(stimEvent)), 1.00);
        if !this.m_fearLocomotionWrapper {
          AnimationControllerComponent.SetAnimWrapperWeightOnOwnerAndItems(owner, this.GetRandomFearLocomotionAnimWrapper(this.GetFearReactionPhase(stimEvent)), 1.00);
        };
        this.LogSuccess("started fear");
      };
    };
    if this.m_createThreshold {
      this.CreateFearThreashold();
      this.m_createThreshold = false;
    };
    this.CacheEvent(stimTaskData);
    this.LogSuccess("triggered behavior reaction " + EnumValueToString("gamedataOutput", Cast<Int64>(EnumInt(reaction.reactionBehavior))));
  }

  private final func GetStimSource(stimEvent: ref<StimuliEvent>) -> Vector4 {
    let closestDistanceSquared: Float;
    let closestPosition: Vector4;
    let distanceSquared: Float;
    let navigationSystem: ref<AINavigationSystem>;
    let path: ref<NavigationPath>;
    let query: AINavigationSystemQuery;
    let queryId: Uint32;
    let result: AINavigationSystemResult;
    let sourceWorldPosition: WorldPosition;
    let owner: ref<GameObject> = this.GetOwner();
    let ownerPos: Vector4 = owner.GetWorldPosition();
    let investigationSources: array<Vector4> = stimEvent.movePositions;
    let i: Int32 = 0;
    while i < ArraySize(investigationSources) {
      distanceSquared = Vector4.DistanceSquared(investigationSources[i], ownerPos);
      path = GameInstance.GetAINavigationSystem(owner.GetGame()).CalculatePathForCharacter(ownerPos, investigationSources[i], 0.00, owner);
      if !IsDefined(path) {
      } else {
        if distanceSquared < closestDistanceSquared || closestDistanceSquared == 0.00 {
          closestDistanceSquared = distanceSquared;
          closestPosition = investigationSources[i];
        };
      };
      i += 1;
    };
    if !Vector4.IsZero(closestPosition) {
      return closestPosition;
    };
    if stimEvent.IsTagInStimuli(n"NavReach") {
      navigationSystem = GameInstance.GetAINavigationSystem(owner.GetGame());
      AIPositionSpec.SetEntity(query.source, this.GetEntity());
      WorldPosition.SetVector4(sourceWorldPosition, stimEvent.sourcePosition);
      AIPositionSpec.SetWorldPosition(query.target, sourceWorldPosition);
      queryId = navigationSystem.StartPathfinding(query);
      navigationSystem.GetResult(queryId, result);
      navigationSystem.StopPathfinding(queryId);
      if result.hasClosestReachablePoint {
        return WorldPosition.ToVector4(result.closestReachablePoint);
      };
    };
    return stimEvent.sourcePosition;
  }

  private final func TryTriggerCombatOrAlertedFromHostileStim(stimEvent: ref<StimuliEvent>, stimData: ref<StimEventTaskData>, reactionData: ref<AIReactionData>, instigator: ref<GameObject>) -> Bool {
    let owner: ref<GameObject> = this.GetOwner();
    let ownerPuppet: ref<ScriptedPuppet> = this.GetOwnerPuppet();
    if this.CanTriggerCombatFromHostileStim(stimEvent, reactionData) && AIActionHelper.TryChangingAttitudeToHostile(ownerPuppet, instigator) {
      if !SenseComponent.ShouldIgnoreIfPlayerCompanion(owner, instigator) {
        TargetTrackingExtension.InjectThreat(ownerPuppet, instigator);
        this.LogSuccess("triggered combat from hostile stim");
      } else {
        this.LogFailure("could not trigger combat against player companion");
      };
      return true;
    };
    if this.CanTriggerAlertedFromHostileStim(stimEvent) {
      this.TriggerAlerted(instigator);
      this.CacheEvent(stimData);
      this.LogSuccess("triggered alerted from hostile stim");
      return true;
    };
    this.LogInfo("NOT TryTriggerCombatOrAlertedFromHostileStim");
    return false;
  }

  private final func CanTriggerCombatFromHostileStim(stimEvent: ref<StimuliEvent>, reactionData: ref<AIReactionData>) -> Bool {
    let stimType: gamedataStimType = stimEvent.GetStimType();
    if this.GetOwnerPuppet().IsPrevention() {
      return StimFilters.CanTriggerPreventionCombatDirectly(stimType) && (StimFilters.CanTriggerPreventionCombatDirectlyEvenInvisible(stimType) || this.IsTargetVisible(stimEvent.sourceObject));
    };
    return StimFilters.CanTriggerCombatDirectly(stimType);
  }

  private final func CanTriggerAlertedFromHostileStim(stimEvent: ref<StimuliEvent>) -> Bool {
    if this.GetOwnerPuppet().IsPrevention() {
      return false;
    };
    return StimFilters.CanTriggerAlertedDirectly(stimEvent.GetStimType());
  }

  private final static func InGunshotCone(shooter: wref<GameObject>, target: wref<GameObject>) -> Bool {
    return ReactionManagerComponent.IsTargetInFrontOfSource(shooter, target, 15.00, true);
  }

  public final func ShouldIgnoreCombatStim(stimType: gamedataStimType, instigator: wref<ScriptedPuppet>, source: wref<ScriptedPuppet>, sourcePos: Vector4, opt log: Bool) -> Bool {
    let canIgnoreOnlyDueToDelay: Bool;
    let canIgnorePlayerCombatStim: Bool;
    return this.ShouldIgnoreCombatStim(stimType, instigator, source, sourcePos, false, canIgnoreOnlyDueToDelay, canIgnorePlayerCombatStim, log);
  }

  public final func ShouldIgnoreCombatStim(stimType: gamedataStimType, instigator: wref<ScriptedPuppet>, source: wref<ScriptedPuppet>, sourcePos: Vector4, canDelay: Bool, out canIgnoreOnlyDueToDelay: Bool, out canIgnorePlayerCombatStim: Bool, log: Bool) -> Bool {
    let i: Int32;
    let inDangerRange: Bool;
    let isNPCInCombat: Bool;
    let isPlayerInCombat: Bool;
    let otherPuppet: ref<ScriptedPuppet>;
    let puppet: ref<ScriptedPuppet>;
    let squadMates: array<wref<Entity>>;
    if !IsDefined(source) && !IsDefined(instigator) {
      return false;
    };
    if !IsDefined(source) {
      source = instigator;
    };
    if !IsDefined(source) || !source.IsPlayer() {
      return false;
    };
    if !StimFilters.CanBeIgnoredInCombat(stimType) {
      return false;
    };
    isNPCInCombat = this.HasCombatTarget();
    isPlayerInCombat = (source as PlayerPuppet).IsInCombat();
    if !isNPCInCombat && !isPlayerInCombat && this.CombatGracePeriodPassed(source as PlayerPuppet) {
      if canDelay {
        canIgnoreOnlyDueToDelay = true;
      } else {
        return false;
      };
    };
    puppet = this.GetOwnerPuppet();
    if NPCPuppet.IsInCombatWithTarget(puppet, source) {
      return false;
    };
    canIgnorePlayerCombatStim = true;
    if StimFilters.IsProjectile(stimType) && this.IsTargetPositionClose(sourcePos, 4.00) {
      if log {
        this.LogInfo("can\'t be ignored - projectile hit nearby");
      };
      return false;
    };
    inDangerRange = this.IsTargetPositionClose(sourcePos, 12.00);
    if Equals(stimType, gamedataStimType.Explosion) && inDangerRange {
      if log {
        this.LogInfo("can\'t be ignored - explosion nearby");
      };
      return false;
    };
    if StimFilters.IsGunshot(stimType) {
      if inDangerRange {
        if log {
          this.LogInfo("can\'t be ignored - gunshot nearby");
        };
        return false;
      };
      if ReactionManagerComponent.InGunshotCone(source, puppet) {
        if log {
          this.LogInfo("can\'t be ignored - gunshot at owner");
        };
        return false;
      };
    };
    if StimFilters.IsIllegal(stimType) && inDangerRange && ReactionManagerComponent.InGunshotCone(source, puppet) {
      if log {
        this.LogInfo("can\'t be ignored - nearby illegal action directed at owner");
      };
      return false;
    };
    if this.IsTargetVeryClose(source) {
      if log {
        this.LogInfo("can\'t be ignored - player very close to owner");
      };
      return false;
    };
    if puppet.IsConnectedToSecuritySystem() {
      if puppet.IsTargetTresspassingMyZone(source) {
        if log {
          this.LogInfo("can\'t be ignored - player trespassing security zone");
        };
        return false;
      };
    };
    AISquadHelper.GetSquadmates(puppet, squadMates);
    i = 0;
    while i < ArraySize(squadMates) {
      otherPuppet = squadMates[i] as ScriptedPuppet;
      if IsDefined(otherPuppet) && NPCPuppet.IsInCombatWithTarget(otherPuppet, source) {
        if log {
          this.LogInfo("can\'t be ignored - squadmate in combat with player");
        };
        return false;
      };
      i += 1;
    };
    return true;
  }

  private final func IsSquadMateInDanger() -> Bool {
    let i: Int32;
    let investigateData: stimInvestigateData;
    let member: ref<ScriptedPuppet>;
    let memberDesiredReaction: ref<AIReactionData>;
    let memberStimReactionComp: ref<ReactionManagerComponent>;
    let smi: ref<SquadScriptInterface>;
    let squadMembers: array<wref<Entity>>;
    let ownerPuppet: ref<ScriptedPuppet> = this.GetOwnerPuppet();
    if !AISquadHelper.GetSquadMemberInterface(ownerPuppet, smi) {
      return false;
    };
    squadMembers = smi.ListMembersWeak();
    if ArraySize(squadMembers) <= 1 {
      return false;
    };
    i = 0;
    while i < ArraySize(squadMembers) {
      member = squadMembers[i] as ScriptedPuppet;
      if !ScriptedPuppet.IsActive(member) {
      } else {
        if member == ownerPuppet {
        } else {
          memberStimReactionComp = member.GetStimReactionComponent();
          memberDesiredReaction = memberStimReactionComp.GetDesiredReactionData();
          if !IsDefined(memberDesiredReaction) || NotEquals(memberDesiredReaction.reactionBehaviorName, gamedataOutput.Intruder) {
          } else {
            if !this.IsTargetVisible(member) {
            } else {
              investigateData = memberDesiredReaction.stimInvestigateData;
              if memberStimReactionComp.ShouldIgnoreCombatStim(memberDesiredReaction.stimType, investigateData.attackInstigator as ScriptedPuppet, memberDesiredReaction.stimEventData.source as ScriptedPuppet, memberDesiredReaction.stimSource) {
              } else {
                return true;
              };
            };
          };
        };
      };
      i += 1;
    };
    return false;
  }

  private final func FirstSquadMemberReaction() -> Bool {
    let distance: Float;
    let i: Int32;
    let member: ref<ScriptedPuppet>;
    let memberDesiredReactionData: ref<AIReactionData>;
    let smi: ref<SquadScriptInterface>;
    let squadMembers: array<wref<Entity>>;
    let stimDistance: Float;
    let suitableSquadmate: ref<ScriptedPuppet>;
    if !AISquadHelper.GetSquadMemberInterface(this.GetOwnerPuppet(), smi) {
      return true;
    };
    squadMembers = smi.ListMembersWeak();
    if ArraySize(squadMembers) <= 1 {
      return true;
    };
    i = 0;
    while i < ArraySize(squadMembers) {
      member = squadMembers[i] as ScriptedPuppet;
      if !ScriptedPuppet.IsActive(member) {
      } else {
        memberDesiredReactionData = member.GetStimReactionComponent().GetDesiredReactionData();
        if IsDefined(this.m_desiredReaction) && NotEquals(member.GetStimReactionComponent().GetReceivedStimType(), this.m_desiredReaction.stimType) && IsDefined(memberDesiredReactionData) && NotEquals(memberDesiredReactionData.stimType, this.m_desiredReaction.stimType) {
        } else {
          stimDistance = Vector4.Distance(member.GetWorldPosition(), this.m_desiredReaction.stimSource);
          if stimDistance < distance || distance == 0.00 {
            suitableSquadmate = member;
            distance = stimDistance;
          };
        };
      };
      i += 1;
    };
    if IsDefined(suitableSquadmate) {
      return this.GetOwnerPuppet() == suitableSquadmate;
    };
    return true;
  }

  public final func ClearPendingReaction() -> Void {
    this.m_pendingReaction = null;
  }

  private func TriggerPendingReaction() -> Void {
    let crowdMemberComponent: ref<CrowdMemberBaseComponent>;
    let owner: ref<GameObject>;
    let triggerAIEvent: ref<StimuliEvent>;
    if !IsDefined(this.m_pendingReaction) {
      return;
    };
    owner = this.GetOwner();
    if this.m_pendingReaction.validTillTimeStamp > 0.00 && this.m_pendingReaction.validTillTimeStamp < EngineTime.ToFloat(GameInstance.GetSimTime(owner.GetGame())) {
      this.ClearPendingReaction();
      return;
    };
    this.DeactiveLookAt();
    GameInstance.GetDelaySystem(owner.GetGame()).CancelDelay(this.m_resetReactionDataID);
    this.m_desiredReaction = new AIReactionData();
    this.m_desiredReaction.reactionBehaviorName = this.m_pendingReaction.reactionBehaviorName;
    this.m_desiredReaction.stimPriority = this.m_pendingReaction.stimPriority;
    this.m_desiredReaction.stimTarget = this.m_pendingReaction.stimTarget;
    this.m_desiredReaction.stimType = this.m_pendingReaction.stimType;
    this.m_desiredReaction.stimSource = this.m_pendingReaction.stimSource;
    this.m_desiredReaction.stimRecord = this.m_pendingReaction.stimRecord;
    this.m_desiredReaction.reactionPriority = this.m_pendingReaction.reactionPriority;
    this.m_desiredReaction.stimInvestigateData = this.m_pendingReaction.stimInvestigateData;
    this.m_desiredReaction.stimEventData = this.m_pendingReaction.stimEventData;
    this.m_desiredReaction.reactionBehaviorAIPriority = this.m_pendingReaction.reactionBehaviorAIPriority;
    this.m_desiredReaction.reactionCooldown = this.m_pendingReaction.reactionCooldown;
    if this.IsInitAnimShock(this.m_pendingReaction.reactionBehaviorName) {
      this.m_desiredReaction.initAnimInWorkspot = true;
      if this.m_previousFearPhase == 2 {
        this.m_previousFearPhase = 0;
      };
    };
    triggerAIEvent = new StimuliEvent();
    triggerAIEvent.SetStimType(gamedataStimType.Invalid);
    triggerAIEvent.name = n"triggerReaction";
    if Equals(this.m_pendingReaction.reactionBehaviorName, gamedataOutput.Flee) {
      NPCPuppet.ChangeHighLevelState(owner, gamedataNPCHighLevelState.Fear);
      this.DeactiveLookAt();
      this.ResetFacial(0.00);
      this.TriggerFearFacial(3);
      AnimationControllerComponent.SetAnimWrapperWeightOnOwnerAndItems(owner, this.GetRandomFearLocomotionAnimWrapper(3), 1.00);
      if this.m_inCrowd {
        crowdMemberComponent = this.GetOwnerPuppet().GetCrowdMemberComponent();
        crowdMemberComponent.SetThreatLastKnownPosition(this.GetPlayerSystem().GetLocalPlayerMainGameObject().GetWorldPosition());
        crowdMemberComponent.AllowWorkspotsUsage(false);
      };
    };
    owner.QueueEvent(triggerAIEvent);
    this.ClearPendingReaction();
  }

  private final func TriggerReactionBehaviorForCrowd(stimEvent: ref<StimuliEvent>, reaction: gamedataOutput, dontPlayStartUpAnimation: Bool, opt skipInitialAnimation: Bool) -> Void {
    let crowdMemberComponent: ref<CrowdMemberBaseComponent>;
    let triggerAIEvent: ref<StimuliEvent>;
    let stimData: stimInvestigateData = stimEvent.stimInvestigateData;
    this.m_desiredReaction = new AIReactionData();
    this.m_desiredReaction.reactionBehaviorName = reaction;
    this.m_desiredReaction.stimPriority = stimEvent.stimRecord.Priority().Type();
    this.m_desiredReaction.stimTarget = stimEvent.sourceObject;
    this.m_desiredReaction.stimType = stimEvent.GetStimType();
    this.m_desiredReaction.stimSource = this.GetStimSource(stimEvent);
    this.m_desiredReaction.stimRecord = stimEvent.stimRecord;
    this.m_desiredReaction.stimInvestigateData = stimData;
    this.m_desiredReaction.reactionBehaviorAIPriority = this.GetOutputPriority(reaction);
    this.m_desiredReaction.initAnimInWorkspot = dontPlayStartUpAnimation;
    if skipInitialAnimation {
      this.m_desiredReaction.skipInitialAnimation = skipInitialAnimation;
    } else {
      this.m_desiredReaction.skipInitialAnimation = stimData.skipInitialAnimation;
    };
    triggerAIEvent = new StimuliEvent();
    triggerAIEvent.SetStimType(gamedataStimType.Invalid);
    triggerAIEvent.name = n"triggerReaction";
    if this.IsInPendingBehavior() && (NotEquals(reaction, gamedataOutput.Flee) || Equals(stimEvent.GetStimType(), gamedataStimType.HijackVehicle)) {
      this.m_pendingReaction = this.m_desiredReaction;
      this.m_pendingReaction.validTillTimeStamp = EngineTime.ToFloat(GameInstance.GetSimTime(this.GetOwner().GetGame())) + TweakDBInterface.GetFloat(t"AIGeneralSettings.pendingReactionValidTimeStamp", 10.00);
      this.m_desiredFearPhase = -1;
      this.m_desiredReaction = null;
    } else {
      this.GetOwner().QueueEvent(triggerAIEvent);
      if this.m_inCrowd {
        crowdMemberComponent = this.GetOwnerPuppet().GetCrowdMemberComponent();
        crowdMemberComponent.SetThreatLastKnownPosition(this.GetPlayerSystem().GetLocalPlayerMainGameObject().GetWorldPosition());
        crowdMemberComponent.AllowWorkspotsUsage(false);
      };
    };
  }

  private final func TriggerReactionBehaviorForCrowd(target: ref<GameObject>, reaction: gamedataOutput, initAnimInWorkspot: Bool, opt sourcePosition: Vector4) -> Void {
    let crowdMemberComponent: ref<CrowdMemberBaseComponent>;
    let triggerAIEvent: ref<StimuliEvent>;
    this.m_desiredReaction = new AIReactionData();
    this.m_desiredReaction.reactionBehaviorName = reaction;
    this.m_desiredReaction.stimTarget = target;
    if Vector4.IsZero(sourcePosition) {
      this.m_desiredReaction.stimSource = target.GetWorldPosition();
    } else {
      this.m_desiredReaction.stimSource = sourcePosition;
    };
    this.m_desiredReaction.reactionBehaviorAIPriority = this.GetOutputPriority(reaction);
    this.m_desiredReaction.initAnimInWorkspot = initAnimInWorkspot;
    triggerAIEvent = new StimuliEvent();
    triggerAIEvent.SetStimType(gamedataStimType.Invalid);
    triggerAIEvent.name = n"triggerReaction";
    if this.IsInPendingBehavior() {
      this.m_pendingReaction = this.m_desiredReaction;
      this.m_pendingReaction.validTillTimeStamp = EngineTime.ToFloat(GameInstance.GetSimTime(this.GetOwner().GetGame())) + TweakDBInterface.GetFloat(t"AIGeneralSettings.pendingReactionValidTimeStamp", 10.00);
      this.m_desiredReaction = null;
    } else {
      this.GetOwner().QueueEvent(triggerAIEvent);
      if Equals(reaction, gamedataOutput.Bump) && IsDefined(this.m_activeReaction) && (Equals(this.m_activeReaction.reactionBehaviorName, gamedataOutput.Bump) || Equals(this.m_activeReaction.reactionBehaviorName, gamedataOutput.BackOff)) {
        this.m_desiredReaction.escalateProvoke = true;
      };
      if this.m_inCrowd {
        if NotEquals(this.m_crowdFearStage, gameFearStage.Relaxed) {
          crowdMemberComponent = this.GetOwnerPuppet().GetCrowdMemberComponent();
          crowdMemberComponent.SetThreatLastKnownPosition(this.GetPlayerSystem().GetLocalPlayerMainGameObject().GetWorldPosition());
          crowdMemberComponent.AllowWorkspotsUsage(false);
        } else {
          if Equals(reaction, gamedataOutput.CallPolice) {
            crowdMemberComponent.TryStopTrafficMovement();
          };
        };
      };
    };
  }

  protected cb func OnDelayStimEvent(evt: ref<DelayStimEvent>) -> Bool {
    if evt.fullEventPipeline {
      this.HandleStimEventByTask(evt.stimEvent, true);
      return true;
    };
    if Equals(evt.stimEvent.GetStimType(), gamedataStimType.AimingAt) && this.IsPlayerAiming() && evt.stimEvent.sourceObject.IsPlayer() && this.IsTargetDetected(evt.stimEvent.sourceObject) && this.IsReactionAvailableInPreset(gamedataStimType.AimingAt) {
      AIActionHelper.TryStartCombatWithTarget(this.GetOwnerPuppet(), evt.stimEvent.sourceObject);
    };
  }

  private final func ProcessEnvironmentalHazard(stimEvent: ref<StimuliEvent>) -> Void {
    let i: Int32;
    let radius: Float;
    if this.m_inCrowd {
      return;
    };
    if IsDefined(stimEvent.sourceObject) {
      if !this.IsTargetInFront(stimEvent.sourceObject) {
        return;
      };
      radius = stimEvent.radius > 0.00 ? stimEvent.radius : this.m_crowdAimingReactionDistance;
      if !this.IsTargetClose(stimEvent.sourceObject, radius) {
        return;
      };
    } else {
      return;
    };
    i = 0;
    while i < ArraySize(this.m_environmentalHazards) {
      if this.m_environmentalHazards[i].sourceObject == stimEvent.sourceObject {
        GameInstance.GetDelaySystem(this.GetOwner().GetGame()).CancelDelay(this.m_environmentalHazardsDelayIDs[i]);
        this.m_environmentalHazards[i] = stimEvent;
        this.m_environmentalHazardsDelayIDs[i] = this.DelayEnvironmentalHazardEvent(stimEvent);
        return;
      };
      i += 1;
    };
    ArrayPush(this.m_environmentalHazards, stimEvent);
    ArrayPush(this.m_environmentalHazardsDelayIDs, this.DelayEnvironmentalHazardEvent(stimEvent));
  }

  private final func DelayEnvironmentalHazardEvent(stimEvent: ref<StimuliEvent>) -> DelayID {
    let cleanEnvironmentalHazardEvent: ref<CleanEnvironmentalHazardEvent> = new CleanEnvironmentalHazardEvent();
    cleanEnvironmentalHazardEvent.stimEvent = stimEvent;
    return GameInstance.GetDelaySystem(this.GetOwner().GetGame()).DelayEvent(this.GetOwner(), cleanEnvironmentalHazardEvent, 2.00);
  }

  protected cb func OnCleanEnvironmentalHazardEvent(cleanEnvironmentalHazardEvent: ref<CleanEnvironmentalHazardEvent>) -> Bool {
    let i: Int32 = 0;
    while i < ArraySize(this.m_environmentalHazards) {
      if this.m_environmentalHazards[i] == cleanEnvironmentalHazardEvent.stimEvent {
        ArrayErase(this.m_environmentalHazards, i);
        ArrayErase(this.m_environmentalHazardsDelayIDs, i);
      };
      i += 1;
    };
  }

  private final func ProcessStimForTheDead(stimEvent: ref<StimuliEvent>) -> Void {
    if ScriptedPuppet.IsAlive(this.GetOwner()) {
      this.LogFailure("owner alive");
      return;
    };
    if !this.GetOwnerPuppet().IsHumanoid() {
      this.LogFailure("owner not humanoid");
      return;
    };
    if NotEquals(stimEvent.GetStimType(), gamedataStimType.UndeadCall) {
      this.LogFailure("unknown stim for the dead");
      return;
    };
    this.LogInfo("processing stim for the dead");
    if this.ActivateUndeadLookAt(stimEvent.sourceObject) {
      this.LogSuccess("activated lookat");
    };
  }

  private final func InitCrowd() -> Void {
    this.m_exitWorkspotAim = TweakDBInterface.GetVector2(t"AIGeneralSettings.workspotReactionExitDelay", new Vector2(3.00, 5.00));
    this.m_fearToIdleDistance = TweakDBInterface.GetVector2(t"AIGeneralSettings.fearToIdleDistance", new Vector2(15.00, 5.00));
    this.m_crowdAimingReactionDistance = TweakDBInterface.GetFloat(t"AIGeneralSettings.crowdAimingReactionDistance", 20.00);
    this.m_fearInPlaceAroundDistance = TweakDBInterface.GetFloat(t"AIGeneralSettings.fearInPlaceAroundDistance", 20.00);
  }

  private final func ShouldStimBeProcessedByCrowd(stimEvent: ref<StimuliEvent>) -> Bool {
    let fearReactionPhase: Int32;
    let reactionSystem: ref<ReactionSystem>;
    let sceneSystemInt: ref<SceneSystemInterface>;
    let vehicle: ref<VehicleObject>;
    let owner: ref<GameObject> = this.GetOwner();
    let stimType: gamedataStimType = stimEvent.GetStimType();
    let puppetRef: ref<NPCPuppet> = owner as NPCPuppet;
    if IsDefined(puppetRef) && puppetRef.IsPrevention() {
      this.LogFailure("owner is from prevention system");
      return false;
    };
    if !this.m_initCrowd {
      this.InitCrowd();
      this.m_initCrowd = true;
    };
    if Equals(stimType, gamedataStimType.HijackVehicle) {
      return true;
    };
    if this.SourceAttitude(stimEvent.sourceObject, EAIAttitude.AIA_Friendly) {
      if !this.m_inCrowd {
        this.LogFailure("friendly stim source and owner not in crowd");
        return false;
      };
      if Equals(stimType, gamedataStimType.AimingAt) {
        this.LogFailure("friendly stim source aiming at owner");
        return false;
      };
    };
    if Equals(stimType, gamedataStimType.MeleeAttack) && StatusEffectSystem.ObjectHasStatusEffect(stimEvent.sourceObject, t"GameplayRestriction.FistFight") {
      this.LogFailure("stim source in a fist fight");
      return false;
    };
    if (owner as NPCPuppet).IsRagdolling() {
      this.LogFailure("owner ragdolling");
      return false;
    };
    if !this.CanReactInVehicle(stimEvent) {
      return false;
    };
    if stimEvent.IsVisual() && !StimFilters.IsGunshot(stimType) {
      if !this.IsTargetInFront(stimEvent.sourceObject) {
        this.LogFailure("visual source behind");
        return false;
      };
      if !this.IsTargetClose(stimEvent.sourceObject, this.m_crowdAimingReactionDistance) {
        this.LogFailure("visual source too far");
        return false;
      };
      if !this.TargetVerticalCheck(stimEvent.sourceObject) {
        this.LogFailure("visual source too high/low");
        return false;
      };
      if GameInstance.GetWorkspotSystem(owner.GetGame()).IsActorInWorkspot(owner) {
        if StatusEffectSystem.ObjectHasStatusEffectWithTag(owner, n"Braindance") || StatusEffectSystem.ObjectHasStatusEffectWithTag(owner, n"Sleep") {
          this.LogFailure("owner sleeping or in braindance");
          return false;
        };
      };
    };
    if this.m_desiredFearPhase > -1 || IsDefined(this.m_activeReaction) || NotEquals(this.m_crowdFearStage, gameFearStage.Relaxed) || this.m_inReactionSequence && GameInstance.GetWorkspotSystem(owner.GetGame()).IsActorInWorkspot(owner) {
      if Equals(stimType, gamedataStimType.CombatHit) {
        if FromVariant<Bool>(this.GetOwnerPuppet().GetAIControllerComponent().GetBehaviorArgument(n"InFearInPlace")) {
          GameObject.PlayVoiceOver(owner, n"fear_beg", n"Scripts:ShouldStimBeProcessedByCrowd", true);
        } else {
          if Equals(PlayerPuppet.GetCurrentCombatState(stimEvent.sourceObject as PlayerPuppet), gamePSMCombat.InCombat) || !IsDefined(this.m_activeReaction) {
            return true;
          };
        };
      };
      fearReactionPhase = this.GetFearReactionPhase(stimEvent);
      if this.m_desiredFearPhase >= fearReactionPhase {
        this.LogFailure("later phase of fear");
        return false;
      };
      if !this.ShouldInterruptCurrentFearStage(fearReactionPhase) {
        this.LogFailure("NOT ShouldInterruptCurrentFearStage");
        return false;
      };
    };
    if !stimEvent.IsTagInStimuli(n"CrowdReaction") && !stimEvent.IsTagInStimuli(n"ChildDanger") {
      this.LogFailure("stim doesnt have CrowdReaction or ChildDanger tags");
      return false;
    };
    if NotEquals(this.m_reactionPreset.Type(), gamedataReactionPresetType.Civilian_Neutral) && !this.IsReactionAvailableInPreset(stimEvent.GetStimType()) {
      this.LogFailure("NOT Civilian_Neutral reaction preset and unavailable reaction");
      return false;
    };
    if Equals(stimType, gamedataStimType.CrowdIllegalAction) && StatusEffectSystem.ObjectHasStatusEffectWithTag(owner, n"LoreVictimSaved") {
      this.LogFailure("no LoreVictimSaved tag");
      return false;
    };
    if Equals(stimType, gamedataStimType.Driving) && IsDefined(stimEvent.sourceObject as VehicleObject) {
      if !(stimEvent.sourceObject as VehicleObject).IsOnPavement() {
        this.LogFailure("driving outside of pavement ignored");
        return false;
      };
      if !this.IsTargetInFront(stimEvent.sourceObject, 30.00, true) && !this.IsTargetBehind(stimEvent.sourceObject, 160.00, true) && !this.IsTargetClose(stimEvent.sourceObject, 10.00) {
        this.LogFailure("driving distance/angle checks failed");
        return false;
      };
      vehicle = stimEvent.sourceObject as VehicleObject;
      if IsDefined(vehicle) {
        if vehicle.GetCurrentSpeed() < 24.00 {
          this.LogFailure("vehicle speed too low");
          return false;
        };
      };
    };
    if GameInstance.GetGameFeatureManager(owner.GetGame()).AggressiveCrowdsEnabled() {
      reactionSystem = GameInstance.GetReactionSystem(owner.GetGame());
      if reactionSystem.IsRegisteredAsAggressive(owner.GetEntityID()) {
        if !this.ShouldFearWhileAggressiveCrowdNPCCombat(stimEvent) {
          this.LogFailure("NOT ShouldFearWhileAggressiveCrowdNPCCombat");
          return false;
        };
      } else {
        if stimEvent.IsTagInStimuli(n"AggressiveCrowd") {
          this.LogFailure("non-agressive NPC, but stim for AggressiveCrowd");
          return false;
        };
      };
    } else {
      if stimEvent.IsTagInStimuli(n"AggressiveCrowd") {
        this.LogFailure("agressive NPCs disabled, but stim for AggressiveCrowd");
        return false;
      };
    };
    sceneSystemInt = GameInstance.GetSceneSystem(owner.GetGame()).GetScriptInterface();
    if sceneSystemInt.IsEntityInScene(owner.GetEntityID()) && sceneSystemInt.IsEntityInScene(stimEvent.sourceObject.GetEntityID()) {
      this.LogFailure("both owner and stim source in scene");
      return false;
    };
    if GameInstance.GetSafeAreaManager(owner.GetGame()).IsPointInSafeArea(owner.GetWorldPosition()) && IsEntityInInteriorArea(EntityGameInterface.GetEntity(owner.GetEntity())) {
      this.LogFailure("owner in safe interior area");
      return false;
    };
    return true;
  }

  private final func HandleCrowdReaction(stimEvent: ref<StimuliEvent>) -> Void {
    let delayedCrowdReaction: ref<DelayedCrowdReactionEvent>;
    let mountInfo: MountingInfo;
    let stimAttackData: stimInvestigateData;
    let vehicleReactionEvent: ref<HandleReactionEvent>;
    let owner: ref<GameObject> = this.GetOwner();
    let game: GameInstance = owner.GetGame();
    let reactionSystem: ref<ReactionSystem> = GameInstance.GetReactionSystem(this.GetOwner().GetGame());
    if this.m_inCrowd && GameInstance.GetGameFeatureManager(game).AggressiveCrowdsEnabled() && (!VehicleComponent.IsMountedToVehicle(game, owner) || VehicleComponent.IsDriver(game, owner.GetEntityID())) && this.ShouldTriggerAggressiveCrowdNPCCombat(stimEvent) && (owner.IsPrevention() || reactionSystem.TryRegisteringAggressiveNPC(owner)) {
      if VehicleComponent.IsMountedToVehicle(game, owner) {
        this.m_driverIsAggressive = true;
      } else {
        this.TriggerAggressiveCrowdBehavior(owner, stimEvent.sourceObject);
      };
    } else {
      if Equals(this.m_reactionPreset.Type(), gamedataReactionPresetType.Child) && stimEvent.IsTagInStimuli(n"ChildDanger") {
        this.m_desiredFearPhase = 3;
        this.DeactiveLookAt();
        stimAttackData = stimEvent.stimInvestigateData;
        if IsDefined(stimAttackData.attackInstigator) {
          stimEvent.sourceObject = stimAttackData.attackInstigator as GameObject;
          stimEvent.sourcePosition = stimEvent.sourceObject.GetWorldPosition();
        };
        this.ActivateReactionLookAt(stimEvent.sourceObject, false);
        delayedCrowdReaction = new DelayedCrowdReactionEvent();
        delayedCrowdReaction.stimEvent = stimEvent;
        owner.QueueEvent(delayedCrowdReaction);
      } else {
        if VehicleComponent.IsMountedToVehicle(game, owner) && NotEquals(stimEvent.GetStimType(), gamedataStimType.HijackVehicle) && NotEquals(stimEvent.GetStimType(), gamedataStimType.Dying) {
          NPCPuppet.ChangeHighLevelState(owner, gamedataNPCHighLevelState.Fear);
          mountInfo = GameInstance.GetMountingFacility(game).GetMountingInfoSingleWithObjects(owner);
          this.m_previousFearPhase = this.ConvertFearStageToFearPhase(this.m_crowdFearStage);
          vehicleReactionEvent = new HandleReactionEvent();
          vehicleReactionEvent.fearPhase = this.GetFearReactionPhase(stimEvent);
          vehicleReactionEvent.stimEvent = stimEvent;
          GameInstance.FindEntityByID(game, mountInfo.parentId).QueueEvent(vehicleReactionEvent);
        } else {
          this.m_previousFearPhase = this.ConvertFearStageToFearPhase(this.m_crowdFearStage);
          this.m_desiredFearPhase = this.GetFearReactionPhase(stimEvent);
          if VehicleComponent.IsMountedToVehicle(game, owner) && Equals(stimEvent.GetStimType(), gamedataStimType.HijackVehicle) {
            GameObject.PlayVoiceOver(owner, n"fear_beg", n"Scripts:HandleCrowdReaction", true);
          };
          this.DeactiveLookAt();
          stimAttackData = stimEvent.stimInvestigateData;
          if IsDefined(stimAttackData.attackInstigator) {
            stimEvent.sourceObject = stimAttackData.attackInstigator as GameObject;
            stimEvent.sourcePosition = stimEvent.sourceObject.GetWorldPosition();
          };
          this.ActivateReactionLookAt(stimEvent.sourceObject, false);
          delayedCrowdReaction = new DelayedCrowdReactionEvent();
          delayedCrowdReaction.stimEvent = stimEvent;
          if this.m_desiredFearPhase == -1 {
            return;
          };
          this.CreateFearArea(stimEvent, this.m_desiredFearPhase);
          if !stimAttackData.skipReactionDelay {
            this.m_delayReactionEventID = GameInstance.GetDelaySystem(game).DelayEvent(owner, delayedCrowdReaction, RandRangeF(this.m_delay.X, this.m_delay.Y));
          } else {
            owner.QueueEvent(delayedCrowdReaction);
          };
        };
      };
    };
  }

  private final func TriggerAggressiveCrowdBehavior(owner: ref<GameObject>, target: ref<GameObject>) -> Void {
    if AIActionHelper.TryChangingAttitudeToHostile(owner as ScriptedPuppet, target) {
      owner.GetSensesComponent().IgnoreLODChange(true);
      owner.GetSensesComponent().Toggle(true);
      owner.GetTargetTrackerComponent().Toggle(true);
      TargetTrackingExtension.InjectThreat(owner as ScriptedPuppet, target);
      (owner as NPCPuppet).SetWasAggressiveCrowd(true);
      this.ResetAllFearAnimWrappers();
    };
  }

  protected cb func OnCrowdReaction(reactionDelayEvent: ref<DelayedCrowdReactionEvent>) -> Bool {
    let blackboard: ref<IBlackboard>;
    let blackboardSystem: ref<BlackboardSystem>;
    let broadcaster: ref<StimBroadcasterComponent>;
    let crowdMemberComponent: ref<CrowdMemberComponent>;
    let exitFearInVehicle: ref<DeescalateFearInVehicle>;
    let exitWorkspot: ref<ExitWorkspotSequenceEvent>;
    let fearPhase: Int32;
    let game: GameInstance;
    let pointResults: NavigationFindPointResult;
    let reactionSystem: ref<ReactionSystem>;
    let stimType: gamedataStimType;
    let workspotSystem: ref<WorkspotGameSystem>;
    let owner: ref<GameObject> = this.GetOwner();
    let stimData: stimInvestigateData = reactionDelayEvent.stimEvent.stimInvestigateData;
    if !ScriptedPuppet.IsActive(owner) {
      return false;
    };
    stimType = reactionDelayEvent.stimEvent.GetStimType();
    if this.m_beignHijacked && NotEquals(stimType, gamedataStimType.HijackVehicle) {
      return false;
    };
    game = owner.GetGame();
    reactionSystem = GameInstance.GetReactionSystem(game);
    crowdMemberComponent = this.GetOwnerPuppet().GetCrowdMemberComponent();
    crowdMemberComponent.OnCrowdReaction(stimType);
    if Equals(stimType, gamedataStimType.AimingAt) && reactionDelayEvent.vehicleFearPhase != 3 {
      blackboardSystem = GameInstance.GetBlackboardSystem(game);
      blackboard = blackboardSystem.GetLocalInstanced(this.GetPlayerSystem().GetLocalPlayerMainGameObject().GetEntityID(), GetAllBlackboardDefs().PlayerStateMachine);
      if blackboard.GetInt(GetAllBlackboardDefs().PlayerStateMachine.UpperBody) == 6 {
        blackboard = GameInstance.GetBlackboardSystem(game).Get(GetAllBlackboardDefs().UI_TargetingInfo);
        if blackboard.GetEntityID(GetAllBlackboardDefs().UI_TargetingInfo.CurrentVisibleTarget) != owner.GetEntityID() && NotEquals(this.m_reactionPreset.Type(), gamedataReactionPresetType.InVehicle_Civilian) {
          this.DeactiveLookAt();
          this.m_desiredFearPhase = -1;
          return IsDefined(null);
        };
      } else {
        this.DeactiveLookAt();
        this.m_desiredFearPhase = -1;
        return IsDefined(null);
      };
    };
    GameInstance.GetDelaySystem(game).CancelDelay(this.m_callingPoliceID);
    fearPhase = this.GetFearReactionPhase(reactionDelayEvent.stimEvent);
    if reactionDelayEvent.vehicleFearPhase > 0 {
      fearPhase = reactionDelayEvent.vehicleFearPhase;
    };
    workspotSystem = GameInstance.GetWorkspotSystem(game);
    crowdMemberComponent.SetThreatLastKnownPosition(this.GetPlayerSystem().GetLocalPlayerMainGameObject().GetWorldPosition());
    crowdMemberComponent.AllowWorkspotsUsage(false);
    NPCPuppet.ChangeHighLevelState(owner, gamedataNPCHighLevelState.Fear);
    if !VehicleComponent.IsMountedToVehicle(game, owner) || Equals(stimType, gamedataStimType.HijackVehicle) {
      reactionSystem.MarkDespawnCandidate(owner.GetEntityID());
    };
    this.DeactiveLookAt();
    this.ResetFacial(0.00);
    this.TriggerFearFacial(fearPhase);
    if this.m_previousFearPhase != 2 {
      AnimationControllerComponent.SetAnimWrapperWeightOnOwnerAndItems(owner, this.GetFearAnimWrapper(fearPhase), 1.00);
      if fearPhase != 0 && (!this.m_fearLocomotionWrapper || fearPhase == 3) {
        AnimationControllerComponent.SetAnimWrapperWeightOnOwnerAndItems(owner, this.GetRandomFearLocomotionAnimWrapper(fearPhase, stimType), 1.00);
      };
      this.m_fearLocomotionWrapper = true;
    };
    switch fearPhase {
      case 1:
        this.m_crowdFearStage = gameFearStage.Stressed;
        break;
      case 2:
        this.m_crowdFearStage = gameFearStage.Alarmed;
        break;
      case 3:
        this.m_crowdFearStage = gameFearStage.Panic;
        crowdMemberComponent.SetThreatLastKnownPosition(this.GetPlayerSystem().GetLocalPlayerMainGameObject().GetWorldPosition());
        break;
      default:
        this.m_crowdFearStage = gameFearStage.Relaxed;
    };
    crowdMemberComponent.ChangeFearStage(this.m_crowdFearStage, !stimData.skipInitialAnimation);
    if workspotSystem.IsActorInWorkspot(owner) {
      if reactionSystem.IsInImmovableWorkspot(owner.GetEntityID()) {
        if fearPhase > 1 && workspotSystem.IsReactionAvailable(owner, n"Fear") {
          this.ActivateReactionLookAt(reactionDelayEvent.stimEvent.sourceObject, false, false, true);
          workspotSystem.SendReactionSignal(owner, n"Fear");
          this.m_inReactionSequence = true;
          GameObject.PlayVoiceOver(owner, n"fear_beg", n"Scripts:OnDelayedReaction");
        } else {
          this.TriggerFacialLookAtReaction(true, true);
        };
      } else {
        switch fearPhase {
          case 0:
            this.TriggerFacialLookAtReaction(true, true);
            break;
          case 1:
            pointResults = GameInstance.GetAINavigationSystem(game).FindPointInSphereForCharacter(owner.GetWorldPosition(), 0.50, owner);
            if this.IsTargetClose(reactionDelayEvent.stimEvent.sourceObject, 3.00) && this.IsTargetInFront(reactionDelayEvent.stimEvent.sourceObject) && workspotSystem.IsReactionAvailable(owner, n"Fear") && NotEquals(stimType, gamedataStimType.Bump) {
              this.ActivateReactionLookAt(reactionDelayEvent.stimEvent.sourceObject, false, false, true);
              workspotSystem.SendReactionSignal(owner, n"Fear");
              this.m_inReactionSequence = true;
              GameObject.PlayVoiceOver(owner, n"fear_beg", n"Scripts:OnDelayedReaction");
              exitWorkspot = new ExitWorkspotSequenceEvent();
              this.m_exitWorkspotSequenceEventId = GameInstance.GetDelaySystem(game).DelayEvent(owner, exitWorkspot, 3.00);
            } else {
              if Equals(pointResults.status, worldNavigationRequestStatus.OK) && workspotSystem.HasExitNodes(owner, true, false, true) {
                this.TriggerReactionBehaviorForCrowd(reactionDelayEvent.stimEvent, gamedataOutput.WalkAway, false);
              } else {
                if workspotSystem.IsReactionAvailable(owner, n"Fear") && NotEquals(stimType, gamedataStimType.Bump) {
                  this.ActivateReactionLookAt(reactionDelayEvent.stimEvent.sourceObject, false, false, true);
                  workspotSystem.SendReactionSignal(owner, n"Fear");
                  this.m_inReactionSequence = true;
                  GameObject.PlayVoiceOver(owner, n"fear_beg", n"Scripts:OnDelayedReaction");
                  exitWorkspot = new ExitWorkspotSequenceEvent();
                  this.m_exitWorkspotSequenceEventId = GameInstance.GetDelaySystem(game).DelayEvent(owner, exitWorkspot, 3.00);
                } else {
                  this.TriggerFacialLookAtReaction(true, true);
                };
              };
            };
            break;
          case 2:
            if workspotSystem.IsReactionAvailable(owner, n"Fear") {
              this.ActivateReactionLookAt(reactionDelayEvent.stimEvent.sourceObject, false, false, true);
              workspotSystem.SendReactionSignal(owner, n"Fear");
              this.m_inReactionSequence = true;
              GameObject.PlayVoiceOver(owner, n"fear_beg", n"Scripts:OnDelayedReaction");
              exitWorkspot = new ExitWorkspotSequenceEvent();
              this.m_exitWorkspotSequenceEventId = GameInstance.GetDelaySystem(game).DelayEvent(owner, exitWorkspot, 3.00);
            } else {
              if VehicleComponent.IsMountedToVehicle(game, owner) {
                this.ActivateReactionLookAt(reactionDelayEvent.stimEvent.sourceObject, false, false, true, true);
                GameObject.PlayVoiceOver(owner, n"fear_beg", n"Scripts:OnCrowdReaction", true);
                exitFearInVehicle = new DeescalateFearInVehicle();
                this.m_exitFearInVehicleEventId = GameInstance.GetDelaySystem(game).DelayEvent(owner, exitFearInVehicle, 3.00);
              } else {
                if !this.m_inReactionSequence {
                  if fearPhase == 3 {
                    this.SetCrowdRunningAwayAnimFeature(stimType);
                    this.TriggerReactionBehaviorForCrowd(reactionDelayEvent.stimEvent, gamedataOutput.Flee, false);
                  } else {
                    this.TriggerReactionBehaviorForCrowd(reactionDelayEvent.stimEvent, gamedataOutput.Surrender, false);
                  };
                };
              };
            };
            break;
          case 3:
            if workspotSystem.IsWorkspotEnabled(owner) && !workspotSystem.HasExitNodes(owner, true, false, true) && (workspotSystem.IsReactionAvailable(owner, n"Fear") || this.m_inReactionSequence) {
              this.ActivateReactionLookAt(reactionDelayEvent.stimEvent.sourceObject, false, false, true);
              workspotSystem.SendReactionSignal(owner, n"Fear");
              this.m_inReactionSequence = true;
              GameObject.PlayVoiceOver(owner, n"fear_beg", n"Scripts:OnDelayedReaction");
              exitWorkspot = new ExitWorkspotSequenceEvent();
              this.m_exitWorkspotSequenceEventId = GameInstance.GetDelaySystem(game).DelayEvent(owner, exitWorkspot, 3.00);
            } else {
              if this.m_previousFearPhase > 1 || workspotSystem.HasExitNodes(owner, true, false) {
                this.SetCrowdRunningAwayAnimFeature(stimType);
                this.TriggerReactionBehaviorForCrowd(reactionDelayEvent.stimEvent, gamedataOutput.Flee, true);
              } else {
                this.SetCrowdRunningAwayAnimFeature(stimType);
                this.TriggerReactionBehaviorForCrowd(reactionDelayEvent.stimEvent, gamedataOutput.Flee, false);
              };
            };
        };
      };
    } else {
      if this.m_inTrafficLane {
        this.GetOwnerPuppet().GetAIControllerComponent().SetBehaviorArgument(n"StimTarget", ToVariant(reactionDelayEvent.stimEvent.sourceObject));
        switch fearPhase {
          case 0:
            this.TriggerFacialLookAtReaction(true, true);
            break;
          case 1:
            this.TriggerReactionBehaviorForCrowd(reactionDelayEvent.stimEvent, gamedataOutput.WalkAway, false, true);
            break;
          case 2:
            crowdMemberComponent.TryStopTrafficMovement();
            this.TriggerReactionBehaviorForCrowd(reactionDelayEvent.stimEvent, gamedataOutput.Surrender, false, true);
            break;
          case 3:
            this.SetCrowdRunningAwayAnimFeature(stimType);
            this.TriggerReactionBehaviorForCrowd(reactionDelayEvent.stimEvent, gamedataOutput.Flee, false, true);
        };
      } else {
        switch fearPhase {
          case 0:
            this.TriggerFacialLookAtReaction(true, true);
            break;
          case 1:
            pointResults = GameInstance.GetAINavigationSystem(game).FindPointInSphereForCharacter(owner.GetWorldPosition(), 0.50, owner);
            if Equals(pointResults.status, worldNavigationRequestStatus.OK) {
              this.TriggerReactionBehaviorForCrowd(reactionDelayEvent.stimEvent, gamedataOutput.WalkAway, false);
            } else {
              this.TriggerFacialLookAtReaction(true, true);
            };
            break;
          case 2:
            this.TriggerReactionBehaviorForCrowd(reactionDelayEvent.stimEvent, gamedataOutput.Surrender, true);
            break;
          case 3:
            if this.m_previousFearPhase > 1 {
              this.SetCrowdRunningAwayAnimFeature(stimType);
              this.TriggerReactionBehaviorForCrowd(reactionDelayEvent.stimEvent, gamedataOutput.Flee, false, true);
            } else {
              this.SetCrowdRunningAwayAnimFeature(stimType);
              this.TriggerReactionBehaviorForCrowd(reactionDelayEvent.stimEvent, gamedataOutput.Flee, false);
            };
        };
      };
    };
    if NotEquals(this.m_reactionPreset.Type(), gamedataReactionPresetType.Child) && reactionDelayEvent.stimEvent.sourceObject == this.GetPlayerSystem().GetLocalPlayerMainGameObject() && !reactionDelayEvent.stimEvent.IsTagInStimuli(n"NoFearSpread") {
      this.SpreadFear(fearPhase);
    } else {
      if Equals(stimType, gamedataStimType.HijackVehicle) {
        broadcaster = reactionDelayEvent.stimEvent.sourceObject.GetStimBroadcasterComponent();
        if IsDefined(broadcaster) {
          broadcaster.TriggerSingleBroadcast(owner, gamedataStimType.CrimeWitness);
        };
      };
    };
    this.m_desiredFearPhase = -1;
  }

  private final func SpreadFear(phase: Int32) -> Void {
    let broadcaster: ref<StimBroadcasterComponent>;
    let stimData: stimInvestigateData;
    let owner: ref<GameObject> = this.GetOwner();
    if !GameObject.IsCooldownActive(owner, n"spreadFearCooldown") {
      GameObject.StartCooldown(owner, n"spreadFearCooldown", 3.00);
      broadcaster = owner.GetStimBroadcasterComponent();
      if IsDefined(broadcaster) {
        if phase > 1 {
          stimData.fearPhase = 3;
          broadcaster.TriggerSingleBroadcast(owner, gamedataStimType.SpreadFear, 10.00, stimData);
        } else {
          stimData.fearPhase = 1;
        };
        broadcaster.AddActiveStimuli(owner, gamedataStimType.SpreadFear, 3.00, 15.00, stimData, true);
      };
    };
  }

  private final func CreateFearArea(stimEvent: ref<StimuliEvent>, fearPhase: Int32) -> Void {
    let debugInfo: String;
    let game: GameInstance;
    let owner: ref<GameObject> = this.GetOwner();
    let radius: Float = stimEvent.radius;
    if fearPhase <= 1 {
      return;
    };
    game = owner.GetGame();
    radius = radius / SqrtF(2.00);
    if IsFinal() {
      GameInstance.GetReactionSystem(game).AddFearSource(Cast<Vector3>(stimEvent.sourcePosition), radius);
    } else {
      debugInfo = "[" + EntityID.ToDebugStringDecimal(stimEvent.sourceObject.GetEntityID()) + "] " + EnumValueToString("gamedataStimType", Cast<Int64>(EnumInt(stimEvent.GetStimType())));
      debugInfo += "(R=" + radius + ")";
      GameInstance.GetReactionSystem(game).AddFearSource(Cast<Vector3>(stimEvent.sourcePosition), radius, StringToName(debugInfo));
    };
  }

  private final func ShouldFearInPlace(stimEvent: ref<StimuliEvent>) -> Bool {
    let player: ref<PlayerPuppet>;
    let weapon: ref<WeaponObject>;
    let owner: ref<GameObject> = this.GetOwner();
    let game: GameInstance = owner.GetGame();
    if VehicleComponent.IsMountedToVehicle(game, owner) {
      return false;
    };
    player = GameInstance.GetPlayerSystem(game).GetLocalPlayerMainGameObject() as PlayerPuppet;
    if VehicleComponent.IsMountedToVehicle(game, player) {
      return false;
    };
    if stimEvent.IsTagInStimuli(n"TryRunAway") {
      return false;
    };
    weapon = GameObject.GetActiveWeapon(player);
    if weapon.IsMelee() {
      return false;
    };
    if Equals(PlayerPuppet.GetCurrentCombatState(player), gamePSMCombat.InCombat) {
      if Equals(stimEvent.GetStimType(), gamedataStimType.CombatHit) {
        return true;
      };
      if this.GetThreatDistanceSquared(stimEvent.sourceObject) < this.m_fearInPlaceAroundDistance * this.m_fearInPlaceAroundDistance {
        return true;
      };
    };
    return false;
  }

  private final func TriggerFacialLookAtReaction(opt forceFear: Bool, opt playVO: Bool) -> Void {
    let lookAtData: LookAtData;
    let vo: CName;
    let facialReactionAnimFeature: ref<AnimFeature_FacialReaction> = new AnimFeature_FacialReaction();
    let target: ref<GameObject> = this.GetPlayerSystem().GetLocalPlayerControlledGameObject();
    if !this.m_inCrowd {
      playVO = true;
      facialReactionAnimFeature.category = 3;
      facialReactionAnimFeature.idle = 1;
      this.m_facialCooldown = 2.00;
      vo = n"greeting";
      this.ActivateReactionLookAt(target, false);
    } else {
      if forceFear || this.IsTargetArmed(target) {
        facialReactionAnimFeature.category = 3;
        facialReactionAnimFeature.idle = 10;
        this.ActivateReactionLookAt(target, false);
        this.m_facialCooldown = 5.00;
      } else {
        if (target as PlayerPuppet).IsNaked() {
          facialReactionAnimFeature.category = 3;
          facialReactionAnimFeature.idle = 7;
          vo = n"fear_foll";
          this.ActivateReactionLookAt(target, true);
          this.m_facialCooldown = 5.00;
        } else {
          this.SelectFacialEmotion(lookAtData);
          vo = n"greeting";
          this.ActivateReactionLookAt(target, true, true);
          facialReactionAnimFeature.category = lookAtData.category;
          facialReactionAnimFeature.idle = lookAtData.idle;
          this.m_facialCooldown = 2.00;
        };
      };
    };
    AnimationControllerComponent.ApplyFeatureToReplicate(this.GetOwner(), n"FacialReaction", facialReactionAnimFeature);
    if !this.GetOwnerPuppet().IsVendor() && playVO {
      GameObject.PlayVoiceOver(this.GetOwner(), vo, n"Scripts:TriggerLookAtReaction");
    };
  }

  private final func TriggerFearFacial(phase: Int32) -> Void {
    let facialReactionAnimFeature: ref<AnimFeature_FacialReaction> = new AnimFeature_FacialReaction();
    facialReactionAnimFeature.category = 3;
    switch phase {
      case 1:
        facialReactionAnimFeature.idle = 10;
        break;
      case 2:
        facialReactionAnimFeature.idle = 11;
        break;
      case 3:
        facialReactionAnimFeature.idle = 9;
        break;
      default:
        facialReactionAnimFeature.idle = 10;
    };
    AnimationControllerComponent.ApplyFeatureToReplicate(this.GetOwner(), n"FacialReaction", facialReactionAnimFeature);
  }

  private final func ResetFacial(cooldown: Float) -> Void {
    let facialReactionAnimFeature: ref<AnimFeature_FacialReaction>;
    let facialResetEvent: ref<ResetFacialEvent>;
    if cooldown > 0.00 {
      GameInstance.GetDelaySystem(this.GetOwner().GetGame()).CancelDelay(this.m_resetFacialEventId);
      facialResetEvent = new ResetFacialEvent();
      this.m_resetFacialEventId = this.GetDelaySystem().DelayEvent(this.GetOwner(), facialResetEvent, cooldown);
    } else {
      facialReactionAnimFeature = new AnimFeature_FacialReaction();
      AnimationControllerComponent.ApplyFeatureToReplicate(this.GetOwner(), n"FacialReaction", facialReactionAnimFeature);
    };
  }

  protected cb func OnResetLookatReactionEvent(evt: ref<ResetLookatReactionEvent>) -> Bool {
    this.DeactiveLookAt();
    this.ResetFacial(this.m_facialCooldown);
  }

  protected cb func OnResetFacialEvent(evt: ref<ResetFacialEvent>) -> Bool {
    this.m_facialCooldown = 0.00;
    let facialReactionAnimFeature: ref<AnimFeature_FacialReaction> = new AnimFeature_FacialReaction();
    AnimationControllerComponent.ApplyFeatureToReplicate(this.GetOwner(), n"FacialReaction", facialReactionAnimFeature);
  }

  private final func CanTriggerExpressionLookAt() -> Bool {
    let sceneSystem: ref<SceneSystemInterface>;
    let owner: ref<GameObject> = this.GetOwner();
    let ownerPuppet: ref<ScriptedPuppet> = this.GetOwnerPuppet();
    if !ScriptedPuppet.IsActive(owner) {
      return false;
    };
    if Equals(this.m_highLevelState, gamedataNPCHighLevelState.Combat) || Equals(this.m_highLevelState, gamedataNPCHighLevelState.Alerted) {
      return false;
    };
    if (ownerPuppet as NPCPuppet).IsRagdolling() {
      return false;
    };
    if ScriptedPuppet.IsBlinded(ownerPuppet) {
      return false;
    };
    if Equals(this.m_reactionPreset.Type(), gamedataReactionPresetType.NoReaction) || Equals(this.m_reactionPreset.Type(), gamedataReactionPresetType.Follower) {
      return false;
    };
    if ownerPuppet.IsBoss() {
      return false;
    };
    if this.m_inReactionSequence || Equals(this.m_crowdFearStage, gameFearStage.Alarmed) || Equals(this.m_crowdFearStage, gameFearStage.Panic) {
      return false;
    };
    if StatusEffectSystem.ObjectHasStatusEffectWithTag(owner, n"LoreAnim") {
      return false;
    };
    if GameInstance.GetWorkspotSystem(owner.GetGame()).IsActorInWorkspot(owner) {
      if StatusEffectSystem.ObjectHasStatusEffectWithTag(owner, n"Braindance") || StatusEffectSystem.ObjectHasStatusEffectWithTag(owner, n"Sleep") || StatusEffectSystem.ObjectHasStatusEffectWithTag(owner, n"Busy") {
        return false;
      };
    };
    sceneSystem = GameInstance.GetSceneSystem(owner.GetGame()).GetScriptInterface();
    if IsDefined(sceneSystem) && (sceneSystem.IsEntityInDialogue(owner.GetEntityID()) || sceneSystem.IsEntityInScene(owner.GetEntityID())) {
      return false;
    };
    if !ownerPuppet.IsOnAutonomousAI() {
      return false;
    };
    return true;
  }

  private final func ShouldFearWhileAggressiveCrowdNPCCombat(stimEvent: ref<StimuliEvent>) -> Bool {
    let playerPuppet: ref<PlayerPuppet>;
    let threats: array<TrackedLocation> = this.GetPlayerSystem().GetLocalPlayerControlledGameObject().GetTargetTrackerComponent().GetHostileThreats(false);
    if ArraySize(threats) > 1 {
      return true;
    };
    playerPuppet = stimEvent.sourceObject as PlayerPuppet;
    if WeaponObject.IsMelee(GameObject.GetActiveWeapon(this.GetOwner()).GetItemID()) {
      if Equals(stimEvent.GetStimType(), gamedataStimType.WeaponDisplayed) && WeaponObject.IsRanged(GameObject.GetActiveWeapon(playerPuppet).GetItemID()) {
        return true;
      };
      if StimFilters.IsGunshot(stimEvent.GetStimType()) {
        return true;
      };
    };
    return false;
  }

  private final func ShouldTriggerAggressiveCrowdNPCCombat(stimEvent: ref<StimuliEvent>) -> Bool {
    let distanceToPlayer: Float;
    let maxDistanceToTriggerCombat: Float;
    let navigationSystem: ref<AINavigationSystem>;
    let preventionSystem: ref<PreventionSystem>;
    let playerPuppet: ref<PlayerPuppet> = stimEvent.sourceObject as PlayerPuppet;
    let owner: ref<GameObject> = this.GetOwner();
    if !IsDefined(playerPuppet) {
      return false;
    };
    if playerPuppet.IsInCombat() {
      return false;
    };
    if StatusEffectSystem.ObjectHasStatusEffectWithTag(playerPuppet, n"NoCombat") {
      return false;
    };
    if playerPuppet.GetPlayerStateMachineBlackboard().GetInt(GetAllBlackboardDefs().PlayerStateMachine.Zones) == 2 {
      return false;
    };
    if GameInstance.GetSafeAreaManager(owner.GetGame()).IsPointInSafeArea(playerPuppet.GetWorldPosition()) {
      return false;
    };
    preventionSystem = GameInstance.GetScriptableSystemsContainer(owner.GetGame()).Get(n"PreventionSystem") as PreventionSystem;
    if EnumInt(preventionSystem.GetHeatStage()) > 0 {
      return false;
    };
    if stimEvent.IsTagInStimuli(n"NonAggressiveCrowd") {
      return false;
    };
    if !this.IsTargetInFront(playerPuppet, 120.00) {
      return false;
    };
    if !this.IsTargetInFront(playerPuppet, 150.00, true) {
      return false;
    };
    if WeaponObject.IsRanged(GameObject.GetActiveWeapon(playerPuppet).GetItemID()) {
      distanceToPlayer = Vector4.DistanceSquared(owner.GetWorldPosition(), playerPuppet.GetWorldPosition());
      maxDistanceToTriggerCombat = TweakDBInterface.GetFloat(t"AIGeneralSettings.distanceToTriggerAggressiveCrowdRanged", 15.00);
      if distanceToPlayer >= maxDistanceToTriggerCombat * maxDistanceToTriggerCombat {
        return false;
      };
    } else {
      distanceToPlayer = Vector4.DistanceSquared(owner.GetWorldPosition(), playerPuppet.GetWorldPosition());
      maxDistanceToTriggerCombat = TweakDBInterface.GetFloat(t"AIGeneralSettings.distanceToTriggerAggressiveCrowdMelee", 5.00);
      if distanceToPlayer >= maxDistanceToTriggerCombat * maxDistanceToTriggerCombat {
        return false;
      };
    };
    if !this.m_driverAllowedToGetAggressive && Equals(stimEvent.GetStimType(), gamedataStimType.HijackVehicle) && VehicleComponent.IsMountedToVehicle(owner.GetGame(), owner) {
      return false;
    };
    navigationSystem = GameInstance.GetAINavigationSystem(owner.GetGame());
    if IsDefined(navigationSystem) && !navigationSystem.IsPointOnNavmesh(owner, owner.GetWorldPosition(), 0.10) {
      return false;
    };
    return true;
  }

  private final func IsPlayerFearThreat() -> Bool {
    if this.IsTargetArmed(this.GetPlayerSystem().GetLocalPlayerControlledGameObject()) {
      return true;
    };
    if this.IsPlayerCarryingBody(this.GetPlayerSystem().GetLocalPlayerControlledGameObject() as PlayerPuppet) {
      return true;
    };
    return false;
  }

  private final const func IsPlayerCarryingBody(playerPuppet: wref<PlayerPuppet>) -> Bool {
    let playerStateMachineBlackboard: ref<IBlackboard>;
    if !IsDefined(playerPuppet) {
      return false;
    };
    playerStateMachineBlackboard = GameInstance.GetBlackboardSystem(playerPuppet.GetGame()).GetLocalInstanced(playerPuppet.GetEntityID(), GetAllBlackboardDefs().PlayerStateMachine);
    return playerStateMachineBlackboard.GetBool(GetAllBlackboardDefs().PlayerStateMachine.Carrying);
  }

  private final func SetCrowdRunningAwayAnimFeature(stimType: gamedataStimType) -> Void {
    let crowdRunningAwayAnimFeature: ref<AnimFeature_CrowdRunningAway> = new AnimFeature_CrowdRunningAway();
    if Equals(stimType, gamedataStimType.Driving) {
      crowdRunningAwayAnimFeature.isRunningAwayFromPlayersCar = true;
    } else {
      crowdRunningAwayAnimFeature.isRunningAwayFromPlayersCar = false;
    };
    AnimationControllerComponent.ApplyFeatureToReplicate(this.GetOwner(), n"CrowdRunningAway", crowdRunningAwayAnimFeature);
  }

  private final func SafeToExitFear() -> Bool {
    let distanceToPlayer: Float;
    if this.IsPlayerFearThreat() {
      distanceToPlayer = Vector4.DistanceSquared(this.GetOwner().GetWorldPosition(), this.GetPlayerSystem().GetLocalPlayerControlledGameObject().GetWorldPosition());
      if this.IsTargetInFront(this.GetPlayerSystem().GetLocalPlayerControlledGameObject(), 120.00) {
        if distanceToPlayer < this.m_fearToIdleDistance.X * this.m_fearToIdleDistance.X {
          return false;
        };
      } else {
        if distanceToPlayer < this.m_fearToIdleDistance.Y * this.m_fearToIdleDistance.Y {
          return false;
        };
      };
    };
    return true;
  }

  private final func SafeToExitPanicFear() -> Bool {
    let simTime: Float;
    let distanceToPlayer: Float = Vector4.DistanceSquared(this.GetOwner().GetWorldPosition(), this.GetPlayerSystem().GetLocalPlayerControlledGameObject().GetWorldPosition());
    if GameInstance.GetCameraSystem(this.GetOwner().GetGame()).IsInCameraFrustum(this.GetOwner(), 2.00, 0.75) {
      if distanceToPlayer > 1225.00 {
        simTime = EngineTime.ToFloat(GameInstance.GetSimTime(this.GetOwner().GetGame()));
        if this.m_successfulFearDeescalation == 0.00 {
          this.m_successfulFearDeescalation = simTime + 1.50;
        };
        if this.m_successfulFearDeescalation <= simTime {
          return true;
        };
        return false;
      };
    } else {
      if distanceToPlayer > 506.25 {
        simTime = EngineTime.ToFloat(GameInstance.GetSimTime(this.GetOwner().GetGame()));
        if this.m_successfulFearDeescalation == 0.00 {
          this.m_successfulFearDeescalation = simTime + 0.50;
        };
        if this.m_successfulFearDeescalation >= simTime {
          return true;
        };
        return false;
      };
    };
    this.m_successfulFearDeescalation = 0.00;
    return false;
  }

  private final func SurrenderToLeave() -> Bool {
    let target: ref<GameObject> = this.GetPlayerSystem().GetLocalPlayerControlledGameObject();
    let targetPos: Vector4 = target.GetWorldPosition();
    let ownerPos: Vector4 = this.GetOwner().GetWorldPosition();
    let direction: Vector4 = targetPos - ownerPos;
    let angleToTarget: Float = Vector4.GetAngleDegAroundAxis(direction, this.GetOwner().GetWorldForward(), this.GetOwner().GetWorldUp());
    if AbsF(angleToTarget) > 120.00 {
      return true;
    };
    direction = ownerPos - targetPos;
    angleToTarget = Vector4.GetAngleDegAroundAxis(direction, target.GetWorldForward(), target.GetWorldUp());
    if AbsF(angleToTarget) > 10.00 {
      return true;
    };
    return false;
  }

  private final func CanTriggerReprimandOrder() -> Bool {
    let record: ref<IPrereq_Record>;
    let owner: ref<GameObject> = this.GetOwner();
    let game: GameInstance = owner.GetGame();
    let reprimandAbility: ref<GameplayAbility_Record> = TweakDBInterface.GetGameplayAbilityRecord(t"Ability.CanAskToFollowOrder");
    let prereqCount: Int32 = reprimandAbility.GetPrereqsForUseCount();
    let i: Int32 = 0;
    while i < prereqCount {
      record = reprimandAbility.GetPrereqsForUseItem(i);
      if IPrereq.CreatePrereq(record.GetID()).IsFulfilled(game, owner) {
        return true;
      };
      i += 1;
    };
    return false;
  }

  public final const func CanAskToHolsterWeapon() -> Bool {
    let record: ref<IPrereq_Record>;
    let owner: ref<GameObject> = this.GetOwner();
    let game: GameInstance = owner.GetGame();
    let reprimandAbility: ref<GameplayAbility_Record> = TweakDBInterface.GetGameplayAbilityRecord(t"Ability.CanAskToHolsterWeapon");
    let prereqCount: Int32 = reprimandAbility.GetPrereqsForUseCount();
    let i: Int32 = 0;
    while i < prereqCount {
      record = reprimandAbility.GetPrereqsForUseItem(i);
      if IPrereq.CreatePrereq(record.GetID()).IsFulfilled(game, owner) {
        return true;
      };
      i += 1;
    };
    return false;
  }

  private final func NotifySecuritySystem(stimType: gamedataStimType, stimObject: ref<GameObject>) -> Void {
    if Equals(stimType, gamedataStimType.DeadBody) {
      this.GetOwnerPuppet().TriggerSecuritySystemNotification(stimObject.GetWorldPosition(), stimObject, ESecurityNotificationType.ALARM, stimType);
    };
  }

  private final func SetWarningMessage(const lockey: script_ref<String>) -> Void {
    let simpleScreenMessage: SimpleScreenMessage;
    simpleScreenMessage.isShown = true;
    simpleScreenMessage.duration = 5.00;
    simpleScreenMessage.message = Deref(lockey);
    simpleScreenMessage.isInstant = true;
    GameInstance.GetBlackboardSystem(this.GetPlayerSystem().GetLocalPlayerControlledGameObject().GetGame()).Get(GetAllBlackboardDefs().UI_Notifications).SetVariant(GetAllBlackboardDefs().UI_Notifications.WarningMessage, ToVariant(simpleScreenMessage), true);
  }

  protected cb func OnTriggerDelayedReactionEvent(evt: ref<TriggerDelayedReactionEvent>) -> Bool {
    this.TriggerReactionBehaviorForCrowd(evt.stimEvent, evt.behavior, evt.initAnim);
  }

  protected cb func OnExitWorkspotSequenceEvent(evt: ref<ExitWorkspotSequenceEvent>) -> Bool {
    let owner: ref<GameObject> = this.GetOwner();
    let game: GameInstance = owner.GetGame();
    if this.m_inReactionSequence {
      if Equals(this.m_crowdFearStage, gameFearStage.Panic) && VehicleComponent.IsMountedToVehicle(game, owner) {
        if this.SafeToExitPanicFear() {
          this.m_successfulFearDeescalation = 0.00;
          GameInstance.GetWorkspotSystem(game).HardResetPlaybackToStart(owner);
        } else {
          GameInstance.GetDelaySystem(game).CancelDelay(this.m_exitWorkspotSequenceEventId);
          this.m_exitWorkspotSequenceEventId = GameInstance.GetDelaySystem(game).DelayEvent(owner, evt, 1.00);
        };
      } else {
        if NotEquals(this.m_crowdFearStage, gameFearStage.Panic) {
          if this.SafeToExitFear() {
            if VehicleComponent.IsMountedToVehicle(game, owner) {
              GameInstance.GetWorkspotSystem(game).HardResetPlaybackToStart(owner);
            } else {
              GameInstance.GetWorkspotSystem(game).ResetPlaybackToStart(owner);
            };
          } else {
            GameInstance.GetDelaySystem(game).CancelDelay(this.m_exitWorkspotSequenceEventId);
            this.m_exitWorkspotSequenceEventId = GameInstance.GetDelaySystem(game).DelayEvent(owner, evt, 1.00);
          };
        };
      };
    };
  }

  protected cb func OnDeescalateFearInVehicle(evt: ref<DeescalateFearInVehicle>) -> Bool {
    let crowdSettingsEvent: ref<CrowdSettingsEvent>;
    let mountInfo: MountingInfo;
    let owner: ref<GameObject> = this.GetOwner();
    let game: GameInstance = owner.GetGame();
    if VehicleComponent.IsMountedToVehicle(game, owner) {
      if this.SafeToExitPanicFear() {
        this.m_crowdFearStage = gameFearStage.Relaxed;
        this.GetOwnerPuppet().GetCrowdMemberComponent().ChangeFearStage(this.m_crowdFearStage);
        this.m_successfulFearDeescalation = 0.00;
        AnimationControllerComponent.SetAnimWrapperWeightOnOwnerAndItems(owner, n"fear", 0.00);
        crowdSettingsEvent = new CrowdSettingsEvent();
        crowdSettingsEvent.movementType = n"normal";
        mountInfo = GameInstance.GetMountingFacility(game).GetMountingInfoSingleWithObjects(owner);
        GameInstance.FindEntityByID(game, mountInfo.parentId).QueueEvent(crowdSettingsEvent);
      } else {
        GameInstance.GetDelaySystem(game).CancelDelay(this.m_exitFearInVehicleEventId);
        this.m_exitFearInVehicleEventId = GameInstance.GetDelaySystem(game).DelayEvent(owner, evt, 1.00);
      };
    };
  }

  protected cb func OnCrowdSettingsEvent(evt: ref<CrowdSettingsEvent>) -> Bool {
    this.GetOwnerPuppet().GetCrowdMemberComponent().ChangeMoveType(evt.movementType);
  }

  private final func GetFearReactionPhase(stimEvent: ref<StimuliEvent>) -> Int32 {
    let stimData: stimInvestigateData;
    if StimFilters.IsIllegalAction(stimEvent.GetStimType()) {
      stimData = stimEvent.stimInvestigateData;
      if stimData.fearPhase != 0 {
        return 0;
      };
    };
    if stimEvent.IsTagInStimuli(n"Uncomfortable") {
      if this.m_isInCrosswalk {
        return 1;
      };
      return 0;
    };
    if stimEvent.IsTagInStimuli(n"PotentialFear") {
      return 1;
    };
    if stimEvent.IsTagInStimuli(n"DirectThreat") {
      if this.IsTargetClose(stimEvent.sourceObject, 10.00) {
        return 2;
      };
      return 1;
    };
    if stimEvent.IsTagInStimuli(n"PanicFear") {
      return 3;
    };
    if Equals(stimEvent.GetStimType(), gamedataStimType.SpreadFear) {
      stimData = stimEvent.stimInvestigateData;
      if stimData.fearPhase == 0 {
        return 1;
      };
      return stimData.fearPhase;
    };
    if Equals(stimEvent.GetStimType(), gamedataStimType.Driving) {
      return 3;
    };
    return -1;
  }

  private final func ShouldInterruptCurrentFearStage(fearPhase: Int32) -> Bool {
    if Equals(this.m_highLevelState, gamedataNPCHighLevelState.Relaxed) {
      return true;
    };
    if fearPhase > this.ConvertFearStageToFearPhase(this.m_crowdFearStage) {
      return true;
    };
    return false;
  }

  private final func ConvertFearStageToFearPhase(fearStage: gameFearStage) -> Int32 {
    switch fearStage {
      case gameFearStage.Relaxed:
        return 0;
      case gameFearStage.Stressed:
        return 1;
      case gameFearStage.Alarmed:
        return 2;
      default:
        return 3;
    };
  }

  private final func GetSpreadFearPhase(stimEvent: ref<StimuliEvent>) -> Int32 {
    if Equals(stimEvent.GetStimType(), gamedataStimType.CombatHit) {
      return 1;
    };
    if this.m_desiredFearPhase > 0 && this.m_desiredFearPhase != 3 {
      return 1;
    };
    return this.m_desiredFearPhase;
  }

  private final func CanReactInVehicle(stimEvent: ref<StimuliEvent>) -> Bool {
    let carMountInfo: MountingInfo;
    let count: Int32;
    let i: Int32;
    let mountingInfos: array<MountingInfo>;
    let randDraw: Int32;
    let stimType: gamedataStimType = stimEvent.GetStimType();
    let owner: ref<GameObject> = this.GetOwner();
    let game: GameInstance = owner.GetGame();
    if !VehicleComponent.IsMountedToVehicle(game, owner) {
      return true;
    };
    if Equals(stimType, gamedataStimType.VehicleHit) {
      randDraw = RandRange(0, 100);
      if randDraw > 30 {
        this.LogFailure("randomly ignoring vehicle hits");
        return false;
      };
    };
    if StimFilters.IsIgnoredInVehicle(stimType) {
      this.LogFailure("IsIgnoredInVehicle");
      return false;
    };
    if stimEvent.IsTagInStimuli(n"TrafficPlayerOnly") && !stimEvent.sourceObject.IsPlayer() && NotEquals(PlayerPuppet.GetCurrentCombatState(this.GetPlayerSystem().GetLocalPlayerMainGameObject() as PlayerPuppet), gamePSMCombat.InCombat) {
      this.LogFailure("TrafficPlayerOnly");
      return false;
    };
    if Equals(stimType, gamedataStimType.Dying) {
      carMountInfo = GameInstance.GetMountingFacility(game).GetMountingInfoSingleWithObjects(owner);
      mountingInfos = GameInstance.GetMountingFacility(game).GetMountingInfoMultipleWithIds(carMountInfo.parentId);
      count = ArraySize(mountingInfos);
      i = 0;
      while i < count {
        if (GameInstance.FindEntityByID(game, mountingInfos[i].childId) as GameObject) == stimEvent.sourceObject {
          return true;
        };
        i += 1;
      };
      this.LogFailure("ignoring dying in vehicle");
      return false;
    };
    return true;
  }

  protected cb func OnCrowdCallingPoliceEvent(evt: ref<CrowdCallingPoliceEvent>) -> Bool {
    let request: ref<UnregisterPoliceCaller>;
    this.m_willingToCallPolice = false;
    let reactionSystem: ref<ScriptedReactionSystem> = GameInstance.GetScriptableSystemsContainer(this.GetOwner().GetGame()).Get(n"ScriptedReactionSystem") as ScriptedReactionSystem;
    if IsDefined(reactionSystem) && reactionSystem.IsCaller(this.GetEntity()) {
      this.TriggerReactionBehaviorForCrowd(this.GetPlayerSystem().GetLocalPlayerMainGameObject(), gamedataOutput.CallPolice, false);
      request = new UnregisterPoliceCaller();
      reactionSystem.QueueRequest(request);
    };
  }

  private final func CheckStalk(target: ref<GameObject>, timeout: Float) -> Void {
    let stalkEvent: ref<StalkEvent>;
    if this.m_playerProximity && (NotEquals(this.m_reactionPreset.Type(), gamedataReactionPresetType.Civilian_Passive) || !this.SourceAttitude(target, EAIAttitude.AIA_Friendly)) {
      stalkEvent = new StalkEvent();
      GameInstance.GetDelaySystem(this.GetOwner().GetGame()).DelayEvent(this.GetOwner(), stalkEvent, timeout);
    };
  }

  private final func CheckComfortZone() -> Void {
    let broadcaster: ref<StimBroadcasterComponent>;
    let checkComfortZoneEvent: ref<CheckComfortZoneEvent>;
    let distrurbComfortZoneEvent: ref<DisturbingComfortZone>;
    let owner: ref<GameObject> = this.GetOwner();
    let player: ref<GameObject> = this.GetPlayerSystem().GetLocalPlayerControlledGameObject();
    let game: GameInstance = owner.GetGame();
    let simTime: Float = EngineTime.ToFloat(GameInstance.GetSimTime(game));
    if this.m_playerProximity && this.IsTargetInFront(player) && this.IsTargetInFront(player, 45.00, true) {
      if this.m_disturbingComfortZoneInProgress {
        if this.m_comfortZoneTimestamp >= simTime {
          this.m_entereProximityRecently += 1;
          if this.m_entereProximityRecently >= 3 {
            broadcaster = player.GetStimBroadcasterComponent();
            if IsDefined(broadcaster) {
              broadcaster.SendDrirectStimuliToTarget(owner, gamedataStimType.CrowdIllegalAction, owner);
            };
          };
        } else {
          this.m_entereProximityRecently = 0;
          this.m_disturbingComfortZoneInProgress = false;
        };
      } else {
        this.m_disturbingComfortZoneInProgress = true;
        this.m_entereProximityRecently += 1;
        this.m_comfortZoneTimestamp = simTime + 10.00;
      };
      distrurbComfortZoneEvent = new DisturbingComfortZone();
      this.m_disturbComfortZoneEventId = GameInstance.GetDelaySystem(game).DelayEvent(owner, distrurbComfortZoneEvent, 10.00);
    } else {
      if this.m_playerProximity {
        checkComfortZoneEvent = new CheckComfortZoneEvent();
        this.m_checkComfortZoneEventId = GameInstance.GetDelaySystem(game).DelayEvent(owner, checkComfortZoneEvent, 1.00);
      };
    };
  }

  protected cb func OnDisturbingComfortZoneEvent(evt: ref<DisturbingComfortZone>) -> Bool {
    let broadcaster: ref<StimBroadcasterComponent>;
    let disturbEvent: ref<DisturbingComfortZone>;
    let player: ref<GameObject> = this.GetPlayerSystem().GetLocalPlayerControlledGameObject();
    GameInstance.GetDelaySystem(this.GetOwner().GetGame()).CancelDelay(this.m_disturbComfortZoneEventId);
    if this.m_playerProximity && this.IsTargetInFront(player) && !this.GetOwnerPuppet().IsVendor() && this.IsTargetClose(player, 1.00) && this.IsTargetInFront(player, 45.00, true) {
      this.TriggerFacialLookAtReaction(true, true);
      broadcaster = player.GetStimBroadcasterComponent();
      if IsDefined(broadcaster) {
        broadcaster.SendDrirectStimuliToTarget(this.GetOwner(), gamedataStimType.CrowdIllegalAction, this.GetOwner());
      };
    } else {
      if this.m_playerProximity {
        disturbEvent = new DisturbingComfortZone();
        this.m_disturbComfortZoneEventId = GameInstance.GetDelaySystem(this.GetOwner().GetGame()).DelayEvent(this.GetOwner(), disturbEvent, 1.00);
      };
    };
  }

  protected cb func OnCheckComfortZoneEvent(evt: ref<CheckComfortZoneEvent>) -> Bool {
    GameInstance.GetDelaySystem(this.GetOwner().GetGame()).CancelDelay(this.m_checkComfortZoneEventId);
    this.CheckComfortZone();
  }

  private final func GetOutputPriority(output: gamedataOutput) -> Float {
    let outputRecord: ref<Output_Record> = TweakDBInterface.GetOutputRecord(TDBID.Create("ReactionOutput." + EnumValueToString("gamedataOutput", Cast<Int64>(EnumInt(output)))));
    if IsDefined(outputRecord) {
      return outputRecord.AIPriority();
    };
    return 4.00;
  }

  private final func DelayReaction(stimType: gamedataStimType) -> Bool {
    if Equals(stimType, gamedataStimType.AimingAt) {
      return true;
    };
    return false;
  }

  private final func SelectFacialEmotion(out lookAtData: LookAtData) -> Void {
    let personalities: array<gamedataStatType>;
    ArrayPush(personalities, gamedataStatType.PersonalityAggressive);
    ArrayPush(personalities, gamedataStatType.PersonalityCuriosity);
    ArrayPush(personalities, gamedataStatType.PersonalityDisgust);
    ArrayPush(personalities, gamedataStatType.PersonalityFear);
    ArrayPush(personalities, gamedataStatType.PersonalityFunny);
    ArrayPush(personalities, gamedataStatType.PersonalityJoy);
    ArrayPush(personalities, gamedataStatType.PersonalitySad);
    ArrayPush(personalities, gamedataStatType.PersonalityShock);
    ArrayPush(personalities, gamedataStatType.PersonalitySurprise);
    lookAtData.personality = personalities[RandRange(0, 9)];
    lookAtData.category = 3;
    switch lookAtData.personality {
      case gamedataStatType.PersonalityAggressive:
        lookAtData.idle = 1;
        break;
      case gamedataStatType.PersonalityCuriosity:
        lookAtData.category = 1;
        lookAtData.idle = 3;
        break;
      case gamedataStatType.PersonalityDisgust:
        lookAtData.idle = 7;
        break;
      case gamedataStatType.PersonalityFear:
        lookAtData.idle = 10;
        break;
      case gamedataStatType.PersonalityFunny:
        lookAtData.idle = 5;
        break;
      case gamedataStatType.PersonalityJoy:
        lookAtData.idle = 5;
        break;
      case gamedataStatType.PersonalitySad:
        lookAtData.idle = 3;
        break;
      case gamedataStatType.PersonalityShock:
        lookAtData.idle = 8;
        break;
      case gamedataStatType.PersonalitySurprise:
        lookAtData.idle = 8;
        break;
      default:
        lookAtData.idle = 2;
        lookAtData.category = 2;
    };
  }

  private final func MapLookAtVO(lookAtData: LookAtData, out vo: CName) -> Void {
    switch lookAtData.personality {
      case gamedataStatType.PersonalityAggressive:
        vo = n"fear_foll";
        break;
      case gamedataStatType.PersonalityCuriosity:
        vo = n"greeting";
        break;
      case gamedataStatType.PersonalityDisgust:
        vo = n"fear_foll";
        break;
      case gamedataStatType.PersonalityFear:
        vo = n"fear_foll";
        break;
      case gamedataStatType.PersonalityFunny:
        vo = n"greeting";
        break;
      case gamedataStatType.PersonalityJoy:
        vo = n"greeting";
        break;
      case gamedataStatType.PersonalitySad:
        vo = n"None";
        break;
      case gamedataStatType.PersonalityShock:
        vo = n"fear_foll";
        break;
      case gamedataStatType.PersonalitySurprise:
        vo = n"greeting";
        break;
      default:
        vo = n"None";
        break;
    };
  }

  private func ActivateReactionLookAt(targetEntity: ref<Entity>, opt end: Bool, opt repeat: Bool, opt duration: Float, opt upperBody: Bool, opt inVehicle: Bool) -> Bool {
    let endLookat: ref<EndLookatEvent>;
    let lookAtEvent: ref<LookAtAddEvent>;
    let lookAtPartRequest: LookAtPartRequest;
    let lookAtParts: array<LookAtPartRequest>;
    let owner: ref<GameObject>;
    if !IsDefined(targetEntity) {
      return false;
    };
    if Equals(this.m_highLevelState, gamedataNPCHighLevelState.Combat) {
      return false;
    };
    owner = this.GetOwner();
    if StatusEffectSystem.ObjectHasStatusEffectWithTag(owner, n"LoreAnim") {
      return false;
    };
    if IsDefined(this.m_lookatEvent) {
      this.DeactiveLookAt();
    };
    lookAtEvent = new LookAtAddEvent();
    lookAtEvent.SetEntityTarget(targetEntity, n"pla_default_tgt", Vector4.EmptyVector());
    lookAtEvent.SetStyle(animLookAtStyle.Normal);
    lookAtEvent.request.limits.softLimitDegrees = 360.00;
    lookAtEvent.request.limits.hardLimitDegrees = 270.00;
    lookAtEvent.request.limits.backLimitDegrees = 210.00;
    lookAtEvent.request.limits.hardLimitDistance = GetLookAtLimitDistanceValue(animLookAtLimitDistanceType.None);
    lookAtEvent.request.calculatePositionInParentSpace = true;
    lookAtEvent.bodyPart = n"Eyes";
    lookAtPartRequest.partName = n"Head";
    lookAtPartRequest.weight = 0.10;
    lookAtPartRequest.suppress = 1.00;
    lookAtPartRequest.mode = 0;
    ArrayPush(lookAtParts, lookAtPartRequest);
    if !inVehicle {
      lookAtPartRequest.partName = n"Chest";
      lookAtPartRequest.weight = 2.00;
      lookAtPartRequest.suppress = 0.00;
      lookAtPartRequest.mode = 0;
      if upperBody {
        lookAtPartRequest.weight = 0.20;
      };
      ArrayPush(lookAtParts, lookAtPartRequest);
    };
    if !IsFinal() {
      lookAtEvent.SetDebugInfo("ScriptReactionComponent");
    };
    lookAtEvent.SetAdditionalPartsArray(lookAtParts);
    owner.QueueEvent(lookAtEvent);
    if end {
      endLookat = new EndLookatEvent();
      endLookat.repeat = repeat;
      if duration != 0.00 {
        this.GetDelaySystem().DelayEvent(owner, endLookat, TweakDBInterface.GetFloat(t"AIGeneralSettings.reactionLookAtDuration", duration));
      } else {
        this.GetDelaySystem().DelayEvent(owner, endLookat, TweakDBInterface.GetFloat(t"AIGeneralSettings.reactionLookAtDuration", 5.00));
      };
    };
    this.m_lookatEvent = lookAtEvent;
    return true;
  }

  private final func ActivateUndeadLookAt(targetEntity: ref<Entity>) -> Bool {
    let disableUndead: ref<DisableUndeadAnimFeatureEvent>;
    let endLookat: ref<EndLookatEvent>;
    let lookAtEvent: ref<LookAtAddEvent>;
    let lookAtPartRequest: LookAtPartRequest;
    let lookAtParts: array<LookAtPartRequest>;
    let owner: ref<GameObject>;
    let undeadAnimFeature: ref<AnimFeature_Undead>;
    if !IsDefined(targetEntity) {
      this.LogFailure("can not activate lookat: no target entity");
      return false;
    };
    owner = this.GetOwner();
    if StatusEffectSystem.ObjectHasStatusEffectWithTag(owner, n"LoreAnim") {
      this.LogFailure("can not activate lookat: LoreAnim");
      return false;
    };
    if IsDefined(this.m_lookatEvent) {
      this.DeactiveLookAt();
    };
    lookAtEvent = new LookAtAddEvent();
    lookAtEvent.SetEntityTarget(targetEntity, n"pla_default_tgt", Vector4.EmptyVector());
    lookAtEvent.SetStyle(animLookAtStyle.Normal);
    lookAtEvent.request.transitionSpeed = 66.60;
    lookAtEvent.request.limits.softLimitDegrees = 360.00;
    lookAtEvent.request.limits.hardLimitDegrees = 360.00;
    lookAtEvent.request.limits.backLimitDegrees = 360.00;
    lookAtEvent.request.limits.hardLimitDistance = GetLookAtLimitDistanceValue(animLookAtLimitDistanceType.None);
    lookAtEvent.request.calculatePositionInParentSpace = true;
    lookAtEvent.bodyPart = n"Eyes";
    lookAtPartRequest.partName = n"Head";
    lookAtPartRequest.weight = 0.00;
    lookAtPartRequest.suppress = 1.00;
    lookAtPartRequest.mode = 0;
    ArrayPush(lookAtParts, lookAtPartRequest);
    lookAtPartRequest.partName = n"Chest";
    lookAtPartRequest.weight = 1.50;
    lookAtPartRequest.suppress = 0.10;
    lookAtPartRequest.mode = 0;
    ArrayPush(lookAtParts, lookAtPartRequest);
    if !IsFinal() {
      lookAtEvent.SetDebugInfo("ScriptReactionComponent.ActivateUndeadLookAt");
    };
    lookAtEvent.SetAdditionalPartsArray(lookAtParts);
    owner.QueueEvent(lookAtEvent);
    this.m_lookatEvent = lookAtEvent;
    undeadAnimFeature = new AnimFeature_Undead();
    undeadAnimFeature.active = true;
    AnimationControllerComponent.ApplyFeatureToReplicate(this.GetOwner(), n"Undead", undeadAnimFeature);
    endLookat = new EndLookatEvent();
    endLookat.repeat = false;
    this.GetDelaySystem().DelayEvent(owner, endLookat, 15.00);
    disableUndead = new DisableUndeadAnimFeatureEvent();
    this.GetDelaySystem().DelayEvent(owner, disableUndead, 20.00);
    return true;
  }

  private func DeactiveLookAt(opt repeat: Bool) -> Bool {
    let owner: ref<GameObject>;
    let repeatLookat: ref<RepeatLookatEvent>;
    if !IsDefined(this.m_lookatEvent) {
      return false;
    };
    owner = this.GetOwner();
    LookAtRemoveEvent.QueueRemoveLookatEvent(owner, this.m_lookatEvent);
    this.m_lookatEvent = null;
    if repeat && this.m_playerProximity && !ScriptedPuppet.IsDefeated(owner) && !this.m_lookatRepeat {
      repeatLookat = new RepeatLookatEvent();
      repeatLookat.target = this.GetPlayerSystem().GetLocalPlayerControlledGameObject();
      this.GetDelaySystem().DelayEvent(owner, repeatLookat, TweakDBInterface.GetFloat(t"AIGeneralSettings.repeatReactionLookAtDelay", 2.50));
      this.m_lookatRepeat = true;
    };
    return true;
  }

  private final func OnReactionStarted(reactionData: ref<AIReactionData>) -> Void {
    let player: ref<GameObject>;
    let stimTypeName: CName;
    let owner: ref<GameObject> = this.GetOwner();
    let ownerPuppet: ref<ScriptedPuppet> = this.GetOwnerPuppet();
    let game: GameInstance = owner.GetGame();
    this.m_activeReaction = reactionData;
    if this.m_desiredReaction == reactionData {
      this.m_desiredReaction = null;
    };
    this.m_workspotReactionPlayed = false;
    if IsDefined(ownerPuppet) && IsDefined(ownerPuppet.GetPuppetStateBlackboard()) {
      ownerPuppet.GetPuppetStateBlackboard().SetInt(GetAllBlackboardDefs().PuppetState.ReactionBehavior, EnumInt(this.m_activeReaction.reactionBehaviorName));
      ownerPuppet.GetPuppetStateBlackboard().FireCallbacks();
    };
    if reactionData.reactionCooldown != 0.00 {
      GameObject.StartCooldown(owner, EnumValueToName(n"gamedataStimType", Cast<Int64>(EnumInt(reactionData.stimType))), reactionData.reactionCooldown);
    };
    if Equals(reactionData.reactionBehaviorName, gamedataOutput.DeviceInvestigate) {
      ArrayPush(this.m_investigationList, reactionData.stimEventData);
    };
    if Equals(reactionData.reactionBehaviorName, gamedataOutput.Panic) {
      player = GameInstance.GetPlayerSystem(game).GetLocalPlayerControlledGameObject();
      if GameInstance.GetStatsSystem(game).GetStatValue(Cast<StatsObjectID>(player.GetEntityID()), gamedataStatType.CausingPanicReducesUltimateHacksCost) == 1.00 {
        StatusEffectHelper.ApplyStatusEffect(player, t"BaseStatusEffect.ReduceUltimateHackCostBy2");
      };
    };
    stimTypeName = EnumValueToName(n"gamedataStimType", Cast<Int64>(EnumInt(reactionData.stimType)));
    if !GameObject.IsCooldownActive(owner, n"ActiveReactionValueCooldown-" + stimTypeName) {
      this.AddReactionValueToStatPool(reactionData);
      GameObject.StartCooldown(owner, n"ActiveReactionValueCooldown-" + stimTypeName, 1.00);
    };
    this.CacheReaction(reactionData);
  }

  public final func GetCurrentStimTimeStamp() -> Float {
    return this.m_timeStampThreshold;
  }

  public final func GetCurrentStimThresholdValue() -> Int32 {
    return this.m_currentStimThresholdValue;
  }

  public final func GetCurrentStealthStimTimeStamp() -> Float {
    return this.m_stealthTimeStampThreshold;
  }

  public final func GetCurrentStealthStimThresholdValue() -> Int32 {
    return this.m_currentStealthStimThresholdValue;
  }

  private final func AddInvestigatedBody(bodyID: EntityID) -> Void {
    let bodyInvestigatedEvent: ref<AddInvestigatorEvent> = new AddInvestigatorEvent();
    bodyInvestigatedEvent.investigator = this.GetOwner().GetEntityID();
    let body: ref<Entity> = GameInstance.FindEntityByID(this.GetOwner().GetGame(), bodyID);
    body.QueueEvent(bodyInvestigatedEvent);
  }

  protected cb func OnAddInvestigatedBodyEvent(evt: ref<AddInvestigatorEvent>) -> Bool {
    ArrayPush(this.m_deadBodyInvestigators, evt.investigator);
  }

  public final func InformInvestigators() -> Void {
    let bodyInvestigator: ref<ScriptedPuppet>;
    let removeIgnoreListEvent: ref<IgnoreListEvent> = new IgnoreListEvent();
    removeIgnoreListEvent.bodyID = this.GetOwner().GetEntityID();
    removeIgnoreListEvent.removeEvent = true;
    let i: Int32 = 0;
    while i < ArraySize(this.m_deadBodyInvestigators) {
      bodyInvestigator = GameInstance.FindEntityByID(this.GetOwner().GetGame(), this.m_deadBodyInvestigators[i]) as ScriptedPuppet;
      if ScriptedPuppet.IsAlive(bodyInvestigator) {
        bodyInvestigator.QueueEvent(removeIgnoreListEvent);
      };
      i += 1;
    };
  }

  protected cb func OnBodyPickedUp(evt: ref<SetBodyPositionEvent>) -> Bool {
    let droppedPosition: Vector4;
    let acceptableDistance: Float = 5.00;
    if evt.pickedUp {
      this.m_deadBodyStartingPosition = evt.bodyPosition;
      StatusEffectHelper.ApplyStatusEffect(this.GetOwner(), t"BaseStatusEffect.BeingCarried");
    } else {
      droppedPosition = evt.bodyPosition;
      StatusEffectHelper.RemoveStatusEffect(this.GetOwner(), t"BaseStatusEffect.BeingCarried");
      if Vector4.IsZero(this.m_deadBodyStartingPosition) {
        return false;
      };
      if Vector4.Distance(this.m_deadBodyStartingPosition, droppedPosition) > acceptableDistance {
        this.InformInvestigators();
      };
    };
  }

  private final func OnReactionEnded() -> Void {
    let ownerPuppet: ref<ScriptedPuppet> = this.GetOwnerPuppet();
    this.m_activeReaction = null;
    if IsDefined(ownerPuppet) && IsDefined(ownerPuppet.GetPuppetStateBlackboard()) {
      ownerPuppet.GetPuppetStateBlackboard().SetInt(GetAllBlackboardDefs().PuppetState.ReactionBehavior, 12);
      this.GetPuppetReactionBlackboard().SetBool(GetAllBlackboardDefs().PuppetReaction.exitReactionFlag, false);
    };
    ArrayClear(this.m_investigationList);
  }

  protected cb func OnResetReactionEvent(evt: ref<ResetReactionEvent>) -> Bool {
    if this.m_desiredReaction == evt.data {
      this.m_desiredReaction = null;
    };
  }

  public final static func BodyInvestigated(owner: wref<ScriptedPuppet>) -> Void {
    if !IsDefined(owner) {
      return;
    };
    owner.QueueEvent(new BodyInvestigatedEvent());
  }

  protected cb func OnBodyInvestigated(evt: ref<BodyInvestigatedEvent>) -> Bool {
    let ignoreListEvent: ref<IgnoreListEvent>;
    if this.ShouldAddToIgnoreList(this.m_activeReaction.stimType) {
      ignoreListEvent = new IgnoreListEvent();
      ignoreListEvent.bodyID = this.m_activeReaction.stimEventData.source.GetEntityID();
      ArrayPush(this.m_ignoreList, ignoreListEvent.bodyID);
      this.SendIgnoreEventToSquad(ignoreListEvent);
    };
    if NotEquals(this.GetOwnerPuppet().GetHighLevelStateFromBlackboard(), gamedataNPCHighLevelState.Combat) {
      this.SetWarningMessage("LocKey#53240");
      if this.GetOwnerPuppet().IsConnectedToSecuritySystem() {
        this.NotifySecuritySystem(this.m_activeReaction.stimType, this.m_activeReaction.stimTarget);
      };
    };
  }

  private final func InvestigatingAlready(stimEvent: ref<StimuliEvent>) -> Bool {
    return this.IsInList(this.m_investigationList, this.FillStimData(stimEvent));
  }

  private final const func GetOwnerPuppet() -> ref<ScriptedPuppet> {
    return this.GetOwner() as ScriptedPuppet;
  }

  private final func HasCombatTarget() -> Bool {
    let combatTarget: wref<GameObject>;
    if !IsDefined(this.GetOwnerPuppet()) {
      return false;
    };
    combatTarget = FromVariant<wref<GameObject>>(this.GetOwnerPuppet().GetAIControllerComponent().GetBehaviorArgument(n"CombatTarget"));
    if IsDefined(combatTarget) {
      return true;
    };
    return false;
  }

  private final func PickCloserTarget(newStimEvent: ref<StimuliEvent>, out updateByActive: Bool) -> Void {
    let ownerPos: Vector4 = this.GetOwner().GetWorldPosition();
    let activeDistanceSquared: Float = Vector4.DistanceSquared(this.m_activeReaction.stimSource, ownerPos);
    if activeDistanceSquared < Vector4.DistanceSquared(newStimEvent.sourcePosition, ownerPos) {
      updateByActive = true;
    };
  }

  private final const func DidTargetMakeMeAlerted(target: ref<GameObject>) -> Bool {
    let game: GameInstance;
    let mountInfo: MountingInfo;
    let reactionData: ref<AIReactionData>;
    let recentAlertObject: ref<GameObject>;
    let simTime: Float;
    let stimData: stimInvestigateData;
    let owner: ref<GameObject> = this.GetOwner();
    let ownerPuppet: ref<ScriptedPuppet> = this.GetOwnerPuppet();
    if ArraySize(this.m_reactionCache) == 0 && !IsDefined(this.m_recentAlertObject) {
      return false;
    };
    if NotEquals(ownerPuppet.GetHighLevelStateFromBlackboard(), gamedataNPCHighLevelState.Alerted) {
      return false;
    };
    if ownerPuppet.GetSecuritySystem().IsReprimandOngoing() {
      return false;
    };
    game = owner.GetGame();
    simTime = EngineTime.ToFloat(GameInstance.GetSimTime(game));
    recentAlertObject = this.m_recentAlertObject;
    if IsDefined(recentAlertObject) && recentAlertObject == target && this.m_recentAlertTimeStamp >= simTime {
      return true;
    };
    if ArraySize(this.m_reactionCache) == 0 {
      return false;
    };
    reactionData = this.m_reactionCache[ArraySize(this.m_reactionCache) - 1];
    stimData = reactionData.stimInvestigateData;
    if (reactionData.stimTarget == target || stimData.attackInstigator == target) && reactionData.recentReactionTimeStamp >= simTime && NotEquals(reactionData.reactionBehaviorName, gamedataOutput.Reprimand) {
      return true;
    };
    if EngineTime.ToFloat((owner as NPCPuppet).GetLastSEAppliedByPlayer().GetLastApplicationSimTimestamp()) + 10.00 >= simTime {
      return true;
    };
    if this.IsTargetInterestingForRecentSquadMates(target, reactionData.stimTarget) {
      return true;
    };
    if IsDefined(this.m_stolenVehicle) && VehicleComponent.IsMountedToVehicle(game, target) {
      mountInfo = GameInstance.GetMountingFacility(game).GetMountingInfoSingleWithObjects(target);
      if this.m_stolenVehicle == (GameInstance.FindEntityByID(game, mountInfo.parentId) as VehicleObject) {
        return true;
      };
    };
    return false;
  }

  private final const func IsTargetInterestingForRecentSquadMates(target: ref<GameObject>, ally: ref<GameObject>) -> Bool {
    let reactionCache: array<ref<AIReactionData>>;
    let reactionData: ref<AIReactionData>;
    let simTime: Float;
    let stimData: stimInvestigateData;
    if this.IsTargetRecentSquadAlly(ally) {
      reactionCache = (ally as ScriptedPuppet).GetStimReactionComponent().GetReactionCache();
      reactionData = reactionCache[ArraySize(reactionCache) - 1];
      stimData = reactionData.stimInvestigateData;
      simTime = EngineTime.ToFloat(GameInstance.GetSimTime(this.GetOwner().GetGame()));
      if stimData.attackInstigator == target && reactionData.recentReactionTimeStamp >= simTime {
        return true;
      };
      if EngineTime.ToFloat((ally as NPCPuppet).GetLastSEAppliedByPlayer().GetLastApplicationSimTimestamp()) + 10.00 >= simTime {
        return true;
      };
    };
    return false;
  }

  private final const func IsPlayerAiming() -> Bool {
    let player: ref<GameObject> = GameInstance.GetPlayerSystem(this.GetOwner().GetGame()).GetLocalPlayerControlledGameObject();
    let weapon: ref<WeaponObject> = GameObject.GetActiveWeapon(player);
    let blackboard: ref<IBlackboard> = (player as PlayerPuppet).GetPlayerStateMachineBlackboard();
    if blackboard.GetInt(GetAllBlackboardDefs().PlayerStateMachine.UpperBody) == 6 && weapon.IsRanged() || blackboard.GetInt(GetAllBlackboardDefs().PlayerStateMachine.MeleeWeapon) == 7 || blackboard.GetInt(GetAllBlackboardDefs().PlayerStateMachine.MeleeWeapon) == 9 || blackboard.GetInt(GetAllBlackboardDefs().PlayerStateMachine.LeftHandCyberware) == 5 {
      if GameInstance.GetBlackboardSystem(this.GetOwner().GetGame()).Get(GetAllBlackboardDefs().UI_TargetingInfo).GetEntityID(GetAllBlackboardDefs().UI_TargetingInfo.CurrentVisibleTarget) == this.GetOwner().GetEntityID() {
        return true;
      };
    };
    if blackboard.GetInt(GetAllBlackboardDefs().PlayerStateMachine.CombatGadget) == 3 && this.IsTargetInFront(player, 60.00, true) {
      return true;
    };
    return false;
  }

  public final const func GetDesiredReactionData() -> ref<AIReactionData> {
    return this.m_desiredReaction;
  }

  public final const func GetActiveReactionData() -> ref<AIReactionData> {
    return this.m_activeReaction;
  }

  public final const func GetActiveOrDesiredReactionData() -> ref<AIReactionData> {
    if IsDefined(this.m_activeReaction) {
      return this.m_activeReaction;
    };
    return this.m_desiredReaction;
  }

  public final const func GetDesiredReactionName() -> gamedataOutput {
    if !IsDefined(this.m_desiredReaction) {
      return gamedataOutput.Ignore;
    };
    return this.m_desiredReaction.reactionBehaviorName;
  }

  public final const func GetPendingReactionName() -> gamedataOutput {
    if !IsDefined(this.m_pendingReaction) {
      return gamedataOutput.Ignore;
    };
    return this.m_pendingReaction.reactionBehaviorName;
  }

  public final const func GetReactionBehaviorName() -> gamedataOutput {
    if !IsDefined(this.m_activeReaction) {
      return gamedataOutput.Ignore;
    };
    return this.m_activeReaction.reactionBehaviorName;
  }

  public final const func GetReactionCache() -> array<ref<AIReactionData>> {
    return this.m_reactionCache;
  }

  public final const func GetStimuliCache() -> array<ref<StimEventTaskData>> {
    return this.m_stimuliCache;
  }

  public final const func GetReceivedStimType() -> gamedataStimType {
    return this.m_receivedStimType;
  }

  public final const func GetReceivedStimPropagation() -> gamedataStimPropagation {
    return this.m_receivedStimPropagation;
  }

  public final const func GetWorkSpotReactionFlag() -> Bool {
    return this.m_workspotReactionPlayed;
  }

  public final const func IsTargetInterestingForPerception(target: ref<GameObject>) -> Bool {
    let reactionData: ref<AIReactionData>;
    if !IsDefined(target) {
      return false;
    };
    if this.DidTargetMakeMeAlerted(target) {
      return true;
    };
    if this.IsPlayerCarryingBody(target as PlayerPuppet) && this.IsReactionAvailableInPreset(gamedataStimType.CarryBody) {
      return true;
    };
    if (target as PlayerPuppet).GetPlayerStateMachineBlackboard().GetInt(GetAllBlackboardDefs().PlayerStateMachine.Takedown) > 0 {
      return true;
    };
    if this.IsPlayerAiming() && this.IsReactionAvailableInPreset(gamedataStimType.AimingAt) {
      return true;
    };
    if StatusEffectSystem.ObjectHasStatusEffect(target, t"PreventionStatusEffect.PerformingIllegalAction") && this.IsReactionAvailableInPreset(gamedataStimType.IllegalAction) && !this.SourceAttitude(target, EAIAttitude.AIA_Friendly) && this.m_reactionPreset.IsAggressive() {
      return true;
    };
    if !WeaponObject.IsFists(GameObject.GetActiveWeapon(target).GetItemID()) && IsDefined(GameObject.GetActiveWeapon(target)) && this.CanAskToHolsterWeapon() {
      return true;
    };
    reactionData = this.GetActiveReactionData();
    if IsDefined(reactionData) {
      if Equals(reactionData.reactionBehaviorName, gamedataOutput.BodyInvestigate) {
        return true;
      };
      if reactionData.stimTarget == target {
        if Equals(reactionData.reactionBehaviorName, gamedataOutput.AskToFollowOrder) && NotEquals(reactionData.reactionBehaviorName, gamedataOutput.TurnAt) {
          return false;
        };
        if Equals(reactionData.reactionBehaviorName, gamedataOutput.PlayerCall) {
          return false;
        };
        return true;
      };
    };
    return false;
  }

  public final const func GetPuppetReactionBlackboard() -> ref<IBlackboard> {
    return this.m_puppetReactionBlackboard;
  }

  private final func IsInitAnimShock(behavior: gamedataOutput) -> Bool {
    if Equals(this.GetOwnerPuppet().GetHighLevelStateFromBlackboard(), gamedataNPCHighLevelState.Combat) {
      return false;
    };
    return Equals(behavior, gamedataOutput.Investigate) || Equals(behavior, gamedataOutput.Intruder) || Equals(behavior, gamedataOutput.Panic);
  }

  public final const func IsInitAnimCall(stim: gamedataStimType) -> Bool {
    if Equals(stim, gamedataStimType.Call) {
      return true;
    };
    return false;
  }

  public final const func GetInPendingBehavior() -> Bool {
    return this.m_inPendingBehavior;
  }

  public final const func GetReactionPreset() -> wref<ReactionPreset_Record> {
    return this.m_reactionPreset;
  }

  private final func IsInPendingBehavior() -> Bool {
    if this.m_inPendingBehavior {
      return true;
    };
    if Equals(this.m_stanceState, gamedataNPCStanceState.Vehicle) || Equals(this.m_stanceState, gamedataNPCStanceState.VehicleWindow) {
      return true;
    };
    if (this.GetOwnerPuppet() as NPCPuppet).IsRagdolling() {
      return true;
    };
    return false;
  }

  public final const func IsAlertedByDeadBody() -> Bool {
    return this.m_isAlertedByDeadBody;
  }

  public final func GetPreviousFearPhase() -> Int32 {
    return this.m_previousFearPhase;
  }

  public final func GetEnvironmentalHazards() -> array<ref<StimuliEvent>> {
    return this.m_environmentalHazards;
  }

  private final const func GetActiveStimPriority() -> gamedataStimPriority {
    if !IsDefined(this.m_activeReaction) {
      return gamedataStimPriority.Invalid;
    };
    return this.m_activeReaction.stimPriority;
  }

  private final const func GetActiveStimTarget() -> ref<GameObject> {
    if !IsDefined(this.m_activeReaction) {
      return null;
    };
    return this.m_activeReaction.stimTarget;
  }

  private final const func GetActiveStimSource() -> Vector4 {
    if !IsDefined(this.m_activeReaction) {
      return Vector4.EmptyVector();
    };
    return this.m_activeReaction.stimSource;
  }

  private final func ShouldUpdateThreatPosition(stimEvent: ref<StimuliEvent>) -> Bool {
    if stimEvent.IsTagInStimuli(n"Direct") {
      return false;
    };
    if stimEvent.sourceObject != FromVariant<wref<GameObject>>(this.GetOwnerPuppet().GetAIControllerComponent().GetBehaviorArgument(n"CombatTarget")) {
      return false;
    };
    if this.IsTargetVisible(stimEvent.sourceObject) {
      return false;
    };
    if stimEvent.IsVisual() && !StimFilters.IsGunshot(stimEvent.GetStimType()) {
      return false;
    };
    if SenseComponent.ShouldIgnoreIfPlayerCompanion(this.GetOwnerPuppet(), stimEvent.sourceObject) {
      return false;
    };
    return true;
  }

  private final func ShouldTriggerGrenadeDodgeBehavior(stimEvent: ref<StimuliEvent>) -> Bool {
    let grenade: ref<BaseGrenade>;
    let innerRadius: Float;
    let stimDistanceSquared: Float;
    let ownerPuppet: ref<ScriptedPuppet> = this.GetOwnerPuppet();
    if ownerPuppet.IsCharacterCivilian() || Equals(ownerPuppet.GetNPCType(), gamedataNPCType.Drone) {
      return true;
    };
    if StatusEffectSystem.ObjectHasStatusEffectOfType(ownerPuppet, gamedataStatusEffectType.Wounded) {
      return false;
    };
    innerRadius = TweakDBInterface.GetFloat(t"AIGeneralSettings.grenadeDodgeInnerRadius", 0.00);
    stimDistanceSquared = Vector4.DistanceSquared(this.GetOwner().GetWorldPosition(), stimEvent.sourcePosition);
    grenade = stimEvent.sourceObject as BaseGrenade;
    if stimDistanceSquared <= innerRadius * innerRadius || this.IsTargetInFront(grenade) || this.IsTargetInFront(grenade.GetUser()) {
      return true;
    };
    return false;
  }

  private final func CanTriggerPanicInCombat(stimEvent: ref<StimuliEvent>) -> Bool {
    let distance: Float;
    let stimDistanceSquared: Float;
    if !this.HasCombatTarget() {
      return true;
    };
    stimDistanceSquared = Vector4.DistanceSquared(this.GetOwner().GetWorldPosition(), stimEvent.sourcePosition);
    distance = TweakDBInterface.GetFloat(t"AIGeneralSettings.panicInCombatReactionDistance", 10.00);
    if stimDistanceSquared <= distance * distance {
      return true;
    };
    return false;
  }

  private final func CanStimInterruptCombat(stimEvent: ref<StimuliEvent>, canIgnorePlayerCombatStim: Bool) -> Bool {
    let grenade: ref<BaseGrenade> = stimEvent.sourceObject as BaseGrenade;
    if !canIgnorePlayerCombatStim && !stimEvent.IsTagInStimuli(n"Combat") && !(Equals(stimEvent.GetStimType(), gamedataStimType.ProjectileDistraction) && IsDefined(grenade)) {
      return false;
    };
    if ScriptedPuppet.IsOnOffMeshLink(this.GetOwner()) {
      return false;
    };
    if IsDefined(grenade) && grenade.GetUser() == this.GetOwner() {
      return false;
    };
    return true;
  }

  private final func ShouldAddToIgnoreList(stimType: gamedataStimType) -> Bool {
    if Equals(stimType, gamedataStimType.DeadBody) {
      return true;
    };
    return false;
  }

  public final func IsTargetVisible(target: ref<GameObject>) -> Bool {
    let senseComponent: ref<SenseComponent> = this.GetOwnerPuppet().GetSensesComponent();
    if !IsDefined(senseComponent) && !IsDefined(target) {
      return false;
    };
    if !this.GetOwnerPuppet().IsActive() {
      return false;
    };
    return senseComponent.IsAgentVisible(target);
  }

  private final func IsTargetDetected(target: ref<GameObject>) -> Bool {
    let senseComponent: ref<SenseComponent> = this.GetOwnerPuppet().GetSensesComponent();
    if !IsDefined(senseComponent) && !IsDefined(target) {
      return false;
    };
    if !this.GetOwnerPuppet().IsActive() {
      return false;
    };
    return senseComponent.GetDetection(target.GetEntityID()) >= 100.00;
  }

  private final const func SourceAttitude(source: wref<GameObject>, attitude: EAIAttitude) -> Bool {
    let attitudeOwner: ref<AttitudeAgent> = this.GetOwner().GetAttitudeAgent();
    let attitudeTarget: ref<AttitudeAgent> = source.GetAttitudeAgent();
    if IsDefined(attitudeOwner) && IsDefined(attitudeTarget) && IsDefined(source) {
      if Equals(attitudeOwner.GetAttitudeTowards(attitudeTarget), attitude) {
        return true;
      };
    };
    return false;
  }

  private final static func IsTargetInFrontOfSource(source: wref<GameObject>, target: wref<GameObject>, opt frontAngle: Float, opt checkFullAngle: Bool) -> Bool {
    let angleToTarget: Float;
    let cameraTransform: Transform;
    let direction: Vector4;
    let sourceFwd: Vector4;
    let sourcePos: Vector4;
    let sourceUp: Vector4;
    let targetPos: Vector4;
    if !IsDefined(source) || !IsDefined(target) {
      return false;
    };
    if checkFullAngle && source.IsPlayer() && GameInstance.GetCameraSystem(source.GetGame()).GetActiveCameraWorldTransform(cameraTransform) {
      sourcePos = Transform.GetPosition(cameraTransform);
      sourceFwd = Transform.GetForward(cameraTransform);
    } else {
      sourcePos = source.GetWorldPosition();
      sourceFwd = source.GetWorldForward();
      sourceUp = source.GetWorldUp();
    };
    targetPos = target.GetWorldPosition();
    direction = targetPos - sourcePos;
    angleToTarget = checkFullAngle ? Vector4.GetAngleBetween(direction, sourceFwd) : Vector4.GetAngleDegAroundAxis(direction, sourceFwd, sourceUp);
    if frontAngle == 0.00 {
      frontAngle = 90.00;
    };
    return AbsF(angleToTarget) < frontAngle;
  }

  private final const func IsTargetInFront(target: wref<GameObject>, opt frontAngle: Float, opt meInFrontOfTarget: Bool, opt checkFullAngle: Bool) -> Bool {
    if meInFrontOfTarget {
      return ReactionManagerComponent.IsTargetInFrontOfSource(target, this.GetOwner(), frontAngle, checkFullAngle);
    };
    return ReactionManagerComponent.IsTargetInFrontOfSource(this.GetOwner(), target, frontAngle, checkFullAngle);
  }

  private final const func IsTargetBehind(target: wref<GameObject>, opt angle: Float, opt meBehindOfTarget: Bool) -> Bool {
    let owner: ref<GameObject> = this.GetOwner();
    let ownerPos: Vector4 = owner.GetWorldPosition();
    let ownerFwd: Vector4 = owner.GetWorldForward();
    let ownerUp: Vector4 = owner.GetWorldUp();
    let targetPos: Vector4 = target.GetWorldPosition();
    let direction: Vector4 = targetPos - ownerPos;
    let angleToTarget: Float = Vector4.GetAngleDegAroundAxis(direction, ownerFwd, ownerUp);
    if angle == 0.00 {
      angle = 120.00;
    };
    if meBehindOfTarget {
      direction = ownerPos - targetPos;
      angleToTarget = Vector4.GetAngleDegAroundAxis(direction, target.GetWorldForward(), target.GetWorldUp());
      if AbsF(angleToTarget) > angle {
        return true;
      };
    } else {
      direction = targetPos - ownerPos;
      angleToTarget = Vector4.GetAngleDegAroundAxis(direction, ownerFwd, ownerUp);
      if AbsF(angleToTarget) > angle {
        return true;
      };
    };
    return false;
  }

  public final const func IsTargetInMovementDirection(target: wref<GameObject>) -> Bool {
    let angleToTarget: Float;
    let vecToTarget: Vector4 = target.GetWorldPosition() - this.GetOwner().GetWorldPosition();
    let movementDirection: Vector4 = this.GetOwnerPuppet().GetCrowdMemberComponent().GetMovementDirection();
    if !Vector4.IsZero(movementDirection) {
      angleToTarget = Vector4.GetAngleDegAroundAxis(vecToTarget, movementDirection, this.GetOwner().GetWorldUp());
      if AbsF(angleToTarget) < 90.00 {
        return true;
      };
    };
    return false;
  }

  private final const func IsTargetPositionClose(targetPos: Vector4, distance: Float) -> Bool {
    let distanceSquared: Float = Vector4.DistanceSquared(targetPos, this.GetOwner().GetWorldPosition());
    return distanceSquared < distance * distance;
  }

  private final const func IsTargetClose(target: wref<GameObject>, distance: Float) -> Bool {
    return this.IsTargetPositionClose(target.GetWorldPosition(), distance);
  }

  private final const func IsTargetVeryClose(target: wref<GameObject>) -> Bool {
    return this.IsTargetClose(target, 3.00) || this.IsTargetClose(target, 6.00) && this.IsTargetInFront(target, 60.00);
  }

  private final const func TargetVerticalCheck(target: wref<GameObject>, opt distance: Float) -> Bool {
    let vecToTarget: Vector4 = this.GetOwner().GetWorldPosition() - target.GetWorldPosition();
    if AbsF(vecToTarget.Z) > 2.00 {
      return false;
    };
    return true;
  }

  public final static func ReactOnPlayerStealthStim(owner: wref<GameObject>, target: wref<GameObject>) -> Bool {
    let attitudeTarget: ref<AttitudeAgent>;
    let attitudeTowardsTarget: EAIAttitude;
    let attitudeOwner: ref<AttitudeAgent> = owner.GetAttitudeAgent();
    if IsDefined(attitudeOwner) {
      attitudeTarget = target.GetAttitudeAgent();
      if IsDefined(attitudeTarget) && target.IsPlayer() {
        attitudeTowardsTarget = attitudeOwner.GetAttitudeTowards(attitudeTarget);
      } else {
        if GameObject.IsVehicle(target) {
          target = GameInstance.GetPlayerSystem(owner.GetGame()).GetLocalPlayerMainGameObject();
          attitudeTarget = target.GetAttitudeAgent();
          attitudeTowardsTarget = attitudeOwner.GetAttitudeTowards(attitudeTarget);
        };
      };
      if IsDefined(attitudeTarget) {
        if Equals(attitudeTowardsTarget, EAIAttitude.AIA_Hostile) {
          return true;
        };
        if Equals(attitudeTowardsTarget, EAIAttitude.AIA_Neutral) && owner.IsConnectedToSecuritySystem() && owner.IsTargetTresspassingMyZone(target) {
          return true;
        };
      };
    };
    return false;
  }

  private final func CheckHearingDistance(stimEvent: ref<StimuliEvent>) -> Bool {
    let distanceSquared: Float = Vector4.DistanceSquared(this.GetOwner().GetWorldPosition(), stimEvent.sourcePosition);
    let radius: Float = stimEvent.radius * GameInstance.GetStatsSystem(this.GetOwner().GetGame()).GetStatValue(Cast<StatsObjectID>(this.GetOwner().GetEntityID()), gamedataStatType.Hearing);
    if distanceSquared <= radius * radius {
      return true;
    };
    return false;
  }

  private final func IsVisibleRaycast(stimEvent: ref<StimuliEvent>, stimOffset: Vector4) -> Bool {
    let raycastTrace: TraceResult;
    let hit: Bool = GameInstance.GetSpatialQueriesSystem(this.GetOwner().GetGame()).SyncRaycastByQueryPreset(this.GetOwner().GetWorldPosition() + stimOffset, stimEvent.sourcePosition + stimOffset, n"Sight Blocker", raycastTrace);
    return !hit;
  }

  private final func IsTargetVisibleBeyondSenses(stimEvent: ref<StimuliEvent>, reactionData: ref<AIReactionData>) -> Bool {
    if !this.GetOwnerPuppet().IsActive() {
      return false;
    };
    if !StimFilters.IsGunshot(stimEvent.GetStimType()) {
      return false;
    };
    if StimFilters.IsGunshot(reactionData.stimType) {
      return false;
    };
    if this.IsTargetClose(stimEvent.sourceObject, 25.00) {
      return false;
    };
    if !this.IsTargetInFront(stimEvent.sourceObject, 60.00) || !this.IsTargetInFront(stimEvent.sourceObject, 50.00, true) {
      return false;
    };
    return this.IsVisibleRaycast(stimEvent, new Vector4(0.00, 0.00, 0.80, 0.00));
  }

  private final func IsPlayerInZone(zone: gamePSMZones) -> Bool {
    let blackboardSystem: ref<BlackboardSystem> = GameInstance.GetBlackboardSystem(this.GetOwner().GetGame());
    let psmBlackboard: ref<IBlackboard> = blackboardSystem.GetLocalInstanced(this.GetPlayerSystem().GetLocalPlayerMainGameObject().GetEntityID(), GetAllBlackboardDefs().PlayerStateMachine);
    if Equals(IntEnum<gamePSMZones>(psmBlackboard.GetInt(GetAllBlackboardDefs().PlayerStateMachine.Zones)), zone) {
      return true;
    };
    return false;
  }

  private final func IsSameStimulus(stimEvent: ref<StimuliEvent>) -> Bool {
    if IsDefined(this.m_activeReaction) && Equals(this.m_activeReaction.stimType, stimEvent.GetStimType()) {
      return true;
    };
    return false;
  }

  private final const func IsSameSourceObject(stimEvent: ref<StimuliEvent>) -> Bool {
    if IsDefined(this.m_activeReaction) && this.m_activeReaction.stimTarget == stimEvent.sourceObject {
      return true;
    };
    return false;
  }

  private final func IsInList(const list: script_ref<array<StimEventData>>, stimData: StimEventData) -> Bool {
    let i: Int32 = 0;
    while i < ArraySize(Deref(list)) {
      if Deref(list)[i].source == stimData.source && Equals(Deref(list)[i].stimType, stimData.stimType) {
        return true;
      };
      i += 1;
    };
    return false;
  }

  private final func IsLowerPriority(stimEvent: ref<StimuliEvent>, activePriority: gamedataStimPriority) -> Bool {
    return Equals(stimEvent.stimRecord.Priority().Type(), gamedataStimPriority.Low) && Equals(activePriority, gamedataStimPriority.High);
  }

  private final func IsTargetSquadAlly(target: wref<GameObject>) -> Bool {
    let ownerSquadInterface: ref<SquadScriptInterface>;
    let ownerSquadName: CName;
    let targetSquadInterface: ref<SquadScriptInterface>;
    let targetSquadName: CName;
    if !AISquadHelper.GetSquadMemberInterface(this.GetOwnerPuppet(), ownerSquadInterface) {
      return false;
    };
    ownerSquadName = ownerSquadInterface.GetName();
    if !AISquadHelper.GetSquadMemberInterface(target, targetSquadInterface) {
      return false;
    };
    targetSquadName = targetSquadInterface.GetName();
    return Equals(ownerSquadName, targetSquadName);
  }

  private final func IsTargetInSameSecuritySystem(target: wref<GameObject>) -> Bool {
    let securitySystem: ref<SecuritySystemControllerPS> = this.GetOwnerPuppet().GetSecuritySystem();
    if !IsDefined(securitySystem) {
      return false;
    };
    return securitySystem.GetAgentRegistry().IsAgent(Cast<PersistentID>(target.GetEntityID()));
  }

  private final func IsTargetMelee(target: ref<GameObject>) -> Bool {
    if IsDefined(GameObject.GetActiveWeapon(target)) && !GameObject.GetActiveWeapon(target).IsRanged() {
      return true;
    };
    return false;
  }

  private final func IsTargetArmed(target: ref<GameObject>) -> Bool {
    if IsDefined(GameObject.GetActiveWeapon(target)) && !WeaponObject.IsFists(GameObject.GetActiveWeapon(target).GetItemID()) {
      return true;
    };
    return false;
  }

  private final const func IsTargetRecentSquadAlly(target: wref<GameObject>) -> Bool {
    let smi: ref<SquadScriptInterface>;
    let squadName: CName;
    let squadCmp: ref<SquadMemberComponent> = target.GetSquadMemberComponent();
    if !IsDefined(squadCmp) {
      return false;
    };
    if !AISquadHelper.GetSquadMemberInterface(this.GetOwner(), smi) {
      return false;
    };
    squadName = smi.GetName();
    if NotEquals(squadName, squadCmp.MySquadNameCurrentOrRecent(AISquadType.Combat)) {
      return false;
    };
    return true;
  }

  private final func ShouldHelpTargetFromSameAttitudeGroup(target: wref<GameObject>, targetOfTarget: wref<GameObject>) -> Bool {
    let preventionSys: ref<PreventionSystem>;
    let ownerPuppet: ref<ScriptedPuppet> = this.GetOwnerPuppet();
    if NotEquals(ownerPuppet.GetAttitudeAgent().GetAttitudeGroup(), target.GetAttitudeAgent().GetAttitudeGroup()) {
      return false;
    };
    if IsDefined(targetOfTarget) && !targetOfTarget.IsPlayer() {
      return true;
    };
    preventionSys = ownerPuppet.GetPreventionSystem();
    if preventionSys.IsChasingPlayer() && target.IsPrevention() && ownerPuppet.IsPrevention() && preventionSys.ShouldWorkSpotPoliceJoinChase(ownerPuppet) {
      return true;
    };
    return false;
  }

  private final func ShouldHelpCausePlayerGotTooClose(targetOfTarget: wref<GameObject>, onlyAlertNoThreat: script_ref<Bool>) -> Bool {
    if IsDefined(targetOfTarget) && targetOfTarget.IsPlayer() && this.IsTargetVeryClose(targetOfTarget) {
      onlyAlertNoThreat = true;
      return true;
    };
    return false;
  }

  private final func ShouldReactToNPCGrenade(grenade: wref<BaseGrenade>) -> Bool {
    return !grenade.GetUser().IsPlayer() && this.IsTargetClose(grenade, 12.00);
  }

  private final const func ShouldPreventionReact(stimEvent: ref<StimuliEvent>) -> Bool {
    let stimTargetPuppet: ref<ScriptedPuppet> = stimEvent.sourceObject as ScriptedPuppet;
    if Equals(stimEvent.GetStimType(), gamedataStimType.DeadBody) && IsDefined(stimTargetPuppet) && stimTargetPuppet.IsCharacterGanger() {
      this.LogInfo("Ignoring ganger body");
      return false;
    };
    if this.IsIllegalActionAgainstGanger(stimEvent) {
      return false;
    };
    if Equals(stimEvent.GetStimType(), gamedataStimType.SpreadFear) {
      this.LogInfo("Ignoring SpreadFear");
      return false;
    };
    if this.GetOwner().IsTargetTresspassingMyZone(stimEvent.sourceObject) {
      return true;
    };
    if PreventionSystem.ShouldReactionBeAgressive(this.GetOwner().GetGame()) {
      return true;
    };
    if Equals(stimEvent.GetStimType(), gamedataStimType.CrimeWitness) {
      return true;
    };
    return false;
  }

  private final const func IsIllegalActionAgainstGanger(stimEvent: ref<StimuliEvent>) -> Bool {
    let stimTargetPuppet: ref<ScriptedPuppet>;
    let attackData: stimInvestigateData = stimEvent.stimInvestigateData;
    if !StimFilters.IsIllegalAction(stimEvent.GetStimType()) || !IsDefined(attackData.victimEntity) {
      return false;
    };
    stimTargetPuppet = attackData.victimEntity as ScriptedPuppet;
    if !IsDefined(stimTargetPuppet) || !stimTargetPuppet.IsCharacterGanger() {
      return false;
    };
    this.LogInfo("Ignoring IllegalAction against ganger");
    return true;
  }

  private final func SetBaseReactionPreset(opt ignoreSavedPreset: Bool) -> Void {
    let ownerPuppet: ref<ScriptedPuppet> = this.GetOwnerPuppet();
    let savedPresetID: TweakDBID = ownerPuppet.GetReactionPresetID();
    if TDBID.IsValid(savedPresetID) && !ignoreSavedPreset {
      this.m_reactionPreset = TweakDBInterface.GetReactionPresetRecord(savedPresetID);
    } else {
      this.m_reactionPreset = TweakDBInterface.GetCharacterRecord(this.GetOwnerPuppet().GetRecordID()).ReactionPreset();
    };
    if this.m_reactionPreset != null {
      this.m_presetName = this.m_reactionPreset.EnumName();
      ownerPuppet.SetReactionPresetID(this.m_reactionPreset.GetID());
    };
    ownerPuppet.RefreshCachedReactionPresetData();
    ownerPuppet.TryRegisterToPrevention();
  }

  private final func SetReactionPreset(reactionPreset: ref<ReactionPreset_Record>) -> Void {
    let ownerPuppet: ref<ScriptedPuppet> = this.GetOwnerPuppet();
    if reactionPreset == TweakDBInterface.GetCharacterRecord(ownerPuppet.GetRecordID()).ReactionPreset() {
      this.ReevaluateReactionPreset(true);
    } else {
      this.m_reactionPreset = reactionPreset;
      this.m_presetName = this.m_reactionPreset.EnumName();
      ownerPuppet.SetReactionPresetID(reactionPreset.GetID());
    };
    ownerPuppet.RefreshCachedReactionPresetData();
    ownerPuppet.TryRegisterToPrevention();
  }

  private final func MapReactionPreset(const mappingName: script_ref<String>) -> Void {
    let basePreset: ref<ReactionPreset_Record>;
    let i: Int32;
    let newPreset: ref<ReactionPreset_Record>;
    let presets: array<wref<PresetMapper_Record>>;
    let ownerPuppet: ref<ScriptedPuppet> = this.GetOwnerPuppet();
    if Equals(mappingName, "NoReaction") {
      newPreset = TweakDBInterface.GetReactionPresetRecord(t"ReactionPresets.NoReaction");
    } else {
      if Equals(mappingName, "Follower") {
        newPreset = TweakDBInterface.GetReactionPresetRecord(t"ReactionPresets.Follower");
      } else {
        basePreset = TweakDBInterface.GetCharacterRecord(ownerPuppet.GetRecordID()).ReactionPreset();
        basePreset.PresetMapper(presets);
        i = 0;
        while i < ArraySize(presets) {
          if Equals(presets[i].MappingName(), mappingName) {
            newPreset = presets[i].Preset();
          };
          i += 1;
        };
      };
    };
    if newPreset == null {
      newPreset = basePreset;
    };
    this.m_reactionPreset = newPreset;
    this.m_presetName = this.m_reactionPreset.EnumName();
    ownerPuppet.RefreshCachedReactionPresetData();
    ownerPuppet.TryRegisterToPrevention();
  }

  private final func ReevaluateReactionPreset(opt ignoreSavedPreset: Bool) -> Void {
    if StatusEffectSystem.ObjectHasStatusEffectWithTag(this.GetOwner(), n"Braindance") || StatusEffectSystem.ObjectHasStatusEffectWithTag(this.GetOwner(), n"Drunk") {
      this.MapReactionPreset("NoReaction");
    } else {
      if Equals(this.m_aiRole, EAIRole.Follower) {
        this.MapReactionPreset("Follower");
      } else {
        if StatusEffectSystem.ObjectHasStatusEffectWithTag(this.GetOwner(), n"Sleep") {
          this.MapReactionPreset("Sleep");
        } else {
          if StatusEffectSystem.ObjectHasStatusEffectWithTag(this.GetOwner(), n"LoreAnim") {
            this.MapReactionPreset("Lore");
          } else {
            if Equals(this.m_stanceState, gamedataNPCStanceState.Vehicle) || Equals(this.m_stanceState, gamedataNPCStanceState.VehicleWindow) {
              this.MapReactionPreset("Vehicle");
            } else {
              this.SetBaseReactionPreset(ignoreSavedPreset);
            };
          };
        };
      };
    };
  }

  private final func CheckCrowd() -> Void {
    this.m_inCrowd = this.GetOwnerPuppet().IsCrowd();
  }

  public final func SetDownedBodyVisibleComponent(visible: Bool, description: CName) -> Void {
    let detectMultEvent: ref<VisibleObjectDetectionMultEvent>;
    let visibleObjectPosition: Vector4;
    let owner: ref<GameObject> = this.GetOwner();
    let puppet: ref<ScriptedPuppet> = owner as ScriptedPuppet;
    let visibleObject: ref<VisibleObjectComponent> = puppet.GetVisibleObjectComponent();
    visibleObject.Toggle(visible);
    if !visible {
      return;
    };
    if !puppet.m_visibleObjectPositionUpdated {
      visibleObjectPosition = visibleObject.GetLocalPosition();
      visibleObjectPosition.Z = visibleObjectPosition.Z + 1.00;
      visibleObject.SetLocalPosition(visibleObjectPosition);
      puppet.m_visibleObjectPositionUpdated = true;
    };
    visibleObject.visibleObject.description = description;
    visibleObject.visibleObject.visibilityDistance = TweakDBInterface.GetFloat(t"stims.DeadBodyStimuli.radius", 10.00);
    detectMultEvent = new VisibleObjectDetectionMultEvent();
    detectMultEvent.multiplier = 0.90;
    owner.QueueEvent(detectMultEvent);
  }

  private final func OnIncapacitated(instigator: ref<GameObject>) -> Void {
    let attackData: stimInvestigateData;
    let broadcaster: ref<StimBroadcasterComponent>;
    let mountInfo: MountingInfo;
    let owner: ref<GameObject> = this.GetOwner();
    let game: GameInstance = owner.GetGame();
    if IsDefined(instigator) && instigator.IsPlayer() {
      this.SetDownedBodyVisibleComponent(true, n"Dead_Body");
      broadcaster = instigator.GetStimBroadcasterComponent();
      if IsDefined(broadcaster) {
        attackData.victimEntity = EntityGameInterface.GetEntity(owner.GetEntity());
        broadcaster.SetSingleActiveStimuli(owner, gamedataStimType.IllegalAction, 2.50, attackData);
      };
      broadcaster = owner.GetStimBroadcasterComponent();
      if IsDefined(broadcaster) {
        attackData.attackInstigator = instigator;
        attackData.attackInstigatorPosition = instigator.GetWorldPosition();
        broadcaster.TriggerSingleBroadcast(owner, gamedataStimType.DeadBody, attackData);
        broadcaster.AddActiveStimuli(owner, gamedataStimType.Dying, 2.00, attackData);
        broadcaster.TriggerSingleBroadcast(owner, gamedataStimType.Dying, 4.00, attackData, true);
        broadcaster.AddActiveStimuli(owner, gamedataStimType.CrowdIllegalAction, -1.00);
      };
    };
    if VehicleComponent.IsMountedToVehicle(game, owner) && this.m_inCrowd {
      mountInfo = GameInstance.GetMountingFacility(game).GetMountingInfoSingleWithObjects(owner);
      VehicleComponent.QueueExitEventToAllNonFriendlyActivePassengers(game, mountInfo.parentId, owner);
    };
  }

  public final static func SendVOEventToSquad(owner: wref<GameObject>, voEvent: CName, opt setOwnerAsAnsweringEntity: Bool, opt onlyForMembersInCombat: Bool) -> Void {
    let answeringEntityId: EntityID;
    let i: Int32;
    let maxDistBattleCry: Float;
    let member: ref<ScriptedPuppet>;
    let ownerPosition: Vector4;
    let smi: ref<SquadScriptInterface>;
    let squadMembers: array<wref<Entity>>;
    let voiceOverName: CName;
    let ownerPuppet: ref<ScriptedPuppet> = owner as ScriptedPuppet;
    if setOwnerAsAnsweringEntity {
      answeringEntityId = ownerPuppet.GetEntityID();
    };
    if !AISquadHelper.GetSquadMemberInterface(ownerPuppet, smi) {
      return;
    };
    squadMembers = smi.ListMembersWeak();
    if ArraySize(squadMembers) <= 1 {
      return;
    };
    ownerPosition = ownerPuppet.GetWorldPosition();
    maxDistBattleCry = TweakDBInterface.GetFloat(t"AIGeneralSettings.maxDistanceBattleCry", 0.00);
    voiceOverName = n"Scripts:SendVOEventToSquad: " + voEvent;
    i = 0;
    while i < ArraySize(squadMembers) {
      member = squadMembers[i] as ScriptedPuppet;
      if member == ownerPuppet {
      } else {
        if !ScriptedPuppet.IsActive(member) {
        } else {
          if onlyForMembersInCombat && NotEquals(member.GetHighLevelStateFromBlackboard(), gamedataNPCHighLevelState.Combat) {
          } else {
            if Vector4.Distance(member.GetWorldPosition(), ownerPosition) < maxDistBattleCry {
              GameObject.PlayVoiceOver(member, voEvent, voiceOverName, 0.00, answeringEntityId);
            };
          };
        };
      };
      i += 1;
    };
  }

  private final func SendIgnoreEventToSquad(opt ignoreListEvent: ref<IgnoreListEvent>) -> Void {
    let i: Int32;
    let member: ref<ScriptedPuppet>;
    let smi: ref<SquadScriptInterface>;
    let squadMembers: array<wref<Entity>>;
    let ownerPuppet: ref<ScriptedPuppet> = this.GetOwnerPuppet();
    if !AISquadHelper.GetSquadMemberInterface(ownerPuppet, smi) {
      return;
    };
    squadMembers = smi.ListMembersWeak();
    if ArraySize(squadMembers) <= 1 {
      return;
    };
    i = 0;
    while i < ArraySize(squadMembers) {
      member = squadMembers[i] as ScriptedPuppet;
      if member == ownerPuppet {
      } else {
        if !ScriptedPuppet.IsActive(member) {
        } else {
          if IsDefined(ignoreListEvent) {
            member.QueueEvent(ignoreListEvent);
          };
        };
      };
      i += 1;
    };
  }

  private final func GetThreatDistanceSquared(threat: ref<GameObject>) -> Float {
    let distanceSquared: Float = Vector4.DistanceSquared(this.GetOwner().GetWorldPosition(), threat.GetWorldPosition());
    return distanceSquared;
  }

  private final func GetFearAnimWrapper(fearPhase: Int32) -> CName {
    switch fearPhase {
      case 1:
        if this.m_fastWalk {
          return n"disturbed";
        };
        return n"default";
      case 2:
        return n"fear";
      case 3:
        return n"panic";
      default:
        return n"default";
    };
  }

  public final const func GetRandomFearLocomotionAnimWrapper(fearPhase: Int32, opt stimType: gamedataStimType) -> CName {
    let rand: Float;
    if Equals(stimType, gamedataStimType.Driving) {
      rand = RandF();
      if rand <= 0.33 {
        return n"FearLocomotion1";
      };
      if rand > 0.33 && rand <= 0.66 {
        return n"FearLocomotion3";
      };
      return n"FearLocomotion4";
    };
    rand = RandF();
    if rand > 0.25 && rand <= 0.50 {
      return n"FearLocomotion1";
    };
    if rand > 0.50 && rand <= 0.75 {
      return n"FearLocomotion2";
    };
    if rand <= 0.25 {
      return n"FearLocomotion3";
    };
    return n"FearLocomotion4";
  }

  private final func ResetAllFearAnimWrappers() -> Void {
    let owner: ref<GameObject> = this.GetOwner();
    AnimationControllerComponent.SetAnimWrapperWeightOnOwnerAndItems(owner, n"disturbed", 0.00);
    AnimationControllerComponent.SetAnimWrapperWeightOnOwnerAndItems(owner, n"fear", 0.00);
    AnimationControllerComponent.SetAnimWrapperWeightOnOwnerAndItems(owner, n"panic", 0.00);
    AnimationControllerComponent.SetAnimWrapperWeightOnOwnerAndItems(owner, n"FearLocomotion1", 0.00);
    AnimationControllerComponent.SetAnimWrapperWeightOnOwnerAndItems(owner, n"FearLocomotion2", 0.00);
    AnimationControllerComponent.SetAnimWrapperWeightOnOwnerAndItems(owner, n"FearLocomotion3", 0.00);
    AnimationControllerComponent.SetAnimWrapperWeightOnOwnerAndItems(owner, n"FearLocomotion4", 0.00);
    this.m_fearLocomotionWrapper = false;
  }

  public final const func IsFearLocomotionWrapperSet() -> Bool {
    return this.m_fearLocomotionWrapper;
  }

  private final func ReevaluateReaction() -> Void {
    if this.SourceAttitude(this.m_activeReaction.stimTarget, EAIAttitude.AIA_Friendly) {
      this.GetPuppetReactionBlackboard().SetBool(GetAllBlackboardDefs().PuppetReaction.exitReactionFlag, true);
      NPCPuppet.ChangeHighLevelState(this.GetOwner(), gamedataNPCHighLevelState.Relaxed);
    };
  }

  private final func CombatGracePeriodPassed(player: ref<PlayerPuppet>) -> Bool {
    let currentSimTime: Float = EngineTime.ToFloat(GameInstance.GetTimeSystem(player.GetGame()).GetSimTime());
    let exitCombatSimTime: Float = player.GetCombatExitTimestamp();
    return currentSimTime - exitCombatSimTime > this.m_gracePeriodDuration;
  }

  protected cb func OnStanceLevelChanged(evt: ref<StanceStateChangeEvent>) -> Bool {
    this.m_stanceState = evt.state;
    this.ReevaluateReactionPreset();
    if Equals(this.m_stanceState, gamedataNPCStanceState.Stand) {
      this.TriggerPendingReaction();
      if this.m_driverIsAggressive {
        this.TriggerAggressiveCrowdBehavior(this.GetOwner(), this.GetPlayerSystem().GetLocalPlayerMainGameObject());
        this.m_driverAllowedToGetAggressive = false;
      };
    };
    if Equals(this.m_stanceState, gamedataNPCStanceState.Vehicle) || Equals(this.m_stanceState, gamedataNPCStanceState.VehicleWindow) || Equals(this.m_stanceState, gamedataNPCStanceState.Swim) {
      this.GetOwnerPuppet().GetBumpComponent().Toggle(false);
    } else {
      this.GetOwnerPuppet().GetBumpComponent().ToggleComponentOn();
    };
  }

  protected cb func OnHighLevelStateDataEvent(evt: ref<gameHighLevelStateDataEvent>) -> Bool {
    this.m_highLevelState = evt.currentHighLevelState;
    if Equals(this.m_highLevelState, gamedataNPCHighLevelState.Dead) {
      this.DeactiveLookAt();
      this.Toggle(false);
    } else {
      if Equals(this.m_highLevelState, gamedataNPCHighLevelState.Relaxed) {
        this.TriggerPendingReaction();
      };
    };
    if Equals(this.m_highLevelState, gamedataNPCHighLevelState.Combat) {
      (this.GetOwner() as NPCPuppet).GetComfortZoneComponent().Toggle(false);
    };
    if this.GetOwnerPuppet().IsConnectedToSecuritySystem() && NotEquals(this.m_highLevelState, gamedataNPCHighLevelState.Alerted) && this.m_isAlertedByDeadBody {
      this.m_isAlertedByDeadBody = false;
    };
    if GameInstance.GetGameFeatureManager(this.GetOwner().GetGame()).AggressiveCrowdsEnabled() && this.m_inCrowd && NotEquals(this.m_highLevelState, gamedataNPCHighLevelState.Combat) && (this.GetOwner() as NPCPuppet).IsAggressive() && !this.m_driverIsAggressive {
      (this.GetOwner() as NPCPuppet).CallUnregisterAggressiveNPC();
    };
  }

  protected cb func OnRagdollEnabledEvent(evt: ref<RagdollNotifyEnabledEvent>) -> Bool {
    if this.m_inCrowd {
      this.m_desiredFearPhase = -1;
    };
  }

  private final func OnGameDetach() -> Void {
    let puppetBlackboard: ref<IBlackboard>;
    if IsDefined(this.GetOwnerPuppet()) {
      puppetBlackboard = this.GetOwnerPuppet().GetPuppetStateBlackboard();
    };
    if IsDefined(puppetBlackboard) && IsDefined(this.m_pendingBehaviorCb) {
      puppetBlackboard.UnregisterListenerBool(GetAllBlackboardDefs().PuppetState.InPendingBehavior, this.m_pendingBehaviorCb);
    };
    if ArraySize(this.m_ignoreList) != 0 {
      this.InformInvestigators();
    };
  }

  protected cb func OnIncapacitatedEvent(evt: ref<IncapacitatedEvent>) -> Bool {
    this.OnIncapacitated((this.GetOwner() as NPCPuppet).GetMyKiller());
  }

  protected cb func OnIgnoreListEvent(evt: ref<IgnoreListEvent>) -> Bool {
    if evt.removeEvent {
      if ArrayContains(this.m_ignoreList, evt.bodyID) {
        ArrayRemove(this.m_ignoreList, evt.bodyID);
      };
    } else {
      ArrayPush(this.m_ignoreList, evt.bodyID);
      this.AddInvestigatedBody(evt.bodyID);
    };
  }

  protected cb func OnNPCRoleChangeEvent(evt: ref<NPCRoleChangeEvent>) -> Bool {
    this.m_aiRole = evt.m_newRole.GetRoleEnum();
    this.ReevaluateReactionPreset();
    if Equals(this.m_aiRole, EAIRole.Follower) {
      this.GetOwnerPuppet().GetBumpComponent().Toggle(false);
    };
  }

  protected cb func OnWorkspotStartedEvent(evt: ref<WorkspotStartedEvent>) -> Bool;

  protected cb func OnWorkspotFinishedEvent(evt: ref<WorkspotFinishedEvent>) -> Bool;

  protected cb func OnStatusEffectApplied(evt: ref<ApplyStatusEffectEvent>) -> Bool {
    let additionalParam: CName = evt.staticData.AdditionalParam();
    if Equals(evt.staticData.StatusEffectType().Type(), gamedataStatusEffectType.Sleep) || evt.staticData.GameplayTagsContains(n"Braindance") || Equals(additionalParam, n"Drunk") {
      this.ReevaluateReactionPreset();
    };
    if Equals(additionalParam, n"LoreAnim") {
      this.ReevaluateReactionPreset();
      this.m_workspotReactionPlayed = true;
    };
    if Equals(additionalParam, n"LoreVictimSaved") {
      AnimationControllerComponent.SetAnimWrapperWeight(this.GetOwnerPuppet(), n"LoreVictimSaved", 1.00);
    };
    if Equals(additionalParam, n"Busy") {
      this.GetOwnerPuppet().EnableInteraction(n"GenericTalk", false);
    };
  }

  protected cb func OnStatusEffectRemoved(evt: ref<RemoveStatusEffect>) -> Bool {
    let startReaction: ref<StimuliEvent>;
    let additionalParam: CName = evt.staticData.AdditionalParam();
    let ownerPuppet: ref<ScriptedPuppet> = this.GetOwnerPuppet();
    if Equals(evt.staticData.StatusEffectType().Type(), gamedataStatusEffectType.Sleep) || evt.staticData.GameplayTagsContains(n"Braindance") || Equals(additionalParam, n"Drunk") {
      this.ReevaluateReactionPreset();
    };
    if Equals(additionalParam, n"LoreAnim") {
      if IsDefined(this.m_activeReaction) || Equals(ownerPuppet.GetHighLevelStateFromBlackboard(), gamedataNPCHighLevelState.Alerted) {
        startReaction = new StimuliEvent();
        startReaction.name = n"loreAnim";
        this.GetOwner().QueueEvent(startReaction);
      };
      if IsDefined(this.m_cacheSecuritySysOutput) {
        this.ReactToSecuritySystemOutputByTask(this.m_cacheSecuritySysOutput);
      };
      this.ReevaluateReactionPreset();
    };
    if Equals(additionalParam, n"LoreVictimSaved") {
      AnimationControllerComponent.SetAnimWrapperWeight(ownerPuppet, n"LoreVictimSaved", 0.00);
    };
    if Equals(additionalParam, n"Busy") {
      ownerPuppet.EnableInteraction(n"GenericTalk", true);
    };
  }

  protected cb func OnReactionFinishedEvent(evt: ref<ReactionFinishedEvent>) -> Bool {
    let crowdSettingsEvent: ref<CrowdSettingsEvent>;
    let mountInfo: MountingInfo;
    let owner: ref<GameObject> = this.GetOwner();
    let game: GameInstance = owner.GetGame();
    this.DeactiveLookAt();
    this.ResetFacial(this.m_facialCooldown);
    this.m_inReactionSequence = false;
    this.m_crowdFearStage = gameFearStage.Relaxed;
    this.GetOwnerPuppet().GetCrowdMemberComponent().ChangeFearStage(this.m_crowdFearStage);
    if VehicleComponent.IsMountedToVehicle(game, owner) {
      crowdSettingsEvent = new CrowdSettingsEvent();
      crowdSettingsEvent.movementType = n"panic";
      mountInfo = GameInstance.GetMountingFacility(game).GetMountingInfoSingleWithObjects(owner);
      GameInstance.FindEntityByID(game, mountInfo.parentId).QueueEvent(crowdSettingsEvent);
    };
  }

  protected cb func OnReevaluatePresetEvent(evt: ref<ReevaluatePresetEvent>) -> Bool {
    let setAggressiveMaskEvent: ref<SetAggressiveMask>;
    this.ReevaluateReactionPreset();
    this.CheckCrowd();
    if IsDefined(this.m_reactionPreset) && this.m_reactionPreset.IsAggressive() {
      setAggressiveMaskEvent = new SetAggressiveMask();
      this.GetOwnerPuppet().QueueEvent(setAggressiveMaskEvent);
    };
  }

  protected cb func OnReactionChangeRequestEvent(evt: ref<ReactionChangeRequestEvent>) -> Bool {
    this.SetReactionPreset(evt.reactionPresetRecord);
  }

  protected cb func OnPendingBehaviorChanged(value: Bool) -> Bool {
    let triggerAIEvent: ref<AIEvent>;
    if value {
      this.m_inPendingBehavior = true;
    } else {
      this.m_inPendingBehavior = false;
      triggerAIEvent = new AIEvent();
      triggerAIEvent.name = n"TriggerCombatReaction";
      this.GetOwnerPuppet().QueueEvent(triggerAIEvent);
    };
  }

  protected cb func OnAttitudeGroupChanged(evt: ref<AttitudeGroupChangedEvent>) -> Bool {
    if IsDefined(this.m_activeReaction) {
      this.ReevaluateReaction();
    };
  }

  private final func CalculateMoveTypeChangeDelay(totalDistance: Float, distanceLeft: Float, minDistance: Float, maxDelay: Float) -> Float {
    let delay: Float = (1.00 - (distanceLeft - minDistance) / (totalDistance - minDistance)) * maxDelay * 0.50;
    delay += RandF() * maxDelay * 0.50;
    return delay;
  }

  protected cb func OnCrosswalkEvent(evt: ref<CrosswalkEvent>) -> Bool {
    let crowdMemberComponent: ref<CrowdMemberBaseComponent>;
    let ownerPuppet: ref<ScriptedPuppet> = this.GetOwnerPuppet();
    let changeMoveTypeEvent: ref<CrowdSettingsEvent> = new CrowdSettingsEvent();
    if Equals(evt.oldTrafficLightColor, worldTrafficLightColor.INVALID) {
      this.m_isInCrosswalk = true;
    };
    if Equals(evt.trafficLightColor, worldTrafficLightColor.INVALID) {
      this.m_isInCrosswalk = false;
    };
    if Equals(evt.oldTrafficLightColor, worldTrafficLightColor.INVALID) || NotEquals(this.m_crowdFearStage, gameFearStage.Relaxed) {
      return false;
    };
    crowdMemberComponent = ownerPuppet.GetCrowdMemberComponent();
    if Equals(evt.trafficLightColor, worldTrafficLightColor.RED) {
      if evt.totalDistance - evt.distanceLeft <= 1.50 {
        crowdMemberComponent.TryChangeMovementDirection();
      } else {
        if evt.distanceLeft > 2.00 {
          changeMoveTypeEvent.movementType = n"jog";
          GameInstance.GetDelaySystem(this.GetOwner().GetGame()).DelayEvent(this.GetOwner(), changeMoveTypeEvent, this.CalculateMoveTypeChangeDelay(evt.totalDistance, evt.distanceLeft, 2.00, evt.totalDistance / 5.00));
        };
      };
    } else {
      if Equals(evt.trafficLightColor, worldTrafficLightColor.YELLOW) {
        if evt.totalDistance - evt.distanceLeft <= 1.50 {
          crowdMemberComponent.TryChangeMovementDirection();
        } else {
          if evt.distanceLeft > 4.00 {
            changeMoveTypeEvent.movementType = n"jog";
            GameInstance.GetDelaySystem(this.GetOwner().GetGame()).DelayEvent(this.GetOwner(), changeMoveTypeEvent, this.CalculateMoveTypeChangeDelay(evt.totalDistance, evt.distanceLeft, 4.00, evt.totalDistance / 5.00));
          };
        };
      } else {
        if Equals(evt.trafficLightColor, worldTrafficLightColor.GREEN) {
          crowdMemberComponent.ChangeMoveType(n"walk");
        } else {
          crowdMemberComponent.ChangeMoveType(n"walk");
        };
      };
    };
  }

  protected cb func OnBumpEvent(evt: ref<BumpEvent>) -> Bool {
    let blackboard: ref<IBlackboard>;
    let broadcaster: ref<StimBroadcasterComponent>;
    let distanceBuffer: Float;
    let distanceSquared: Float;
    let player: ref<GameObject>;
    let speedModifier: Float;
    let triggerDistance: Float;
    let vehicle: ref<VehicleObject>;
    let workspotSystem: ref<WorkspotGameSystem>;
    let owner: ref<GameObject> = this.GetOwner();
    let ownerPuppet: ref<ScriptedPuppet> = this.GetOwnerPuppet();
    let game: GameInstance = owner.GetGame();
    if !IsDefined(ownerPuppet) || !ownerPuppet.IsActive() {
      return false;
    };
    if Equals(this.m_reactionPreset.Type(), gamedataReactionPresetType.NoReaction) {
      return false;
    };
    if !this.m_initCrowd {
      this.InitCrowd();
      this.m_initCrowd = true;
    };
    player = this.GetPlayerSystem().GetLocalPlayerMainGameObject();
    if evt.isMounted {
      distanceBuffer = this.m_bumpTriggerDistanceBufferMounted;
    } else {
      if GameInstance.GetWorkspotSystem(owner.GetGame()).IsActorInWorkspot(owner) && GameInstance.GetWorkspotSystem(owner.GetGame()).IsActorInWorkspot(this.GetPlayerSystem().GetLocalPlayerControlledGameObject()) && StatusEffectSystem.ObjectHasStatusEffect(this.GetOwner(), t"WorkspotStatus.SyncAnimation") {
        return false;
      };
      if ScriptedPuppet.IsBeingGrappled(ownerPuppet) {
        return false;
      };
      blackboard = GameInstance.GetBlackboardSystem(game).GetLocalInstanced(player.GetEntityID(), GetAllBlackboardDefs().PlayerStateMachine);
      if blackboard.GetInt(GetAllBlackboardDefs().PlayerStateMachine.Locomotion) == 1 {
        distanceBuffer = this.m_bumpTriggerDistanceBufferCrouched;
      };
    };
    vehicle = GameInstance.FindEntityByID(game, evt.vehicleEntityID) as VehicleObject;
    if evt.sourceSpeed > 15.00 {
      speedModifier = 3.50;
    } else {
      if evt.sourceSpeed > 10.00 {
        speedModifier = 2.50;
      } else {
        if evt.sourceSpeed > 5.00 {
          speedModifier = 1.50;
        } else {
          if evt.sourceSpeed > 1.50 {
            speedModifier = 0.50;
          };
        };
      };
    };
    distanceSquared = evt.sourceSquaredDistance;
    triggerDistance = evt.sourceRadius + this.m_NPCRadius + distanceBuffer + speedModifier;
    if !evt.isMounted {
      triggerDistance = evt.sourceRadius + this.m_NPCRadius + distanceBuffer;
      if distanceSquared > triggerDistance * triggerDistance {
        return false;
      };
    };
    if !GameObject.IsCooldownActive(ownerPuppet, n"bumpCooldown") {
      if evt.isMounted {
        GameObject.StartCooldown(ownerPuppet, n"bumpCooldown", TDB.GetFloat(t"AIGeneralSettings.vehicleBumpCooldown"));
        if !(ownerPuppet as NPCPuppet).IsRagdolling() {
          if NotEquals(ownerPuppet.GetHighLevelStateFromBlackboard(), gamedataNPCHighLevelState.Combat) || ownerPuppet.IsPrevention() {
            this.TriggerReactionBehaviorForCrowd(vehicle, gamedataOutput.DodgeToSide, false, evt.sourcePosition);
          };
        };
      } else {
        GameObject.StartCooldown(ownerPuppet, n"bumpCooldown", 1.00);
        if this.SourceAttitude(player, EAIAttitude.AIA_Friendly) {
          return false;
        };
        GameObject.PlayVoiceOver(owner, n"bump", n"Scripts:OnBumpEvent");
        broadcaster = player.GetStimBroadcasterComponent();
        workspotSystem = GameInstance.GetWorkspotSystem(game);
        if workspotSystem.IsActorInWorkspot(ownerPuppet) {
        } else {
          if this.m_inTrafficLane {
          } else {
            if this.m_inCrowd || this.IsReactionAvailableInPreset(gamedataStimType.Bump) {
              this.TriggerReactionBehaviorForCrowd(player, gamedataOutput.Bump, false);
            };
          };
        };
        if this.m_bumpTimestamp >= EngineTime.ToFloat(GameInstance.GetSimTime(game)) {
          this.m_bumpedRecently += 1;
          if this.m_inCrowd {
            if this.m_bumpedRecently > 2 {
              this.TriggerFacialLookAtReaction(true, true);
              if IsDefined(broadcaster) {
                broadcaster.SendDrirectStimuliToTarget(ownerPuppet, gamedataStimType.Bump, ownerPuppet);
              };
            };
          } else {
            if this.m_reactionPreset.IsAggressive() && IsDefined(broadcaster) {
              if this.m_bumpedRecently <= 2 {
                if workspotSystem.IsActorInWorkspot(ownerPuppet) && !ownerPuppet.IsConnectedToSecuritySystem() {
                  broadcaster.SendDrirectStimuliToTarget(ownerPuppet, gamedataStimType.Provoke, ownerPuppet);
                } else {
                  if IsDefined(this.m_desiredReaction) {
                    this.m_desiredReaction.escalateProvoke = true;
                  };
                };
              } else {
                if !this.CanTriggerReprimandOrder() && IsDefined(this.m_activeReaction) && Equals(this.m_activeReaction.reactionBehaviorName, gamedataOutput.Bump) {
                  broadcaster.SendDrirectStimuliToTarget(ownerPuppet, gamedataStimType.Combat, ownerPuppet);
                };
              };
            };
          };
        } else {
          this.m_bumpedRecently = 1;
          this.m_bumpTimestamp = EngineTime.ToFloat(GameInstance.GetSimTime(game)) + 10.00;
          if this.m_inCrowd {
            this.TriggerFacialLookAtReaction(true);
          } else {
            if this.m_reactionPreset.IsAggressive() {
              if IsDefined(broadcaster) && workspotSystem.IsActorInWorkspot(ownerPuppet) && !ownerPuppet.IsConnectedToSecuritySystem() {
                broadcaster.SendDrirectStimuliToTarget(ownerPuppet, gamedataStimType.Provoke, ownerPuppet);
              };
            };
          };
        };
      };
    };
  }

  protected cb func OnClearFearOnHitEvent(evt: ref<ClearFearOnHitEvent>) -> Bool {
    if this.GetOwnerPuppet().IsCharacterCivilian() && !IsDefined(this.m_pendingReaction) {
      this.m_crowdFearStage = gameFearStage.Relaxed;
      this.ResetAllFearAnimWrappers();
    };
  }

  private final func PlayBumpInWorkspot(side: gameinteractionsBumpSide, direction: Vector4) -> Void {
    let reactionName: CName;
    let actor: wref<GameObject> = this.GetOwner();
    let workspotSystem: ref<WorkspotGameSystem> = GameInstance.GetWorkspotSystem(actor.GetGame());
    let isBumpFromFront: Bool = Vector4.Dot2D(actor.GetWorldForward(), direction) < 0.00;
    switch side {
      case gameinteractionsBumpSide.Left:
        reactionName = isBumpFromFront ? n"BumpLeftFront" : n"BumpLeftBack";
        break;
      case gameinteractionsBumpSide.Right:
        reactionName = isBumpFromFront ? n"BumpRightFront" : n"BumpRightBack";
        break;
      default:
        return;
    };
    if workspotSystem.IsReactionAvailable(actor, reactionName) {
      workspotSystem.SendReactionSignal(actor, reactionName);
    };
  }

  protected cb func OnVehicleHit(evt: ref<gameVehicleHitEvent>) -> Bool {
    let magnitude: Float;
    let shouldOmitStims: Bool;
    let velocityDiff: Vector4;
    let instigator: ref<GameObject> = evt.attackData.GetInstigator();
    if !IsDefined(instigator) {
      return false;
    };
    velocityDiff = evt.vehicleVelocity - evt.preyVelocity;
    magnitude = Vector4.Length(velocityDiff);
    shouldOmitStims = !GameObject.IsCooldownActive(this.GetOwner(), n"vehicleSlowHitOnCivilian") && instigator.IsPlayer() && magnitude <= 9.72;
    if instigator.IsPlayer() && !shouldOmitStims {
      StimBroadcasterComponent.BroadcastStim(instigator, gamedataStimType.CrimeWitness);
    };
    if !GameObject.IsCooldownActive(this.GetOwner(), n"vehicleHitCooldown") {
      GameObject.StartCooldown(this.GetOwner(), n"vehicleHitCooldown", 1.00);
      if !shouldOmitStims {
        StimBroadcasterComponent.BroadcastStim(instigator, gamedataStimType.VehicleHit, TweakDBInterface.GetFloat(t"AIGeneralSettings.vehicleHitFearSpreadRange", 5.00));
      };
    };
  }

  protected cb func OnPlayerProximityStartEvent(evt: ref<PlayerProximityStartEvent>) -> Bool {
    let proximityLookatEvent: ref<ProximityLookatEvent>;
    let player: wref<PlayerPuppet> = this.GetPlayerSystem().GetLocalPlayerControlledGameObject() as PlayerPuppet;
    if !IsDefined(player) {
      return false;
    };
    if Equals(evt.profile, n"Crowds") {
      this.m_playerProximity = true;
      if this.m_inCrowd || !this.GetOwnerPuppet().IsConnectedToSecuritySystem() {
        if this.CanTriggerExpressionLookAt() {
          if this.IsTargetInFront(player, 45.00, true) && this.IsTargetInFront(player) {
            if this.m_inCrowd {
              this.ActivateReactionLookAt(player, true, true);
            } else {
              this.ActivateReactionLookAt(player, false);
            };
          };
          proximityLookatEvent = new ProximityLookatEvent();
          this.m_proximityLookatEventId = this.GetDelaySystem().DelayEvent(this.GetOwner(), proximityLookatEvent, 2.00);
        };
      };
    };
  }

  protected cb func OnPlayerProximityStopEvent(evt: ref<PlayerProximityStopEvent>) -> Bool {
    let delaySystem: ref<DelaySystem>;
    if this.m_playerProximity {
      this.m_playerProximity = false;
      if !this.m_inReactionSequence {
        this.DeactiveLookAt();
        this.ResetFacial(this.m_facialCooldown);
      };
    };
    delaySystem = GameInstance.GetDelaySystem(this.GetOwner().GetGame());
    delaySystem.CancelDelay(this.m_disturbComfortZoneEventId);
    delaySystem.CancelDelay(this.m_checkComfortZoneEventId);
    delaySystem.CancelDelay(this.m_proximityLookatEventId);
  }

  protected cb func OnProximityLookatEvent(evt: ref<ProximityLookatEvent>) -> Bool {
    let proximityLookatEvent: ref<ProximityLookatEvent>;
    GameInstance.GetDelaySystem(this.GetOwner().GetGame()).CancelDelay(this.m_proximityLookatEventId);
    if this.CanTriggerExpressionLookAt() {
      if this.m_playerProximity && this.IsTargetInFront(this.GetPlayerSystem().GetLocalPlayerControlledGameObject()) && this.IsTargetInFront(this.GetPlayerSystem().GetLocalPlayerControlledGameObject(), 45.00, true) {
        this.TriggerFacialLookAtReaction();
      } else {
        if this.m_playerProximity {
          proximityLookatEvent = new ProximityLookatEvent();
          this.m_proximityLookatEventId = this.GetDelaySystem().DelayEvent(this.GetOwner(), proximityLookatEvent, 1.50);
        };
      };
    };
  }

  protected cb func OnSwapped(evt: ref<AIPuppetSwappedEvent>) -> Bool {
    if NotEquals(this.m_crowdFearStage, gameFearStage.Relaxed) {
      this.GetPuppetReactionBlackboard().SetBool(GetAllBlackboardDefs().PuppetReaction.exitReactionFlag, true);
      this.ResetAllFearAnimWrappers();
      GameInstance.GetReactionSystem(this.GetOwner().GetGame()).UnmarkDespawnCandidate(this.GetOwner().GetEntityID());
    };
  }

  protected cb func OnTeleported(evt: ref<AIPuppetTeleportedEvent>) -> Bool {
    let owner: ref<GameObject> = this.GetOwner();
    StatusEffectHelper.RemoveStatusEffectsWithTag(owner, n"Ping");
    GameObject.UntagObject(owner);
  }

  protected cb func OnInCrowd(evt: ref<InCrowd>) -> Bool {
    this.m_inTrafficLane = true;
  }

  protected cb func OnOutOfCrowd(evt: ref<OutOfCrowd>) -> Bool {
    this.m_inTrafficLane = false;
  }

  public final func IsInTrafficLane() -> Bool {
    return this.m_inTrafficLane;
  }

  protected cb func OnVehicleHijackEvent(evt: ref<VehicleHijackEvent>) -> Bool {
    this.m_beignHijacked = true;
    this.m_driverAllowedToGetAggressive = evt.driverAllowedToGetAggressive;
  }

  protected cb func OnResetVehicleHijackEvent(evt: ref<ResetVehicleHijackEvent>) -> Bool {
    this.m_beignHijacked = false;
  }

  protected cb func OnSwapPreset(evt: ref<SwapPresetEvent>) -> Bool {
    if Equals(evt.mappingName, "Base") {
      this.SetBaseReactionPreset();
    } else {
      this.MapReactionPreset(evt.mappingName);
    };
  }

  protected cb func OnRainEvent(evt: ref<RainEvent>) -> Bool;

  protected cb func OnDistrurbComfortZoneAggressiveEvent(evt: ref<DistrurbComfortZoneAggressiveEvent>) -> Bool {
    let owner: ref<GameObject> = this.GetOwner();
    this.m_backOffInProgress = true;
    this.m_backOffTimestamp = EngineTime.ToFloat(GameInstance.GetSimTime(owner.GetGame())) + 50.00;
    let broadcaster: ref<StimBroadcasterComponent> = this.GetPlayerSystem().GetLocalPlayerControlledGameObject().GetStimBroadcasterComponent();
    if IsDefined(broadcaster) {
      broadcaster.SendDrirectStimuliToTarget(owner, gamedataStimType.Provoke, owner);
    };
  }

  protected cb func OnAreaEnter(trigger: ref<AreaEnteredEvent>) -> Bool {
    let broadcaster: ref<StimBroadcasterComponent>;
    let distrurbComfortZoneAggressiveEvent: ref<DistrurbComfortZoneAggressiveEvent>;
    let owner: ref<GameObject> = this.GetOwner();
    let game: GameInstance = owner.GetGame();
    GameObject.PlayVoiceOver(owner, n"stlh_curious_grunt", n"Scripts:ProcessReactionOutput");
    this.ActivateReactionLookAt(GameInstance.GetPlayerSystem(game).GetLocalPlayerMainGameObject(), true);
    if this.m_backOffInProgress && this.m_backOffTimestamp >= EngineTime.ToFloat(GameInstance.GetSimTime(game)) {
      broadcaster = this.GetPlayerSystem().GetLocalPlayerControlledGameObject().GetStimBroadcasterComponent();
      if IsDefined(broadcaster) {
        broadcaster.SendDrirectStimuliToTarget(owner, gamedataStimType.Provoke, owner);
      };
    } else {
      this.m_backOffInProgress = false;
      distrurbComfortZoneAggressiveEvent = new DistrurbComfortZoneAggressiveEvent();
      this.m_disturbComfortZoneAggressiveEventId = GameInstance.GetDelaySystem(game).DelayEvent(owner, distrurbComfortZoneAggressiveEvent, 2.00);
    };
  }

  protected cb func OnAreaExit(trigger: ref<AreaExitedEvent>) -> Bool {
    this.DeactiveLookAt();
    GameInstance.GetDelaySystem(this.GetOwner().GetGame()).CancelDelay(this.m_disturbComfortZoneAggressiveEventId);
  }

  protected cb func OnExplorationEnteredEvent(evt: ref<ExplorationEnteredEvent>) -> Bool {
    this.GetOwnerPuppet().GetPuppetStateBlackboard().SetBool(GetAllBlackboardDefs().PuppetState.InPendingBehavior, true);
  }

  protected cb func OnExplorationLeftEvent(evt: ref<ExplorationLeftEvent>) -> Bool {
    this.GetOwnerPuppet().GetPuppetStateBlackboard().SetBool(GetAllBlackboardDefs().PuppetState.InPendingBehavior, false);
  }
}
