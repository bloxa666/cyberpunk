
public static func NoScreenMessage() -> SimpleScreenMessage {
  let ret: SimpleScreenMessage;
  return ret;
}
