
public native class WeatherScriptListener extends IScriptable {

  public func OnRainIntensityChanged(rainIntensity: Float) -> Void;

  public func OnRainIntensityTypeChanged(rainIntensityType: worldRainIntensity) -> Void;
}
