
public native class ScriptStatPoolsListener extends IStatPoolsListener {

  public func OnStatPoolValueChanged(oldValue: Float, newValue: Float, percToPoints: Float) -> Void;
}
