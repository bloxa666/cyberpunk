
public class DetailedLocomotionPSMPrereq extends PlayerStateMachinePrereq {

  protected const func OnRegister(state: ref<PrereqState>, game: GameInstance, context: ref<IScriptable>) -> Bool {
    let bb: ref<IBlackboard> = GameInstance.GetBlackboardSystem(game).GetLocalInstanced((context as ScriptedPuppet).GetEntityID(), GetAllBlackboardDefs().PlayerStateMachine);
    let castedState: ref<DetailedLocomotionPSMPrereqState> = state as DetailedLocomotionPSMPrereqState;
    let locomotionID: BlackboardID_Int = GetAllBlackboardDefs().PlayerStateMachine.LocomotionDetailed;
    if !IsDefined(bb) {
      return false;
    };
    castedState.m_owner = context as GameObject;
    castedState.m_listenerInt = bb.RegisterListenerInt(locomotionID, castedState, n"OnStateUpdate");
    castedState.m_prevValue = bb.GetInt(locomotionID);
    return false;
  }

  protected const func OnUnregister(state: ref<PrereqState>, game: GameInstance, context: ref<IScriptable>) -> Void {
    let castedState: ref<DetailedLocomotionPSMPrereqState> = state as DetailedLocomotionPSMPrereqState;
    let bb: ref<IBlackboard> = GameInstance.GetBlackboardSystem(game).GetLocalInstanced((context as ScriptedPuppet).GetEntityID(), GetAllBlackboardDefs().PlayerStateMachine);
    if IsDefined(bb) {
      bb.UnregisterListenerInt(GetAllBlackboardDefs().PlayerStateMachine.LocomotionDetailed, castedState.m_listenerInt);
    };
  }

  protected const func GetStateMachineEnum() -> String {
    return "gamePSMDetailedLocomotionStates";
  }

  protected const func GetCurrentPSMStateIndex(bb: ref<IBlackboard>) -> Int32 {
    return bb.GetInt(GetAllBlackboardDefs().PlayerStateMachine.LocomotionDetailed);
  }
}
