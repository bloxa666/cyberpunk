
public static func GetInvalidDelayID() -> DelayID {
  let invalidID: DelayID;
  return invalidID;
}

public native class DelayCallback extends IScriptable {

  public func Call() -> Void;
}
