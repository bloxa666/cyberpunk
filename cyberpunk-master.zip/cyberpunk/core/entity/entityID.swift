
public static func EMPTY_ENTITY_ID() -> EntityID {
  let entId: EntityID;
  return entId;
}
