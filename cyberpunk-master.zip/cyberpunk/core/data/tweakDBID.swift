
public static func OperatorLogicNot(a: TweakDBID) -> Bool {
  return !TDBID.IsValid(a);
}
